package edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils;


public abstract class Classifier {
	public String methodName=null;
	public int classesN;
	public abstract double[] getPredictionConfidence(Document doc);
	public abstract int classify(Document doc,double thres);
	public abstract String getExtendedFeatures(Document d);
}
