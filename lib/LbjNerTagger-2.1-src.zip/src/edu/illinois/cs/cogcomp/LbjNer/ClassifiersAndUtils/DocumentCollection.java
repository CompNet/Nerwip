package edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils;


import java.io.File; 
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.IO.InFile;


public class DocumentCollection {
	public Vector<Document> docs=new Vector<Document>();
	
	public DocumentCollection(){
	}
	public void addDoc(Document doc){
		docs.addElement(doc);
	}
	public void addDocuments(Vector<Document> _docs)
	{
		for(int i=0;i<_docs.size();i++)
			this.docs.addElement(_docs.elementAt(i));
	}	
	/*
	 * This code assumes each line in a file contains a new document
	 */
	public void addDocuments(String filename,int classID,StopWords stops,boolean discardFirstToken,String tokenizationDelimiters){
		InFile in=new InFile(filename);
		Vector<String> words=in.readLineTokens(tokenizationDelimiters);
		if((discardFirstToken)&&(words!=null)&&(words.size()>0))
			words.removeElementAt(0);
		if(stops!=null)
			words=stops.filterStopWords(words);
		while(words!=null)
		{
			if(words.size()>=0)
				docs.addElement(new Document(words,classID));
			words=in.readLineTokens(tokenizationDelimiters);
			if((discardFirstToken)&&(words!=null)&&(words.size()>0))
				words.removeElementAt(0);
			if(stops!=null)
				words=stops.filterStopWords(words);
		}
	}
	
	/*
	 * This format assumes that the folder contains a bunch of files.
	 * each files is a single doc
	 */
	public void addFolder(String path,int classID,StopWords stops,boolean discardFirstToken,String tokenizationDelimiters){
		String[] files=(new File(path)).list();
		for(int i=0;i<files.length;i++)
		{
			InFile in=new InFile(path+"/"+files[i]);
			Vector<String> allWords=new Vector<String>();
			Vector<String> words=in.readLineTokens(tokenizationDelimiters);
			if((discardFirstToken)&&(words!=null)&&(words.size()>0))
				words.removeElementAt(0);
			if(stops!=null)
				words=stops.filterStopWords(words);
			while(words!=null)
			{
				for(int j=0;j<words.size();j++)
					allWords.addElement(words.elementAt(j));
				words=in.readLineTokens(tokenizationDelimiters);
				if((discardFirstToken)&&(words!=null)&&(words.size()>0))
					words.removeElementAt(0);
				if(stops!=null)
					words=stops.filterStopWords(words);
			}
			docs.addElement(new Document(allWords,classID));
		}
	}

	public void tokenize()
	{
		for(int i=0;i<docs.size();i++)
			docs.elementAt(i).tokenize();
	}
}
