package edu.illinois.cs.cogcomp.LbjNer.ExperimentsJournal;

import java.io.IOException;
import java.util.Vector;

import LBJ2.parse.LinkedVector;

import edu.illinois.cs.cogcomp.LbjNer.IO.InFile;
import edu.illinois.cs.cogcomp.LbjNer.IO.OutFile;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NERDocument;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NETesterMultiDataset;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Parameters;
import edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData.BuildEvaluationFiles;
import edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData.TaggedDataReader;
import edu.stanford.nlp.ie.AbstractSequenceClassifier;
import edu.stanford.nlp.ie.crf.CRFClassifier;

public class EvalStanfordTagger {
    public static void main(String[] args) throws Exception {
    	tagDataWithStanford();
    	evalStanfordTagger();
    }
    
    public static void evalStanfordTagger() throws Exception{
		String goldPath="Data/GoldData/";
		String stanfordPath="Data/TaggedData";

		String[] goldFiles={
				"MUC7Columns/MUC7.NE.dryrun.sentences.columns.gold",
				"MUC7Columns/MUC7.NE.formalrun.sentences.columns.gold",
				"MUC7Columns/MUC7.NE.training.sentences.columns.gold"
		};
		String[] stanfordFiles={
				"MUC7/MUC7.NE.dryrun.sentences.stanford.tagged",
				"MUC7/MUC7.NE.formalrun.sentences.stanford.tagged",
				"MUC7/MUC7.NE.training.sentences.stanford.tagged"
		};
		for(int i=0;i<goldFiles.length;i++)
			reportPerformanceStanfordTagger(goldPath+"/"+goldFiles[i],"-c",stanfordPath+"/"+stanfordFiles[i],"-r",new String[]{"MISC"},new String[]{});		
		goldFiles=new String[]{
				"Reuters/OriginalFormat/BIO.testa",
				"Reuters/OriginalFormat/BIO.testb",
				"Reuters/OriginalFormat/BIO.train"};
		stanfordFiles= new String[]{
				"Reuters/BIO.testa.sentences.stanford.tagged",
				"Reuters/BIO.testb.sentences.stanford.tagged",				
				"Reuters/BIO.train.sentences.stanford.tagged"
		};
		for(int i=0;i<goldFiles.length;i++)
			reportPerformanceStanfordTagger(goldPath+"/"+goldFiles[i],"-c",stanfordPath+"/"+stanfordFiles[i],"-r",new String[]{},new String[]{});		
		
		//,new String[]{},new String[]{"MISC","PER","LOC","ORG"}
    }
    
    public static void reportPerformanceStanfordTagger(
    		String goldFile,String goldDataFormat,String stanfordFile,String stanfordDataFormat,
    		String[] labelsToIgnoreForEvaluation,String[] labelsToAnonymizeForEvaluation) throws Exception{
		Parameters.readConfigAndLoadExternalData("JournalConfigChunkRepBaseline/baselineBILOU.config");
		Data goldData=new Data(goldFile,goldFile,goldDataFormat,new String[0], new String[0]);
		goldData.setLabelsToIgnore(labelsToIgnoreForEvaluation);
		goldData.setLabelsToAnonymize(labelsToAnonymizeForEvaluation);
		Data stanfordData =new Data(stanfordFile,stanfordFile,stanfordDataFormat, new Vector<String>(), new Vector<String>());
		Vector<NEWord> gold=new Vector<NEWord>();
		for(int did=0;did<stanfordData.documents.size();did++) {
			for(int i=0;i<goldData.documents.elementAt(did).sentences.size();i++)
				for(int j=0;j<goldData.documents.elementAt(did).sentences.elementAt(i).size();j++)
					gold.addElement((NEWord)goldData.documents.elementAt(did).sentences.elementAt(i).get(j));

		}
		Vector<NEWord> stanford=new Vector<NEWord>();
		for(int did=0;did<stanfordData.documents.size();did++) {
			for(int i=0;i<stanfordData.documents.elementAt(did).sentences.size();i++)
				for(int j=0;j<stanfordData.documents.elementAt(did).sentences.elementAt(i).size();j++)
					stanford.addElement((NEWord)stanfordData.documents.elementAt(did).sentences.elementAt(i).get(j));
		}
		int goldId=0;
		for(int stanfordId=0;stanfordId<stanford.size();stanfordId++){
			String s1=stanford.elementAt(stanfordId).form;
			String s2=gold.elementAt(goldId).form;
			gold.elementAt(goldId).neTypeLevel1=gold.elementAt(goldId).neTypeLevel2=stanford.elementAt(stanfordId).neLabel;
			while(!s1.equals(s2)&&s2.startsWith(s1)){
				stanfordId++;
				s1+=stanford.elementAt(stanfordId).form;
			}
			if(!s1.replace("`", "'").equals(s2.replace("`", "'")))
				throw new Exception("Failed string matching: "+s1+"/"+s2);
			goldId++;
			//System.out.println(s1+"\t/\t"+s2);
		}
		if(goldId!=gold.size())
			throw new Exception("Didn't reach the end of the gold data!!!");
		Vector<Data> v=new Vector<Data>();
		LinkedVector hugeSentence = new LinkedVector();
		for(int i=0;i<gold.size();i++)
			hugeSentence.add(gold.elementAt(i));
		Vector<LinkedVector> vv = new Vector<LinkedVector>();
		vv.addElement(hugeSentence);
		NERDocument doc = new NERDocument(vv, "test");
		Data data = new Data(doc);
		v.addElement(data);
		NETesterMultiDataset.printAllTestResultsAsOneDataset(v, false);
    }
    	
    public static void tagDataWithStanford() throws IOException {
    	String s="Good afternoon Rajat Raina, how are you today?\n I am German. I go to school at Stanford University, which is located in California. \n I'm California-based, but I play for Real Madrid.";
        System.out.println("\n------------\n"+tagWithStanfordTagger(s));
        
		String inPath="Data/RawData";
		String[] inFiles={
				"MUC7/MUC7.NE.dryrun.sentences.raw",
				"MUC7/MUC7.NE.formalrun.sentences.raw",
				"MUC7/MUC7.NE.training.sentences.raw",
				"Reuters/BIO.testa.sentences.raw",
				"Reuters/BIO.testb.sentences.raw",				
				"Reuters/BIO.train.sentences.raw"
		};

		String outPath="Data/TaggedData";
		String[] outFiles={
				"MUC7/MUC7.NE.dryrun.sentences.stanford.tagged",
				"MUC7/MUC7.NE.formalrun.sentences.stanford.tagged",
				"MUC7/MUC7.NE.training.sentences.stanford.tagged",
				"Reuters/BIO.testa.sentences.stanford.tagged",
				"Reuters/BIO.testb.sentences.stanford.tagged",				
				"Reuters/BIO.train.sentences.stanford.tagged"
		};
        for(int i=0;i<inFiles.length;i++){
        	System.out.println("Tagging"+inPath+"/"+inFiles[i]);
        	tagFile(inPath+"/"+inFiles[i], outPath+"/"+outFiles[i], false);
        }
        
                
        for(int i=1;i<=20;i++){
        	System.out.println("Tagging"+"Data/RawData/WebpagesOriginal/"+i+".txt");
        	tagFile("Data/RawData/WebpagesOriginal/"+i, "Data/TaggedData/Webpages/"+i+".stanford.tagged", false);
        }
        
    }
    
    public static String tagWithStanfordTagger(String s){
        String serializedClassifier = "StanfordNerModels/ner-eng-ie.crf-4-conll-distsim.ser.gz";      
        AbstractSequenceClassifier classifier = CRFClassifier.getClassifierNoExceptions(serializedClassifier);

         
        String tagged=classifier.testStringInlineXML(s.replace("'", "`"));//the other quote ', causes the Stanford Tagger to replicate tokens sometimes.
        tagged=stanfordXmlTags2Brackets(tagged);
                
        return tagged;	
    }
    
    public static void tagFile(String inFile,String outFile,boolean removeNewlineBreaks){
    	InFile in=new InFile(inFile);
    	StringBuffer buf=new StringBuffer();
    	String line=in.readLine();
    	while(line!=null){
    		buf.append(line);
    		if(!removeNewlineBreaks)
    			buf.append("\n");
    		else
    			buf.append(" ");
    		line=in.readLine();
    	}
    	in.close();
    	OutFile out=new OutFile(outFile);
    	out.println(tagWithStanfordTagger(buf.toString()));
    	out.close();
    }

	private static String stanfordXmlTags2Brackets(String taggedString) {
		String s=taggedString.replace("<LOCATION>", " [LOC ");
		s=s.replace("<ORGANIZATION>", " [ORG ");
		s=s.replace("<PERSON>", " [PER ");
		s=s.replace("<MISC>", " [MISC ");

		s=s.replace("</LOCATION>", " ] ");
		s=s.replace("</ORGANIZATION>", " ] ");
		s=s.replace("</PERSON>", " ] ");
		s=s.replace("</MISC>", " ] ");
		return s;
	}
	

}
