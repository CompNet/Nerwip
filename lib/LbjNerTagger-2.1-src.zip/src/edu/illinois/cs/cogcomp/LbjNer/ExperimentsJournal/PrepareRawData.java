package edu.illinois.cs.cogcomp.LbjNer.ExperimentsJournal;

import java.util.Vector;

import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Parameters;
import edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData.PlainTextWriter;
import edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData.TaggedDataReader;

public class PrepareRawData {
	/*
	 * Do not mess with the webpages! They are taken from the web and whatever they look like- they're supposed to look like that!!!
	 */
	public static void main(String[] args) throws Exception{
		String inPath="Data/GoldData/";
		String[] inFiles={
				"MUC7Columns/MUC7.NE.dryrun.sentences.columns.gold",
				"MUC7Columns/MUC7.NE.formalrun.sentences.columns.gold",
				"MUC7Columns/MUC7.NE.training.sentences.columns.gold",
				"Reuters/OriginalFormat/BIO.testa",
				"Reuters/OriginalFormat/BIO.testb",
				"Reuters/OriginalFormat/BIO.train"};
		String outPath="Data/RawData";
		String[] outFiles={
				"MUC7/MUC7.NE.dryrun.sentences.raw",
				"MUC7/MUC7.NE.formalrun.sentences.raw",
				"MUC7/MUC7.NE.training.sentences.raw",
				"Reuters/BIO.testa.sentences.raw",
				"Reuters/BIO.testb.sentences.raw",				
				"Reuters/BIO.train.sentences.raw"
		};
		for(int i=0;i<inFiles.length;i++)
			stripColumnTags(inPath, inFiles[i], outPath, outFiles[i]);
	}

	public static void stripColumnTags(String inPath,String inFile,String outPath,String outFile) throws Exception{
		Parameters.readConfigAndLoadExternalData("JournalConfigChunkRepBaseline/baselineBILOU.config");
		Data data = new Data(inPath+"/"+inFile,inFile, "-c", new Vector<String>(), new Vector<String>());
		PlainTextWriter.write(data, outPath+"/"+outFile);
	}
}
