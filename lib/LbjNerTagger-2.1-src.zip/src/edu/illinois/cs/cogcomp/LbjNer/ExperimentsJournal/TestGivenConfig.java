package edu.illinois.cs.cogcomp.LbjNer.ExperimentsJournal;

import java.util.Vector; 

import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.ExpressiveFeaturesAnnotator;
import LBJ2.classify.Classifier;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel1;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel2;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NETesterMultiDataset;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Parameters;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;

public class TestGivenConfig {
	public static Vector<Data> readOutOfDomainTestData() throws Exception{
		Vector<Data> res=new Vector<Data>();
/*		Data data = new Data("../../Data/GoldData/MUC7Columns/MUC7.NE.formalrun.sentences.columns.gold","muc7formal", "-c",new String[]{"MISC"},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(data.sentences);
		res.addElement(data);
		data=new Data("../../Data/GoldData/MUC7Columns/MUC7.NE.dryrun.sentences.columns.gold", "muc7dry","-c",new String[]{"MISC"},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(data.sentences);
		res.addElement(data);
		data=new Data("../../Data/GoldData/MUC7Columns/MUC7.NE.training.sentences.columns.gold", "muc7train","-c",new String[]{"MISC"},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(data.sentences);
		res.addElement(data);
		data=new Data("../../Data/GoldData/WebpagesColumns/","web", "-c",new String[]{},new String[]{"MISC","PER","LOC","ORG"});
		ExpressiveFeaturesAnnotator.annotate(data.sentences);
		res.addElement(data);*/
		return res;
	}
	public static Vector<Data> readCoNLLTestData() throws Exception{
		Vector<Data> res=new Vector<Data>();
		Data data=new Data("../../Data/GoldData/Reuters/ColumnFormatDocumentsSplit/Test", "conll03test","-c",new String[]{},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(data);
		res.addElement(data);
		return res;		
	}
	public static Vector<Data> readCoNLLDevData() throws Exception{
		Vector<Data> res=new Vector<Data>();
		Data data=new Data("../../Data/GoldData/Reuters/ColumnFormatDocumentsSplit/Dev", "conll03dev","-c",new String[]{},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(data);
		res.addElement(data);
		return res;		
	}
	public static Vector<Data> readCoNLLTrainData() throws Exception{
		Vector<Data> res=new Vector<Data>();
		Data data=new Data("../../Data/GoldData/Reuters/ColumnFormatDocumentsSplit/Train","conll03train", "-c",new String[]{},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(data);
		res.addElement(data);
		return res;		
	}

	public static void main(String[] args) throws Exception{
		String configFile=args[0];
		Parameters.readConfigAndLoadExternalData(configFile);
		Vector<Data> inDomainTest=readCoNLLTestData();
		Vector<Data> inDomainDev=readCoNLLDevData();
		//Vector<Data> inDomainTrain=readCoNLLTrainData();
		Vector<Data> outOfDomainData=readOutOfDomainTestData();
		//tuning on the in-domain data (CoNLL test)
		
		//System.out.println("-------------------------------------------------------------");
		//System.out.println("------Training with tuning on CoNLL Development dataset       ------");
		//System.out.println("-------------------------------------------------------------");
		//LearningCurveMultiDataset.getLearningCurve(inDomainDev,inDomainTrain,-1);
		//System.out.println("-------------------------------------------------------------");
		//System.out.println("------PERFORMANCE WHEN TUNING ON THE CONLL DEVELOPMENT SET    ------");
		//System.out.println("-------------------------------------------------------------");
		Parameters.loadClassifierModels(ParametersForLbjCode.currentParameters);
		NETaggerLevel1 taggerLevel1=(NETaggerLevel1)ParametersForLbjCode.currentParameters.taggerLevel1;
		NETaggerLevel2 taggerLevel2=(NETaggerLevel2)ParametersForLbjCode.currentParameters.taggerLevel2;

		NETesterMultiDataset.printTestResultsByDataset(inDomainTest,taggerLevel1,taggerLevel2,true);	
		NETesterMultiDataset.printTestResultsByDataset(inDomainDev,taggerLevel1,taggerLevel2,true);
		NETesterMultiDataset.printTestResultsByDataset(outOfDomainData,taggerLevel1,taggerLevel2,true);
		NETesterMultiDataset.printAllTestResultsAsOneDataset(outOfDomainData,taggerLevel1,taggerLevel2,true);		
	}
}
