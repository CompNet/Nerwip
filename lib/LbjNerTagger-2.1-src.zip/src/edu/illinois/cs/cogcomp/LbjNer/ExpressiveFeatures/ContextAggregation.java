package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import java.util.Hashtable;

import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;

public class ContextAggregation {

	/*
	 * Make sure to call this function as a last possible function:
	 * this function already assumes that the data was annotated with dictionaries etc.
	 */
	public static void annotate(NEWord word){
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("aggregateContext")||ParametersForLbjCode.currentParameters.featuresToUse.containsKey("aggregateGazetteerMatches"))
		{  
			int i=0;
			NEWord w = word, last = (NEWord)word.nextIgnoreSentenceBoundary;

			Hashtable<NEWord, Boolean> takenWords=new Hashtable<NEWord, Boolean>();
			takenWords.put(word, true);
			NEWord temp=word.nextIgnoreSentenceBoundary;
			int k=0;
			while(temp!=null&&k<3)
			    {
				takenWords.put(temp, true);
				temp=temp.nextIgnoreSentenceBoundary;
				k++;
			    }
			temp=word.previousIgnoreSentenceBoundary;
			k=0;
			while(temp!=null&&k<3)
			    {
				takenWords.put(temp, true);
				temp=temp.previousIgnoreSentenceBoundary;
				k++;
			    }



			for (i = 0; i < 200 && last != null; ++i) last = (NEWord) last.nextIgnoreSentenceBoundary;
			for (i = 0; i > -200 && w.previousIgnoreSentenceBoundary != null; --i) w = (NEWord) w.previousIgnoreSentenceBoundary;

			do{
				if(w.form.equalsIgnoreCase(word.form)&&Character.isUpperCase(word.form.charAt(0))&&
						Character.isLowerCase(w.form.charAt(0)))
					updateFeatureCounts(word,"appearsDownCased");
				if(w.form.equalsIgnoreCase(word.form)&&
						Character.isUpperCase(w.form.charAt(0))&&
						Character.isUpperCase(word.form.charAt(0))&&
						word!=w)
				{
				    //if((!takenWords.containsKey(w))&&ParametersForLbjCode.currentParameters.featuresToUse.containsKey("aggregateGazetteerMatches")){
					//System.out.println(w.matchedMultiTokenGazEntries.size());
					//for(int j=0;j<w.matchedMultiTokenGazEntries.size();j++)
					 //   updateFeatureCounts(word,w.matchedMultiTokenGazEntryTypes.elementAt(j));
                     //                   for(int j=0;j<w.matchedMultiTokenGazEntryTypesIgnoreCase.size();j++)
					  //  updateFeatureCounts(word,w.matchedMultiTokenGazEntryTypesIgnoreCase.elementAt(j));
				    //}
				    if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("aggregateContext"))
					{
						if(w.previous==null)
							updateFeatureCounts(word,"appearancesUpperStartSentence");
						if(w.previous!=null)
							if(((NEWord)w.previous).form.endsWith("."))
								updateFeatureCounts(word,"appearancesUpperStartSentence");
						if(w.previous!=null&&(!((NEWord)w.previous).form.endsWith(".")))
							updateFeatureCounts(word,"appearancesUpperMiddleSentence");

						NEWord wtemp = w, lastTemp = (NEWord)w.nextIgnoreSentenceBoundary;
						int j=0;
						for (j = 0; j < 2 && lastTemp != null; ++j) lastTemp = (NEWord) lastTemp.nextIgnoreSentenceBoundary;
						for (j = 0; j > -2 && wtemp.previousIgnoreSentenceBoundary != null; --j) wtemp = (NEWord) wtemp.previousIgnoreSentenceBoundary;
						do{
							updateFeatureCounts(word,"context:"+j+":"+wtemp.form);		 				
							if(BrownClusters.resources!=null){
								String[] brownPaths=BrownClusters.getPrefixes(wtemp);
								//for(int k=0;k<brownPaths.length;k++)
								//updateFeatureCounts(word,"contextPath:"+j+":"+brownPaths[k]);
								if(brownPaths.length>0)
									updateFeatureCounts(word,"contextPath:"+j+":"+brownPaths[0]);
							}
							wtemp = (NEWord) wtemp.nextIgnoreSentenceBoundary; 
							j++;
						}while(wtemp != lastTemp);
					}
				}
				w = (NEWord) w.nextIgnoreSentenceBoundary; 
			}while(w != last);
		}
	}
	private static void updateFeatureCounts(NEWord w,String feature){
		if(w.nonLocalFeatures.containsKey(feature)){
			int i=w.nonLocalFeatures.get(feature)+1;
			w.nonLocalFeatures.remove(feature);
			w.nonLocalFeatures.put(feature, i);
		}
		else
			w.nonLocalFeatures.put(feature, 1);
	}

}
