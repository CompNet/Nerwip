package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import java.util.Vector; 

import edu.illinois.cs.cogcomp.LbjNer.InferenceMethods.Decoder;
import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel1;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel2;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NETesterMultiDataset;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.TextChunkRepresentationManager;

public class ExpressiveFeaturesAnnotator {

	/*
	 * Do not worry about the brown clusters and word embeddings, 
	 * this stuff is added on the fly in the .lbj feature generators... 
	 */
	public static void annotate(Data data) throws Exception{

		//System.out.println("Annotating the data with expressive features...");

	    //annotating with Linkability features - this must be before the title case normalization and before gazetteers matching!!!!;
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("Linkability")){
			//System.out.println("Annotating the data with Linkability features");
			for(int docid=0;docid<data.documents.size();docid++){
				Vector<LinkedVector> res=data.documents.elementAt(docid).sentences;
				for(int i=0;i<res.size();i++){
					for(int j=0;j<res.elementAt(i).size();j++)
						WikipediaLinkability.annotate((NEWord)res.elementAt(i).get(j));
				}
			}
		}
	
		/*
		 * must be after the linkability has been initialized!!!
		 */
	    if(ParametersForLbjCode.currentParameters.normalizeTitleText){
	    	//System.out.println("Normalizing text case ...");
			TitleTextNormalizer.normalizeCase(data);
	    }

		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("BrownClusterPaths")){
			//System.out.println("Brown clusters OOV statistics:");
			BrownClusters.printOovData(data);
		}		
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("WordEmbeddings")){
			//System.out.println("Word Embeddings OOV statistics:");
			WordEmbeddings.printOovData(data);
		}
	    //annotating with Gazzetteers;
		if(ParametersForLbjCode.currentParameters.featuresToUse!=null){
  			if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("GazetteersFeatures")){
  				//System.out.println("Annotating the data with gazetteers");
  				for(int docid=0;docid<data.documents.size();docid++)
  				{
  					Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences;
  					for(int i=0;i<sentences.size();i++){
  						LinkedVector vector=sentences.elementAt(i);
  						for(int j=0;j<vector.size();j++)
  							Gazzetteers.annotate((NEWord)vector.get(j));
  					}
  				}
  			}
		}
	    //annotating the nonlocal features;
		//System.out.println("Annotating the data with context-aggregation features (if necessary)");
			for(int docid=0;docid<data.documents.size();docid++)
				{
					Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences;
					for(int i=0;i<sentences.size();i++){
						LinkedVector vector=sentences.elementAt(i);
						for(int j=0;j<vector.size();j++)
				    		ContextAggregation.annotate((NEWord)vector.get(j));
					}
				}

	    /*
	     * Note that this piece of code must be the last!!!
	     * Here we are adding as features the predictions of the aux models
	     */
	    for(int i=0;i<ParametersForLbjCode.currentParameters.auxiliaryModels.size();i++){
	    	ParametersForLbjCode currentModel=ParametersForLbjCode.currentParameters;
	    	ParametersForLbjCode.currentParameters=ParametersForLbjCode.currentParameters.auxiliaryModels.elementAt(i);
	    	Decoder.annotateDataBIO(data, (NETaggerLevel1)ParametersForLbjCode.currentParameters.taggerLevel1,(NETaggerLevel2) ParametersForLbjCode.currentParameters.taggerLevel2);
			Vector<Data> v=new Vector<Data>();
			v.addElement(data);
			//System.out.println("--------------------------------------------------");
			//System.out.println("The performance of the aux model "+ParametersForLbjCode.currentParameters.configFilename+" is: ");
			NETesterMultiDataset.printAllTestResultsAsOneDataset(v, false);
			//System.out.println("--------------------------------------------------");
			TextChunkRepresentationManager.changeChunkRepresentation(
					TextChunkRepresentationManager.EncodingScheme.BIO, 
					TextChunkRepresentationManager.EncodingScheme.BILOU, 
					data, NEWord.LabelToLookAt.PredictionLevel1Tagger);
			TextChunkRepresentationManager.changeChunkRepresentation(
					TextChunkRepresentationManager.EncodingScheme.BIO, 
					TextChunkRepresentationManager.EncodingScheme.BILOU, 
					data, NEWord.LabelToLookAt.PredictionLevel2Tagger);
			addAuxiliaryClassifierFeatures(data,"aux_model_"+i);
						
			ParametersForLbjCode.currentParameters=currentModel;
	    }
	   
	    
		//System.out.println("Done Annotating the data with expressive features...");
   }
	
	private static void addAuxiliaryClassifierFeatures(Data data,String auxModelId){
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for(int j=0;j<sentences.size();j++)
				for(int k=0;k<sentences.elementAt(j).size();k++){
					NEWord w=(NEWord)sentences.elementAt(j).get(k);
					NEWord.DiscreteFeature f=new NEWord.DiscreteFeature();
					f.featureGroupName=auxModelId;
					f.featureValue=w.neTypeLevel2;
					f.useWithinTokenWindow=true;
					w.generatedDiscreteFeaturesNonConjunctive.addElement(f);
					//	System.out.println("Adding feature: "+w.form+"\t"+auxModelId+"\t"+w.neTypeLevel2);
			}
		}
	}
}
