package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import edu.illinois.cs.cogcomp.LbjNer.GazetteerIndexManager.GazetteerIndexSearcher;
import edu.illinois.cs.cogcomp.LbjNer.GazetteerIndexManager.GazetteerIndexSearcher.GazetteersAnnotation;
import edu.illinois.cs.cogcomp.LbjNer.GazetteerIndexManager.IndexGazetteers.AnalyzerTypes;
import edu.illinois.cs.cogcomp.LbjNer.IO.*; 
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.MyString;


import java.util.*;
import java.io.*; 

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.queryParser.ParseException;

public class Gazzetteers{
	public static Vector<String> dictNames=new Vector<String>();
	public  static Vector<Hashtable<String,Boolean>> dictionaries=null;
	public static Vector<Hashtable<String, Boolean>> dictionariesIgnoreCase = null;
	public static Vector<Hashtable<String, Boolean>> dictionariesOneWordIgnorePunctuation = null;
	// public static GazetteerIndexSearcher gazetteers = null;
	// public static GazetteerIndexSearcher gazetteersIC = null;

	public static void init(String pathToDictionaries
			/*String pathToDictionariesCaseSensitive, String pathToDictionariesIgnoreCase*/) throws Exception{
		dictNames=new Vector<String>();
		dictionaries=null;
		dictionariesIgnoreCase = null;
		dictionariesOneWordIgnorePunctuation = null;
		System.out.println("loading dazzetteers....");
		Vector<String> filenames=new Vector<String>();
		String[] allfiles=(new File(pathToDictionaries)).list();
		for(int i=0;i<allfiles.length;i++)
			if((new File(pathToDictionaries+"/"+allfiles[i])).isFile()){
				filenames.addElement(pathToDictionaries+"/"+allfiles[i]);
				dictNames.addElement(allfiles[i]);
			}
		dictionaries=new Vector<Hashtable<String,Boolean>>(filenames.size());
		dictionariesIgnoreCase=new Vector<Hashtable<String,Boolean>>(filenames.size());
		dictionariesOneWordIgnorePunctuation=new Vector<Hashtable<String,Boolean>>(filenames.size());
		
		for(int i=0;i<filenames.size();i++)
		{
			System.out.println("\tloading gazzetteer:...."+filenames.elementAt(i));
			dictionaries.addElement(new Hashtable<String,Boolean>());
			dictionariesIgnoreCase.addElement(new Hashtable<String,Boolean>());
			dictionariesOneWordIgnorePunctuation.addElement(new Hashtable<String,Boolean>());
			InFile in=new InFile(filenames.elementAt(i));
			String line=in.readLine();
			while(line!=null){
				dictionaries.elementAt(i).put(line,true);
				if((!line.equalsIgnoreCase("in"))&&(!line.equalsIgnoreCase("on"))&&(!line.equalsIgnoreCase("us"))&&(!line.equalsIgnoreCase("or"))&&(!line.equalsIgnoreCase("am")))
					dictionariesIgnoreCase.elementAt(i).put(line.toLowerCase(),true);
				StringTokenizer st=new StringTokenizer(line," ");
				while(st.hasMoreTokens()){
					String s=MyString.cleanPunctuation(st.nextToken());
					if(s.length()>=5&&Character.isUpperCase(s.charAt(0))){
						dictionariesOneWordIgnorePunctuation.elementAt(i).put(s,true);
					}
				}
				line=in.readLine();
			}
			in.close();
		}
		System.out.println("found "+dictionaries.size()+" gazetteers");
		//gazetteers = new GazetteerIndexSearcher(pathToDictionariesCaseSensitive,true);
		//gazetteersIC = new GazetteerIndexSearcher(pathToDictionariesIgnoreCase,true);
	}
	
	public static void annotate(NEWord w) throws CorruptIndexException, IOException, ParseException
	{
		if(w.gazetteers==null)
			w.gazetteers=new Vector<String>();
		
/*	       	for(int j=0;j<dictionaries.size();j++)
		{
			if(dictionariesOneWordIgnorePunctuation.elementAt(j).containsKey(MyString.cleanPunctuation(w.form))){
			    //BE CAREFULE WITH THE "PART-" PREFIX! IT'S USED ELSEWHERE!!!
				w.gazetteers.addElement("Part-"+dictNames.elementAt(j));
			}
		}*/
	       
		NEWord start=w;
		String prev1 = null;
		String prev2 = null;
		if((NEWord)w.previous!=null) {
			prev1 = ((NEWord)w.previous).form;
			if(((NEWord)((NEWord)w.previous).previous)!=null)
				prev2 = ((NEWord)((NEWord)w.previous).previous).form;
		}
		NEWord endWord=(NEWord)(w.next);
		String expression=w.form;
		boolean changeEnd=true;
		if(w.normalizedMostLinkableExpression!=null){
			if(w.gazetteers==null)
				w.gazetteers=new Vector<String>();
			/*if(w.normalizedForm!=null&&!w.normalizedForm.equalsIgnoreCase(w.form)) {
				GazetteersAnnotation matches = gazetteers.getGazetteerAnnotations(w.normalizedMostLinkableExpression, AnalyzerTypes.ExactMatch);
				for (int i=0; i<matches.categ.size(); i++) 
					w.gazetteers.addElement("Normalized_Expression_Gaz_Match"+matches.categ.elementAt(i));
				matches = gazetteersIC.getGazetteerAnnotations(w.normalizedMostLinkableExpression, AnalyzerTypes.ExactMatch);
				for (int i=0; i<matches.categ.size(); i++) 
					w.gazetteers.addElement("Normalized_Expression_Gaz_Match_IC"+matches.categ.elementAt(i));
			}*/
			for(int j=0;j<dictionaries.size();j++)
				if(dictionaries.elementAt(j).containsKey(w.normalizedMostLinkableExpression)){
					if(w.normalizedForm!=null&&!w.normalizedForm.equalsIgnoreCase(w.form))
						w.gazetteers.addElement("Normalized_Expression_Gaz_Match(*)"+dictNames.elementAt(j));
					else
						w.gazetteers.addElement("Normalized_Expression_Gaz_Match"+dictNames.elementAt(j));
				}
		}
		for(int i=0;i<5&&changeEnd;i++)
		{
			String next1 = null;
			String next2 = null;
			if(endWord!=null) {
				next1=endWord.form;
				if(endWord.next!=null)
					next2=((NEWord)endWord.next).form;
			}
			
			changeEnd=false;
			/*GazetteersAnnotation matches = new GazetteersAnnotation();
			matches = gazetteers.getGazetteerAnnotations(expression, AnalyzerTypes.ExactMatch);
			//if(matches.categ.size()>0){
			//	System.out.print("Matches for "+expression+" : ");
			//	for(int j=0;j<matches.categ.size();j++)
			//		System.out.print(" "+matches.categ.elementAt(j));
			//	System.out.println(" gold label = "+w.neLabel);
			//}
			NEWord temp=start;
			for (int j=0; j<matches.categ.size(); j++) { 
				if(i==0){
					updateWordGazetteerInfo(temp,"U-"+matches.categ.elementAt(j), prev1, prev2, next1, next2);
				} else {
					int loc=0;
					while(temp!=endWord){
						if(temp.gazetteers==null)
							temp.gazetteers=new Vector<String>();
						if(loc==0)
							updateWordGazetteerInfo(temp,"B-"+matches.categ.elementAt(j), prev1, prev2, next1, next2);
						if(loc>0&&loc<i)
							updateWordGazetteerInfo(temp,"I-"+matches.categ.elementAt(j), prev1, prev2, next1, next2);
						if(loc==i)
							updateWordGazetteerInfo(temp,"L-"+matches.categ.elementAt(j), prev1, prev2, next1, next2);
						temp=(NEWord)temp.next;
						loc++;
					}
				}
			}
			matches = gazetteersIC.getGazetteerAnnotations(expression, AnalyzerTypes.ExactMatch);
			temp=start;
			for (int j=0; j<matches.categ.size(); j++) { 
				if(i==0){
					updateWordGazetteerInfo(temp,"U-"+matches.categ.elementAt(j)+"_IC", prev1, prev2, next1, next2);
				} else {
					int loc=0;
					while(temp!=endWord){
						if(temp.gazetteers==null)
							temp.gazetteers=new Vector<String>();
						if(loc==0)
							updateWordGazetteerInfo(temp,"B-"+matches.categ.elementAt(j)+"_IC", prev1, prev2, next1, next2);
						if(loc>0&&loc<i)
							updateWordGazetteerInfo(temp,"I-"+matches.categ.elementAt(j)+"_IC", prev1, prev2, next1, next2);
						if(loc==i)
							updateWordGazetteerInfo(temp,"L-"+matches.categ.elementAt(j)+"_IC", prev1, prev2, next1, next2);
						temp=(NEWord)temp.next;
						loc++;
					}
				}
			}*/

			for(int j=0;j<dictionaries.size();j++)
			{
				if(dictionaries.elementAt(j).containsKey(expression))
				{
					NEWord temp=start;
					if(temp.gazetteers==null)
						temp.gazetteers=new Vector<String>();
					if(i==0){
						updateWordGazetteerInfo(temp,"U-"+dictNames.elementAt(j), prev1, prev2, next1, next2);
					}
					else{
						int loc=0;
						while(temp!=endWord){
							if(temp.gazetteers==null){
								temp.gazetteers=new Vector<String>();
							}
							if(loc==0){
								updateWordGazetteerInfo(temp,"B-"+dictNames.elementAt(j), prev1, prev2, next1, next2);
							}
							if(loc>0&&loc<i){
								updateWordGazetteerInfo(temp,"I-"+dictNames.elementAt(j), prev1, prev2, next1, next2);
							}
							if(loc==i){
								updateWordGazetteerInfo(temp,"L-"+dictNames.elementAt(j), prev1, prev2, next1, next2);
							}
							temp=(NEWord)temp.next;
							loc++;
						}
					}
				}
				if(dictionariesIgnoreCase.elementAt(j).containsKey(expression.toLowerCase()))
				{
					NEWord temp=start;
					if(temp.gazetteers==null)
						temp.gazetteers=new Vector<String>();
					if(i==0){
						updateWordGazetteerInfo(temp,"U-"+dictNames.elementAt(j)+"(IC)", prev1, prev2, next1, next2);
					}
					else{
						int loc=0;
						while(temp!=endWord){
							if(temp.gazetteers==null){
								temp.gazetteers=new Vector<String>();
							}
							if(loc==0){
								updateWordGazetteerInfo(temp,"B-"+dictNames.elementAt(j)+"(IC)", prev1, prev2, next1, next2);
							}
							if(loc>0&&loc<i){
								updateWordGazetteerInfo(temp,"I-"+dictNames.elementAt(j)+"(IC)", prev1, prev2, next1, next2);
							}
							if(loc==i){
								updateWordGazetteerInfo(temp,"L-"+dictNames.elementAt(j)+"(IC)", prev1, prev2, next1, next2);
							}
							temp=(NEWord)temp.next;
							loc++;
						}
					}
				}
			} //dictionaries
			if(endWord!=null)
			{
				expression+=" "+endWord.form;
				endWord=(NEWord)endWord.next;
				changeEnd=true;
			}
		} //i
	}
	
	private static void updateWordGazetteerInfo(NEWord w, String gazString, String prev1, String prev2, String next1, String next2) {
		w.gazetteers.addElement(gazString);
		 //if(next1!=null) {
			//w.gazetteers.addElement(gazString+"next1="+next1);
		 //}
		//if(next2!=null)
		//	w.gazetteers.addElement(gazString+"next2="+next2);
		//if(prev1!=null) {
			//w.gazetteers.addElement(gazString+"prev1="+prev1);
		//}
		//if(prev2!=null)
		//	w.gazetteers.addElement(gazString+"prev2="+prev2);
	}
}
