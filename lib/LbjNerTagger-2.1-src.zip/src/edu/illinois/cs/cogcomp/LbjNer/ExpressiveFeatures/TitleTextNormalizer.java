package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

 import java.util.HashMap; 
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.IO.InFile;
import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Parameters;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.CharacteristicWords;


/*
 * NOTE- IMPORTANT!!!!
 * FOR THIS CLASS, WE HAVE TO RESPECT THE DOCUMENT BOUNDARIES. PLEASE DO NOT
 * READ ALL THE DOCUMENTS AS A SINGLE DATA COLLECTION!!!
 * 
 * This class will "fix" the all-cap sentneces in the titles. If the word is allCAP in a sentence, 
 * I'll see if it appears as capitilized in non-sentence start position within the text. If it does,
 * I use that instance from within the document. Otherwise, I'll lowercase the fucker
 */
public class TitleTextNormalizer {
	public static final int WindowSize=500;//the size of the window to be used for text normalization. if we see a lowercased word in 500 word proximity from an all-caps title word, we lowercase it.
	public static String pathToBrownClusterForWordFrequencies=null;
	public static HashMap<String,String> lowercasedToNormalizedTokensMap=null; 
	
	public static void init(){
		if(!ParametersForLbjCode.currentParameters.normalizeTitleText)
			return;
		InFile in=new InFile(pathToBrownClusterForWordFrequencies);
		String line=in.readLine();
		lowercasedToNormalizedTokensMap=new HashMap<String,String>();
		HashMap<String,Integer> normalizedTokenCounts=new HashMap<String, Integer>();
		while(line!=null){
			StringTokenizer st=new StringTokenizer(line);
			String path=st.nextToken();
			String word=st.nextToken();
			int occ=Integer.parseInt(st.nextToken());
			if(lowercasedToNormalizedTokensMap.containsKey(word.toLowerCase())){
				String normalizedWord=lowercasedToNormalizedTokensMap.get(word.toLowerCase());
				int prevCount=normalizedTokenCounts.get(normalizedWord);
				if(prevCount<occ){
					lowercasedToNormalizedTokensMap.put(word.toLowerCase(), word);
					normalizedTokenCounts.put(word, occ);					
				}
			}
			else{
				lowercasedToNormalizedTokensMap.put(word.toLowerCase(), word);
				normalizedTokenCounts.put(word, occ);
			}
			line=in.readLine();
		}

	}
	
	public static void normalizeCaseData(Vector<Data> data){
		if(!ParametersForLbjCode.currentParameters.normalizeTitleText)
			return;
		if(lowercasedToNormalizedTokensMap==null)
			init();
		for(int did=0;did<data.size();did++)
			normalizeCase(data.elementAt(did));
	}

	
	public static void normalizeCase(Data data){
		if(!ParametersForLbjCode.currentParameters.normalizeTitleText)
			return;
		if(lowercasedToNormalizedTokensMap==null)
			init();		
		//Below are the words that we'll want to normalize. We'll fill in the hashtable below with the
		//words that appear in non-mixed case sentences. For CoNLL data, we basically fill the hashmap
		//below with words from the titles
		HashMap<NEWord,Boolean> wordsToNormalize=new HashMap<NEWord, Boolean>();
		HashMap<NEWord,Boolean> wordsInMixedCaseSentences=new HashMap<NEWord, Boolean>();
		
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences=data.documents.elementAt(docid).sentences;
			for(int i=0;i<sentences.size();i++){
				if(mixedCase(sentences.elementAt(i))){
					//note that I exclude here the first word of a sentence on purpose!!!
					for(int j=1;j<sentences.elementAt(i).size();j++)
						wordsInMixedCaseSentences.put((NEWord)sentences.elementAt(i).get(j),true);
				}
				else{
					// these words - in all caps or all-lowercase sentences are subject for normalization
					for(int j=0;j<sentences.elementAt(i).size();j++)
						wordsToNormalize.put(((NEWord)sentences.elementAt(i).get(j)), true);
				}
			}
		}
		
		for(Iterator<NEWord> iter=wordsToNormalize.keySet().iterator();iter.hasNext();)
		{
			NEWord w=iter.next();
			w.isCaseNormalized=true;
			if(w.form.equals("A")){
				w.normalizedForm="a";
				w.form=w.normalizedForm;
			}else{
				//the hashmap below remembers the words that appeared lowercased in the document
				HashMap<String,Boolean> lowecasedForms=new HashMap<String, Boolean>();
				//note that this MUST EXCLUDE the words that start a sentence!!!!
				//for each mixed-case string in mixed-case sentences, such as "McLaren" 
				//we're keeping all the ways to write them out. E.g.   McLaren MCLAREN etc. 
				//Eventually, we'll normalize to the most common spelling in the document 
				HashMap<String,CharacteristicWords> uppercasedFormsInMixedCaseNonSentenceStart=new HashMap<String, CharacteristicWords>();
				getNeighborhoodWordStatistics(w,wordsInMixedCaseSentences,uppercasedFormsInMixedCaseNonSentenceStart,lowecasedForms);
				//w.originalForm=w.form; // this can cauze all sorts of problems!!!
				String key=w.form.toLowerCase();
				if(w.normalizedMostLinkableExpression==null){
					if(lowecasedForms.containsKey(key)){
						w.normalizedForm=key;
					}
					else{
						if(uppercasedFormsInMixedCaseNonSentenceStart.containsKey(key))
							w.normalizedForm=uppercasedFormsInMixedCaseNonSentenceStart.get(key).topWords.elementAt(0);
						else{
							if(lowercasedToNormalizedTokensMap.containsKey(w.form.toLowerCase()))
								w.normalizedForm=lowercasedToNormalizedTokensMap.get(w.form.toLowerCase());
							else
								w.normalizedForm=w.form;//.toLowerCase();
						}
					}
				}else{
					int start=w.normalizedMostLinkableExpression.toLowerCase().indexOf(w.form.toLowerCase());
					String normalizedForm=w.normalizedMostLinkableExpression.substring(start,start+w.form.length());
					if(Character.isLowerCase(normalizedForm.charAt(0))&&uppercasedFormsInMixedCaseNonSentenceStart.containsKey(normalizedForm.toLowerCase()))
						w.normalizedForm=uppercasedFormsInMixedCaseNonSentenceStart.get(normalizedForm.toLowerCase()).topWords.elementAt(0);
					else
						w.normalizedForm=normalizedForm;
				}
				if(w.previous==null&&Character.isLowerCase(w.normalizedForm.charAt(0)))
					w.normalizedForm=Character.toUpperCase(w.normalizedForm.charAt(0))+w.normalizedForm.substring(1);
				w.form=w.normalizedForm;
			}
		}
	}	
	
	/*
	 * the first 2 parameters must be passed.
	 * the last 2 places is where I'm keeping the answers
	 */
	public static void getNeighborhoodWordStatistics(
			NEWord word,
			HashMap<NEWord,Boolean> wordsInMixedCasedSentences,
			HashMap<String,CharacteristicWords> uppercasedFormsInMixedCaseNonSentenceStart,
			HashMap<String,Boolean> lowecasedForms)
	{
		NEWord temp=word.previousIgnoreSentenceBoundary;
		int count=0;
		while(temp!=null&&count<WindowSize){
			//we dont want to take into statistics words that begin sentences
			if(wordsInMixedCasedSentences.containsKey(temp)&&temp.previous!=null){
				String w=temp.form;
				String key=w.toLowerCase();
				if(Character.isUpperCase(w.charAt(0))){
					CharacteristicWords topSpellings=new CharacteristicWords(5);
					if(uppercasedFormsInMixedCaseNonSentenceStart.containsKey(key))
						topSpellings=uppercasedFormsInMixedCaseNonSentenceStart.get(key);
					topSpellings.addElement(w, 1);
					uppercasedFormsInMixedCaseNonSentenceStart.put(key, topSpellings);
				}
				if(Character.isLowerCase(w.charAt(0)))
					lowecasedForms.put(key, true);
			}
			count++;
			 temp=temp.previousIgnoreSentenceBoundary;
		}		
		temp=word.nextIgnoreSentenceBoundary;
		count=0;
		while(temp!=null&&count<WindowSize){
			//we dont want to take into statistics words that begin sentences
			if(wordsInMixedCasedSentences.containsKey(temp)&&temp.previous!=null){
				String w=temp.form;
				String key=w.toLowerCase();
				if(Character.isUpperCase(w.charAt(0))){
					CharacteristicWords topSpellings=new CharacteristicWords(5);
					if(uppercasedFormsInMixedCaseNonSentenceStart.containsKey(key))
						topSpellings=uppercasedFormsInMixedCaseNonSentenceStart.get(key);
					topSpellings.addElement(w, 1);
					uppercasedFormsInMixedCaseNonSentenceStart.put(key, topSpellings);
				}
				if(Character.isLowerCase(w.charAt(0)))
					lowecasedForms.put(key, true);
			}
			count++;
			 temp=temp.nextIgnoreSentenceBoundary;
		}		
	}
	
	public static boolean mixedCase(LinkedVector sentence){
		if(lowercasedToNormalizedTokensMap==null)
			init();
		boolean hasLowecaseLetters=false;
		boolean hasUppercaseLetters=false;
		for(int i=0;i<sentence.size();i++){
			String s=((NEWord)sentence.get(i)).originalForm;
			for(int j=0;j<s.length();j++){
				if(Character.isLowerCase(s.charAt(j)))
					hasLowecaseLetters =true;
				if(Character.isUpperCase(s.charAt(j)))
					hasUppercaseLetters =true;
			}
		}
		return hasLowecaseLetters&&hasUppercaseLetters;
	}
	
	public static void main(String[] args) throws Exception{
		Parameters.readConfigAndLoadExternalData("linkabilityPlusNormalizationLocalTest.config");
		Data data = new Data("Data/GoldData/Reuters/OriginalFormat/BIO.testa", "test", "-c", new String[]{},  new String[]{});

		//Vector<LinkedVector> data = TaggedDataReader.readData("Data/GoldData/MUC7Columns/MUC7.NE.formalrun.sentences.columns.gold", "-c");
		//Vector<LinkedVector> data = TaggedDataReader.readData("Data/GoldData/WebpagesColumns", "-c");
		ExpressiveFeaturesAnnotator.annotate(data);
		normalizeCase(data);
		int countFalseDownCases=0;
		int countFlaseUpCases=0;
		int totalNormalizedTokens=0;
		int allCapsSentences=0;
		double maxLinkability=0;
		
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences=data.documents.elementAt(docid).sentences;
			for(int i=0;i<sentences.size();i++){
				boolean prints=false;
				boolean isNormSentence=false;
				for(int j=0;j<sentences.elementAt(i).size();j++)
				{
					NEWord w=(NEWord)sentences.elementAt(i).get(j);
					if(w.isCaseNormalized){
						totalNormalizedTokens++;
						prints=true;
						isNormSentence=true;
						if(w.maxLinkability_IC>maxLinkability)
							maxLinkability=w.maxLinkability_IC;
						if(!w.originalForm.equals(w.form))
							System.out.println("Changed : "+w.originalForm+"-->"+w.form+"; most linkable expression: "+w.normalizedMostLinkableExpression);
						if(Character.isLowerCase(w.form.charAt(0))&&!w.originalForm.equals(w.form)&&!w.neLabel.equals("O")){
							String context=w.form;
							if(w.previous!=null)
								context=((NEWord)w.previous).form+" "+context;
							if(w.next!=null)
								context=context+" "+((NEWord)w.next).form;
							countFalseDownCases++;
							System.out.println("-------------------------BAD IDEA TO CHANGE  : "+w.originalForm+"-->"+w.form+" linkabiliy:"+w.maxLinkability_IC+" context: "+context+"; most linkable expression: "+w.normalizedMostLinkableExpression);
						}
						if(Character.isUpperCase(w.form.charAt(0))&&w.previous!=null&&w.neLabel.equals("O")){
							countFlaseUpCases++;
						}
						boolean allCaps=true;
						for(int k=0;k<w.form.length();k++)
							if(!Character.isUpperCase(w.form.charAt(k)))
								allCaps=false;
						if(allCaps)
							System.out.println("All-caps tokens left: \t"+w.form+"; most linkable expression: "+w.normalizedMostLinkableExpression);	
					}
				}
				if(prints)
					System.out.println("------------------------------------------");
				if(isNormSentence)
					allCapsSentences++;
			}
		}
		
		System.out.println("\nTotal number of false downcases : "+countFalseDownCases);
		System.out.println("Total number of false upCases : "+countFlaseUpCases);
		System.out.println("Total number of all-caps sentences: "+ allCapsSentences);
		System.out.println("Total number of case-normalized tokens: "+totalNormalizedTokens);
	}
}
