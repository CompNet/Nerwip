package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import java.util.Hashtable;
import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel2;

import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.OccurrenceCounter;

public class TwoLayerAggregationFeaturesOld {

	// ----------  THIS CLASS IS DEPRICATED
	
	/*
	public static void displayLevel1AggregationData(Vector<LinkedVector> data){
		for(int i=0;i<data.size();i++)
			for(int j=0;j<data.elementAt(i).size();j++){
				NEWord w=(NEWord)data.elementAt(i).get(j);
				System.out.println("Word: "+w.form);
				System.out.println("\t entity: "+w.entity);
				System.out.println("\t enity type: "+w.entityType);
				System.out.println("\t token in entity supertype: ");
				String[] arr=w.mostFrequentLevel1TokenInEntityType.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1TokenInEntityType.getCount(arr[k])/w.mostFrequentLevel1TokenInEntityType.totalTokens);
				System.out.println("\t supertype: ");
				arr=w.mostFrequentLevel1SuperEntityType.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1SuperEntityType.getCount(arr[k])/w.mostFrequentLevel1SuperEntityType.totalTokens);
				System.out.println("\t exact entity type: ");
				arr=w.mostFrequentLevel1ExactEntityType.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1ExactEntityType.getCount(arr[k])/w.mostFrequentLevel1ExactEntityType.totalTokens);
				System.out.println("\t token maj: ");
				arr=w.mostFrequentLevel1Prediction.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1Prediction.getCount(arr[k])/w.mostFrequentLevel1Prediction.totalTokens);
				System.out.println("\t token maj type: ");
				arr=w.mostFrequentLevel1PredictionType.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1PredictionType.getCount(arr[k])/w.mostFrequentLevel1PredictionType.totalTokens);
				System.out.println("\t token maj not-O: ");
				arr=w.mostFrequentLevel1NotOutsidePrediction.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1NotOutsidePrediction.getCount(arr[k])/w.mostFrequentLevel1NotOutsidePrediction.totalTokens);
				System.out.println("\t token maj type not-O: ");
				arr=w.mostFrequentLevel1NotOutsidePredictionType.getTokens();
				for(int k=0;k<arr.length;k++)
					System.out.println("\t\t"+arr[k]+":"+ w.mostFrequentLevel1NotOutsidePredictionType.getCount(arr[k])/w.mostFrequentLevel1NotOutsidePredictionType.totalTokens);
			}
	}

	//
	// assumes that the data has been tagged with level 1
	// 
	//
	public static void aggregateLevel1Predictions(Vector<LinkedVector> data){
		for(int i=0;i<data.size();i++)
			for(int j=0;j<data.elementAt(i).size();j++)
				aggregateTokenLevelLevel1Predictions((NEWord)data.elementAt(i).get(j));
	}

	private static void aggregateTokenLevelLevel1Predictions(NEWord word){
		OccurrenceCounter mostFrequentLevel1Prediction=new OccurrenceCounter();
		OccurrenceCounter mostFrequentLevel1PredictionType=new OccurrenceCounter();
		OccurrenceCounter mostFrequentLevel1NotOutsidePrediction=new OccurrenceCounter();
		OccurrenceCounter mostFrequentLevel1NotOutsidePredictionType=new OccurrenceCounter();
		if(!Character.isUpperCase(word.form.charAt(0)))
			return;
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1"))
		{  
			int i=0;
			NEWord w = word, last = (NEWord)word.nextIgnoreSentenceBoundary;

			for (i = 0; i < 1000 && last != null; ++i) last = (NEWord) last.nextIgnoreSentenceBoundary;
			for (i = 0; i > -1000 && w.previousIgnoreSentenceBoundary != null; --i) w = (NEWord) w.previousIgnoreSentenceBoundary;

			do{
				if(w.form.equalsIgnoreCase(word.form)&&
						Character.isUpperCase(w.form.charAt(0))&&w!=word)
				{
					String prediction="O";
					if(NETaggerLevel2.isTraining){
						prediction=w.neLabel;
						if(ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.useNoise())
							prediction=ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.randomLabel();
					}
					else{
						prediction=w.neTypeLevel1;
					}
					mostFrequentLevel1Prediction.addToken(prediction);
					if(!prediction.equals("O"))
						mostFrequentLevel1NotOutsidePrediction.addToken(prediction);
					if(prediction.indexOf('-')>-1){
						prediction=prediction.substring(2,prediction.length());
						mostFrequentLevel1NotOutsidePredictionType.addToken(prediction);
					}
					mostFrequentLevel1PredictionType.addToken(prediction);
				}
				w = (NEWord) w.nextIgnoreSentenceBoundary; 
			}while(w != last);	   		
		}
		word.mostFrequentLevel1Prediction=mostFrequentLevel1Prediction;
		word.mostFrequentLevel1NotOutsidePrediction=mostFrequentLevel1NotOutsidePrediction;
		word.mostFrequentLevel1PredictionType=mostFrequentLevel1PredictionType;
		word.mostFrequentLevel1NotOutsidePredictionType=mostFrequentLevel1NotOutsidePredictionType;
	}

	public static void aggregateEntityLevelPredictions(Vector<LinkedVector> data){
		annotatePredictionLevel1Entities(data);
		for(int i=0;i<data.size();i++)
			for(int j=0;j<data.elementAt(i).size();j++){
				setMajorityExactEntityFeatures((NEWord)data.elementAt(i).get(j));
				setMajoritySuperEntityFeatures((NEWord)data.elementAt(i).get(j));
				setMajorityTokenInEntityFeatures((NEWord)data.elementAt(i).get(j));
			}				
	}

	public static void setMajoritySuperEntityFeatures(NEWord word){
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")&&word.entity!=null)
		{  
			OccurrenceCounter majority=new OccurrenceCounter();
			int i=0;
			NEWord w = word, last = (NEWord)word.nextIgnoreSentenceBoundary;

			for (i = 0; i < 1000 && last != null; ++i) last = (NEWord) last.nextIgnoreSentenceBoundary;
			for (i = 0; i > -1000 && w.previousIgnoreSentenceBoundary != null; --i) w = (NEWord) w.previousIgnoreSentenceBoundary;

			do{
				if(w!=word&&w!=null&&(w!=last)&&w.entity!=null&&w.entity.indexOf(word.entity)>-1&&(!w.entity.equals(word.entity)))
				{
					majority.addToken(w.entityType);
					String entity=w.entity;
					while(w!=null&&w.entity!=null&&w.entity.equals(entity)&&w!=last)
						w=w.nextIgnoreSentenceBoundary;
				}
				else{
					if(w!=last)
						w = (NEWord) w.nextIgnoreSentenceBoundary;
				}
			}while(w != last);

			word.mostFrequentLevel1SuperEntityType=majority;
		}		
	}


	public static void setMajorityTokenInEntityFeatures(NEWord word){
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")&&Character.isUpperCase(word.form.charAt(0)))
		{  
			OccurrenceCounter majority=new OccurrenceCounter();
			int i=0;
			NEWord w = word, last = (NEWord)word.nextIgnoreSentenceBoundary;

			for (i = 0; i < 1000 && last != null; ++i) last = (NEWord) last.nextIgnoreSentenceBoundary;
			for (i = 0; i > -1000 && w.previousIgnoreSentenceBoundary != null; --i) w = (NEWord) w.previousIgnoreSentenceBoundary;

			Hashtable<NEWord, Boolean> takenWords=new Hashtable<NEWord, Boolean>();
			takenWords.put(word, true);
			NEWord temp=word.nextIgnoreSentenceBoundary;
			while(temp!=null&&word.entity!=null&&temp.entity!=null&&word.entity.equals(temp.entity))
			{
				takenWords.put(temp, true);
				temp=temp.nextIgnoreSentenceBoundary;
			}
			temp=word.previousIgnoreSentenceBoundary;
			while(temp!=null&&word.entity!=null&&temp.entity!=null&&word.entity.equals(temp.entity))
			{
				takenWords.put(temp, true);
				temp=temp.previousIgnoreSentenceBoundary;
			}


			do{
				if((!takenWords.containsKey(w))&&w!=null&&(w!=last)&&w.entity!=null&&
						w.entity.indexOf(word.form.toLowerCase()+" ")>-1&&
						(!w.entity.equals(word.form.toLowerCase()+" ")))
				{
					majority.addToken(w.entityType);
					String entity=w.entity;
					while(w!=null&&w.entity!=null&&w.entity.equals(entity)&&w!=last)
						w=w.nextIgnoreSentenceBoundary;
				}
				else{
					if(w!=last)
						w = (NEWord) w.nextIgnoreSentenceBoundary;
				}
			}while(w != last);

			word.mostFrequentLevel1TokenInEntityType=majority;
		}		
	}


	public static void setMajorityExactEntityFeatures(NEWord word){
		if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")&&word.entity!=null)
		{  
			OccurrenceCounter majority=new OccurrenceCounter();
			int i=0;
			NEWord w = word, last = (NEWord)word.nextIgnoreSentenceBoundary;

			for (i = 0; i < 1000 && last != null; ++i) last = (NEWord) last.nextIgnoreSentenceBoundary;
			for (i = 0; i > -1000 && w.previousIgnoreSentenceBoundary != null; --i) w = (NEWord) w.previousIgnoreSentenceBoundary;

			Hashtable<NEWord, Boolean> takenWords=new Hashtable<NEWord, Boolean>();
			takenWords.put(word, true);
			NEWord temp=word.nextIgnoreSentenceBoundary;
			while(temp!=null&&word.entity!=null&&temp.entity!=null&&word.entity.equals(temp.entity))
			{
				takenWords.put(temp, true);
				temp=temp.nextIgnoreSentenceBoundary;
			}
			temp=word.previousIgnoreSentenceBoundary;
			while(temp!=null&&word.entity!=null&&temp.entity!=null&&word.entity.equals(temp.entity))
			{
				takenWords.put(temp, true);
				temp=temp.previousIgnoreSentenceBoundary;
			}
			do{
				if((!takenWords.containsKey(w))&&w!=null&&(w!=last)&&w.entity!=null&&
						w.entity.equals(word.entity)&&
						(!w.entity.equalsIgnoreCase((w.form+" ").toLowerCase())))
				{
					String entity=w.entity;
					majority.addToken(w.entityType);
					while(w!=null&&w.entity!=null&&w.entity.equals(entity)&&w!=last)
						w=w.nextIgnoreSentenceBoundary;
				}
				else{
					if(w!=last)
						w = (NEWord) w.nextIgnoreSentenceBoundary;
				}
			}while(w != last);

			word.mostFrequentLevel1ExactEntityType=majority;
		}		
	}

	public static void annotatePredictionLevel1Entities(Vector<LinkedVector> data){
		if(data.size()==0)
			return;
		NEWord w=(NEWord)data.elementAt(0).get(0);
		while(w!=null){
			String label=w.neTypeLevel1;
			if(NETaggerLevel2.isTraining)
				label=w.neLabel;
			if(label.startsWith("B-")||label.startsWith("U-")){
				String expression=w.form+" ";
				String type=label.substring(2);
				NEWord temp=w.nextIgnoreSentenceBoundary;
				if(NETaggerLevel2.isTraining){
					while(temp!=null&&temp.neLabel.endsWith(type)&&
							(!temp.neLabel.startsWith("B-"))&&
							(!temp.neLabel.startsWith("U-"))){
						expression+=temp.form+" ";
						temp=temp.nextIgnoreSentenceBoundary;
					}
				}
				else{
					while(temp!=null&&temp.neTypeLevel1.endsWith(type)&&
							(!temp.neTypeLevel1.startsWith("B-"))&&
							(!temp.neTypeLevel1.startsWith("U-"))){
						expression+=temp.form+" ";
						temp=temp.nextIgnoreSentenceBoundary;
					}					
				}
				if(ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.useNoise()&&NETaggerLevel2.isTraining)
					type=ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.randomType();
				while(w!=temp){
					w.entity=expression.toLowerCase();
					w.entityType=type;
					w=w.nextIgnoreSentenceBoundary;
				}
			}
			else
				w=w.nextIgnoreSentenceBoundary;
		}
	}
	*/
}
