package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;


import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NamedEntity;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.OccurrenceCounter;


public class TwoLayerPredictionAggregationFeatures {
	public enum Direction {RIGHT,LEFT};//are we aggregating to the right or to the left
	public static void setLevel1AggregationFeatures(Data data, boolean useGoldData,String comment) throws Exception{
		System.out.println("Extracting features for level 2 inference");
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for(int i=0;i<sentences.size();i++)
				for(int j=0;j<sentences.elementAt(i).size();j++)
					setLevel1AggregationFeatures((NEWord)sentences.elementAt(i).get(j), useGoldData);
		}
		System.out.println("Done - Extracting features for level 2 inference");
	}

	/*
	 * If our confidence in predicting the named entity is higher than minConfidenceThreshold, 
	 * we're going to use the predictions as features
	 */
	private static void setLevel1AggregationFeatures(NEWord word,boolean useGoldData) throws Exception{
		//word.level1AggregationFeatures=new Vector<String>();
		word.level1AggregationFeatures=new Vector<NEWord.RealFeature>();

		NamedEntity currentNE=word.predictedEntity;
		//these counters will keep the distribution of the features around the current word
		OccurrenceCounter featuresCounts=new OccurrenceCounter();

		if(useGoldData)
			currentNE=word.goldEntity;
		HashMap<NamedEntity,Boolean> confidentEntitiesInTheArea=new HashMap<NamedEntity,Boolean>();
		HashMap<NamedEntity,Boolean> confidentEntitiesInTheAreaLeft=new HashMap<NamedEntity,Boolean>();
		HashMap<NamedEntity,Boolean> confidentEntitiesInTheAreaRight=new HashMap<NamedEntity,Boolean>();
		NEWord w=word.previousIgnoreSentenceBoundary;
		for(int i=0;i<1000&&w!=null;i++){
			if(useGoldData&&w.goldEntity!=null&&(!w.goldEntity.equals(currentNE))){
				confidentEntitiesInTheArea.put(w.goldEntity,true);
				confidentEntitiesInTheAreaLeft.put(w.goldEntity,true);
			}
			if(w.predictedEntity!=null&&(!w.predictedEntity.equals(currentNE))&&!useGoldData){
				confidentEntitiesInTheArea.put(w.predictedEntity,true);
				confidentEntitiesInTheAreaLeft.put(w.predictedEntity,true);
			}
			if(w!=word&&w.form.equals(word.form)){
				if(useGoldData){
					if(ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.nextDouble()<0.1)
						featuresCounts.addToken("leftTokenLevel"+ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.randomLabel());
					else
						featuresCounts.addToken("leftTokenLevel"+w.neLabel);
				}
				else{
					featuresCounts.addToken("leftTokenLevel"+w.neTypeLevel1);					
				}					
			}
			w=w.previousIgnoreSentenceBoundary;
		}
		w=word.nextIgnoreSentenceBoundary;
		for(int i=0;i<1000&&w!=null;i++){
			if(useGoldData&&w.goldEntity!=null&&(!w.goldEntity.equals(currentNE))){
				confidentEntitiesInTheArea.put(w.goldEntity,true);
				confidentEntitiesInTheAreaRight.put(w.goldEntity,true);
			}
			if(w.predictedEntity!=null&&(!w.predictedEntity.equals(currentNE))&&!useGoldData){
				confidentEntitiesInTheArea.put(w.predictedEntity,true);
				confidentEntitiesInTheAreaRight.put(w.predictedEntity,true);
			}
			if(w!=word&&w.form.equals(word.form)){
				if(useGoldData){
					if(ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.nextDouble()<0.2)
						featuresCounts.addToken("rightTokenLevel"+ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.randomLabel());
					else
						featuresCounts.addToken("rightTokenLevel"+w.neLabel);
				}
				else{
					featuresCounts.addToken("rightTokenLevel"+w.neTypeLevel1);					
				}
			}
			w=w.nextIgnoreSentenceBoundary;
		}
		for(Iterator<NamedEntity> i=confidentEntitiesInTheArea.keySet().iterator();i.hasNext();){
			NamedEntity ne=i.next();
			double omisisonRate=0.1;
			//check if we should just omit this NE
			if(ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.nextDouble()>omisisonRate){
				double noiseRate=0.2;//this is if the direction is right. If the direction is left- we have to modify this
				String direction=Direction.RIGHT.toString();//please be careful with updating the direction values 
				if(confidentEntitiesInTheAreaLeft.containsKey(ne)){
					direction=Direction.LEFT.toString();
					noiseRate=0.1;//we're typically better with entities to the left....
				}
				String neType=ne.type;
				if(ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.nextDouble()<noiseRate){
					String randomLabelType=ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.randomType();
					while(randomLabelType.equalsIgnoreCase("O")||randomLabelType.equals(neType))
						randomLabelType=ParametersForLbjCode.currentParameters.level1AggregationRandomGenerator.randomType();
					neType=randomLabelType;
				}

				if((!confidentEntitiesInTheAreaLeft.containsKey(ne))&&(!confidentEntitiesInTheAreaRight.containsKey(ne)))
					throw new Exception("Fatal error: the NE is neither on the left or the right?!");
				if(currentNE!=null){
					String form=currentNE.form;
					if(form.length()>3){
						if(ne.form.equals(form))
							featuresCounts.addToken(direction+"NE_Also_Exact_Match_NE_Type:\t"+neType);
						if((!ne.form.equals(form))&&(!ne.form.startsWith(form))&&(!ne.form.endsWith(form))&&ne.form.indexOf(form)>-1)
							featuresCounts.addToken(direction+"NE_Also_Substring_In_NE_Type:\t"+neType);
						if((!ne.form.equals(form))&&ne.form.startsWith(form))
							featuresCounts.addToken(direction+"NE_Also_Starts_NE_Type:\t"+neType);
						if((!ne.form.equals(form))&&ne.form.endsWith(form))
							featuresCounts.addToken(direction+"NE_Also_Ends_NE_Type:\t"+neType);
						if((!(ne.form.equals(form)))&&ne.form.toLowerCase().equals(form.toLowerCase()))
							featuresCounts.addToken(direction+"NE_Also_Exact_Match_NE_Type_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&(!ne.form.startsWith(form))&&(!ne.form.endsWith(form))&&ne.form.indexOf(form)>-1))&&
								((!ne.form.toLowerCase().equals(form.toLowerCase()))&&(!ne.form.toLowerCase().startsWith(form.toLowerCase()))&&
										(!ne.form.toLowerCase().endsWith(form.toLowerCase()))&&ne.form.toLowerCase().indexOf(form.toLowerCase())>-1))
							featuresCounts.addToken(direction+"NE_Also_Substring_In_NE_Type_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&ne.form.startsWith(form)))&&(!ne.form.toLowerCase().equals(form.toLowerCase()))&&
								ne.form.toLowerCase().startsWith(form.toLowerCase()))
							featuresCounts.addToken(direction+"NE_Also_Starts_NE_Type_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&ne.form.endsWith(form)))&&(!ne.form.toLowerCase().equals(form.toLowerCase()))&&
								ne.form.toLowerCase().endsWith(form.toLowerCase()))
							featuresCounts.addToken(direction+"NE_Also_Ends_NE_Type_IC:\t"+neType);
					}
					// if we cannot match complete NEs, it's not the end of the work yet.
					// in cases such as "Bank of Australia" and "Bank of Illinoils", we want to be able to say something about the word "Bank"
					form=word.form;
					if(form.length()>3){
						if(ne.form.equals(form))
							featuresCounts.addToken(direction+"labeledTokenExactMatchInExpression:\t"+neType);
						if((!ne.form.equals(form))&&(!ne.form.startsWith(form))&&(!ne.form.endsWith(form))&&ne.form.indexOf(form)>-1)
							featuresCounts.addToken(direction+"labeledTokenSubstringInExpression:\t"+neType);
						if((!ne.form.equals(form))&&ne.form.startsWith(form))
							featuresCounts.addToken(direction+"labeledTokenStartsExpression:\t"+neType);
						if((!ne.form.equals(form))&&ne.form.endsWith(form))
							featuresCounts.addToken(direction+"unlabeledTokenEndsExpression:\t"+neType);
						if((!(ne.form.equals(form)))&&(ne.form.toLowerCase().equals(form.toLowerCase())))
							featuresCounts.addToken(direction+"labeledTokenExactMatchInExpression_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&(!ne.form.startsWith(form))&&(!ne.form.endsWith(form))&&ne.form.indexOf(form)>-1))&&
								((!ne.form.toLowerCase().equals(form.toLowerCase()))&&(!ne.form.toLowerCase().startsWith(form.toLowerCase()))&&
										(!ne.form.toLowerCase().endsWith(form.toLowerCase()))&&ne.form.toLowerCase().indexOf(form.toLowerCase())>-1))
							featuresCounts.addToken(direction+"labeledTokenSubstringInExpression_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&ne.form.startsWith(form)))&&((!ne.form.toLowerCase().equals(form.toLowerCase()))&&
								ne.form.toLowerCase().startsWith(form.toLowerCase())))
							featuresCounts.addToken(direction+"labeledTokenStartsExpression_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&ne.form.endsWith(form)))&&((!ne.form.toLowerCase().equals(form.toLowerCase()))&&
								ne.form.toLowerCase().endsWith(form.toLowerCase())))
							featuresCounts.addToken(direction+"labeledTokenEndsExpression_IC:\t"+neType);
					}

				}else{
					//this form is not a part of named entity
					String form=word.form;
					if(form.length()>3){
						if(ne.form.equals(form))
							featuresCounts.addToken(direction+"unlabeledTokenExactMatchInExpression:\t"+neType);
						if((!ne.form.equals(form))&&(!ne.form.startsWith(form))&&(!ne.form.endsWith(form))&&ne.form.indexOf(form)>-1)
							featuresCounts.addToken(direction+"unlabeledTokenSubstringInExpression:\t"+neType);
						if((!ne.form.equals(form))&&ne.form.startsWith(form))
							featuresCounts.addToken(direction+"unlabeledTokenStartsExpression:\t"+neType);
						if((!ne.form.equals(form))&&ne.form.endsWith(form))
							featuresCounts.addToken(direction+"unlabeledTokenEndsExpression:\t"+neType);
						if((!(ne.form.equals(form)))&&(ne.form.toLowerCase().equals(form.toLowerCase())))
							featuresCounts.addToken(direction+"unlabeledTokenExactMatchInExpression_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&(!ne.form.startsWith(form))&&(!ne.form.endsWith(form))&&ne.form.indexOf(form)>-1))&&
								((!ne.form.toLowerCase().equals(form.toLowerCase()))&&(!ne.form.toLowerCase().startsWith(form.toLowerCase()))&&
										(!ne.form.toLowerCase().endsWith(form.toLowerCase()))&&ne.form.toLowerCase().indexOf(form.toLowerCase())>-1))
							featuresCounts.addToken(direction+"unlabeledTokenSubstringInExpression_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&ne.form.startsWith(form)))&&((!ne.form.toLowerCase().equals(form.toLowerCase()))&&
								ne.form.toLowerCase().startsWith(form.toLowerCase())))
							featuresCounts.addToken(direction+"unlabeledTokenStartsExpression_IC:\t"+neType);
						if((!((!ne.form.equals(form))&&ne.form.endsWith(form)))&&((!ne.form.toLowerCase().equals(form.toLowerCase()))&&
								ne.form.toLowerCase().endsWith(form.toLowerCase())))
							featuresCounts.addToken(direction+"unlabeledTokenEndsExpression_IC:\t"+neType);
					}
				}
			}
		}
		double max=-1;
		for(Iterator<String> i = featuresCounts.getTokensIterator();i.hasNext();){
			String s=i.next();
			if(max<featuresCounts.getCount(s))
				max=featuresCounts.getCount(s);
		}
		if(max==0)
			max=1;
		word.level1AggregationFeatures=new Vector<NEWord.RealFeature>();
		for(Iterator<String> i = featuresCounts.getTokensIterator();i.hasNext();){
			String s=i.next();
			word.level1AggregationFeatures.add(new NEWord.RealFeature(featuresCounts.getCount(s)/max,s));
		}
	}
}
