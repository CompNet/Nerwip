package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import edu.illinois.cs.cogcomp.LbjNer.IO.*;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;


import java.util.*;
import java.io.*;

public class WikipediaLinkability{
	public static double minAppearanceCountForHashing=5;//This is to regulate the memory consumption   
	public static double minAppearanceCountForLinkabilityNormalization=10;// if a phrase appears in less than 10 wikipedia pages don't use it for case normalization and gazettters matching   
	
	public  static Hashtable<String,Double> linkScores=null;
	public  static Hashtable<String,Double> linkScoresPrevalent=null;
	public  static Hashtable<String,Double> linkScoresVeryPrevalent=null;
	public  static Hashtable<String,Double> linkScores_IC=null;
	public  static Hashtable<String,Double> linkScoresPrevalent_IC=null;
	public  static Hashtable<String,Double> linkScoresVeryPrevalent_IC=null;
	public static Hashtable<String,LinkabilityData> linkableEntitiesNormalizer=null;//rememeber that the keys will ne lowercased!!!!

	/*
	 * surface forms with linkability lower than min score threshold will not be read 
	 */
	public static void init(String pathToLinkScores,double linkScoreThres){
		System.out.println("Loading the linkability scores");
		linkScores=new Hashtable<String, Double>();
		linkScoresPrevalent=new Hashtable<String, Double>();
		linkScoresVeryPrevalent=new Hashtable<String, Double>();
		linkScores_IC=new Hashtable<String, Double>();
		linkScoresPrevalent_IC=new Hashtable<String, Double>();
		linkScoresVeryPrevalent_IC=new Hashtable<String, Double>();
		linkableEntitiesNormalizer=new Hashtable<String, LinkabilityData>();
		InFile in=new InFile(pathToLinkScores);
		String line=in.readLine();
		while(line!=null){
			StringTokenizer st=new StringTokenizer(line,"\t");
			String exp=st.nextToken();
			double score=Double.parseDouble(st.nextToken());
			int anchorsCount=Integer.parseInt(st.nextToken());
			int appearanceCount=Integer.parseInt(st.nextToken());
			if(appearanceCount>minAppearanceCountForHashing){
				LinkabilityData data=new LinkabilityData(score, anchorsCount, appearanceCount, exp);
				if(score>linkScoreThres){
					while(exp.endsWith(" "))
						exp=exp.substring(0,exp.length()-1);
					while(exp.startsWith(" "))
						exp=exp.substring(1,exp.length());
					if(data.appearanceCount>minAppearanceCountForLinkabilityNormalization){
						if(linkableEntitiesNormalizer.containsKey(exp.toLowerCase())){
							LinkabilityData older = linkableEntitiesNormalizer.get(exp.toLowerCase());
							if(data.isMoreLinkableThan(older))
								linkableEntitiesNormalizer.put(exp.toLowerCase(), data);
						}
						else
							linkableEntitiesNormalizer.put(exp.toLowerCase(),data);
					}
					linkScores.put(exp, score);
					double lowercaseScore=0;
					if(linkScores_IC.containsKey(exp.toLowerCase()))
						lowercaseScore=linkScores_IC.get(exp.toLowerCase());
					if(lowercaseScore<score)
						linkScores_IC.put(exp.toLowerCase(), score);
					if(appearanceCount>20){
						linkScoresPrevalent.put(exp, score);
						lowercaseScore=0;
						if(linkScoresPrevalent_IC.containsKey(exp.toLowerCase()))
							lowercaseScore=linkScoresPrevalent_IC.get(exp.toLowerCase());
						if(lowercaseScore<score)
							linkScoresPrevalent_IC.put(exp.toLowerCase(), score);
					}
					if(appearanceCount>100){
						linkScoresVeryPrevalent.put(exp, score);
						lowercaseScore=0;
						if(linkScoresVeryPrevalent_IC.containsKey(exp.toLowerCase()))
							lowercaseScore=linkScoresVeryPrevalent_IC.get(exp.toLowerCase());
						if(lowercaseScore<score)
							linkScoresVeryPrevalent_IC.put(exp, score);
					}
				}
			}
			line=in.readLine();
		}
		in.close();
		System.out.println("Done loading the linkability scores");
	}

	public static void annotate(NEWord w)
	{		
		NEWord start=w;
		NEWord end=w;
		String expression=w.form;
		Vector<NEWord> expressionWords=new Vector<NEWord>();
		expressionWords.addElement(w);
		//System.out.println("Annotating the word : "+ w.form);
		for(int i=0;i<6&&end!=null;i++)
		{
			/*
			 * This piece of code initializes the "normalizedMostLinkableExpression" for each word
			 */
			if(linkableEntitiesNormalizer.containsKey(expression.toLowerCase()))
			{
				LinkabilityData currentLinkability = linkableEntitiesNormalizer.get(expression.toLowerCase());
				LinkabilityData maxOldLink=null;
				if(w.normalizedMostLinkableExpression!=null&&linkableEntitiesNormalizer.containsKey(w.normalizedMostLinkableExpression))
					maxOldLink=linkableEntitiesNormalizer.get(w.normalizedMostLinkableExpression);
				if(maxOldLink==null||currentLinkability.isMoreLinkableThan(maxOldLink)){
					//I'm about to update the most linkable normalized expression for the word, but
					//first, I need to remove the old most linkable normalized expression info from
					//all the words that were in that expression					
					if(w.normalizedMostLinkableExpression!=null){
						String s=w.normalizedMostLinkableExpression;
						NEWord temp=w;
						while(temp!=null&&temp.normalizedMostLinkableExpression!=null&&temp.normalizedMostLinkableExpression.equals(s)){
							temp.normalizedMostLinkableExpression=null;
							temp=temp.nextIgnoreSentenceBoundary;
						}
						temp=w.previousIgnoreSentenceBoundary;//note that w.previousIgnoreSentenceBoundary is null already, so we need to be careful here!!! 
						while(temp!=null&&temp.normalizedMostLinkableExpression!=null&&temp.normalizedMostLinkableExpression.equals(s)){
							temp.normalizedMostLinkableExpression=null;
							temp=temp.previousIgnoreSentenceBoundary;
						}
					}
					//and now the update the most linkable score
					for(int j=0;j<expressionWords.size();j++)
						expressionWords.elementAt(j).normalizedMostLinkableExpression=currentLinkability.form;
				}
			}

			/*
			 * This is for case-sensitive linkability scores
			 */
			if(linkScores.containsKey(expression))
			{
				double score=linkScores.get(expression);
				if(score>start.maxStartLinkabilityScore)
					start.maxStartLinkabilityScore=score;
				if(score>end.maxEndLinkabilityScore)
					end.maxEndLinkabilityScore=score;
				for(int j=0;j<expressionWords.size();j++)
					if(expressionWords.elementAt(j).maxLinkability<score)
						expressionWords.elementAt(j).maxLinkability=score;
			}

			if(linkScoresPrevalent.containsKey(expression))
			{
				double score=linkScoresPrevalent.get(expression);
				if(score>start.maxStartLinkabilityScorePrevalent)
					start.maxStartLinkabilityScorePrevalent=score;
				if(score>end.maxEndLinkabilityScorePrevalent)
					end.maxEndLinkabilityScorePrevalent=score;
				for(int j=0;j<expressionWords.size();j++)
					if(expressionWords.elementAt(j).maxLinkabilityPrevalent<score)
						expressionWords.elementAt(j).maxLinkabilityPrevalent=score;
			}

			if(linkScoresVeryPrevalent.containsKey(expression))
			{
				double score=linkScoresVeryPrevalent.get(expression);
				if(score>start.maxStartLinkabilityScoreVeryPrevalent)
					start.maxStartLinkabilityScoreVeryPrevalent=score;
				if(score>end.maxEndLinkabilityScoreVeryPrevalent)
					end.maxEndLinkabilityScoreVeryPrevalent=score;
				for(int j=0;j<expressionWords.size();j++)
					if(expressionWords.elementAt(j).maxLinkabilityVeryPrevalent<score)
						expressionWords.elementAt(j).maxLinkabilityVeryPrevalent=score;
			}

			/*
			 * This is for the ignore case scenario
			 */

			if(linkScores_IC.containsKey(expression.toLowerCase()))
			{
				double score=linkScores_IC.get(expression.toLowerCase());
				if(score>start.maxStartLinkabilityScore_IC)
					start.maxStartLinkabilityScore_IC=score;
				if(score>end.maxEndLinkabilityScore_IC)
					end.maxEndLinkabilityScore_IC=score;
				for(int j=0;j<expressionWords.size();j++)
					if(expressionWords.elementAt(j).maxLinkability_IC<score)
						expressionWords.elementAt(j).maxLinkability_IC=score;
			}

			if(linkScoresPrevalent_IC.containsKey(expression.toLowerCase()))
			{
				double score=linkScoresPrevalent_IC.get(expression.toLowerCase());
				if(score>start.maxStartLinkabilityScorePrevalent_IC)
					start.maxStartLinkabilityScorePrevalent_IC=score;
				if(score>end.maxEndLinkabilityScorePrevalent_IC)
					end.maxEndLinkabilityScorePrevalent_IC=score;
				for(int j=0;j<expressionWords.size();j++)
					if(expressionWords.elementAt(j).maxLinkabilityPrevalent_IC<score)
						expressionWords.elementAt(j).maxLinkabilityPrevalent_IC=score;
			}

			if(linkScoresVeryPrevalent_IC.containsKey(expression.toLowerCase()))
			{
				double score=linkScoresVeryPrevalent_IC.get(expression.toLowerCase());
				if(score>start.maxStartLinkabilityScoreVeryPrevalent_IC)
					start.maxStartLinkabilityScoreVeryPrevalent_IC=score;
				if(score>end.maxEndLinkabilityScoreVeryPrevalent_IC)
					end.maxEndLinkabilityScoreVeryPrevalent_IC=score;
				for(int j=0;j<expressionWords.size();j++)
					if(expressionWords.elementAt(j).maxLinkabilityVeryPrevalent_IC<score)
						expressionWords.elementAt(j).maxLinkabilityVeryPrevalent_IC=score;
			}

			end=(NEWord) end.next;
			if(end!=null){
				expressionWords.addElement(end);
				if(expression.endsWith("-")||end.form.equals(".")||end.form.equals(",")||end.form.equals("-"))
					expression=expression+end.form;
				else
					expression=expression+" "+end.form;
			}
		} //i
	}

	public static class LinkabilityData{
		double linkability;
		double anchorsCount;
		double appearanceCount;
		String form;

		public LinkabilityData(double linkability,double anchorsCount,double appearanceCount,String form){
			this.linkability=linkability;
			this.anchorsCount=anchorsCount;
			this.appearanceCount=appearanceCount;
			this.form=form;			
		}

		public boolean isMoreLinkableThan(LinkabilityData other){
			/*
			 * If one of the surface forms has appeared less then 5 times,
			 * we do not trust the linkability statistics and go with the appearance
			 * count.
			 */
			if(this.appearanceCount>10&&other.appearanceCount<5)
				return true;
			if(this.appearanceCount<5&&other.appearanceCount>10)
				return false;
			if(this.appearanceCount<other.appearanceCount/2)
				return false;
			if(this.appearanceCount/2>other.appearanceCount)
				return true;
			return this.linkability>other.linkability;
		}
	}
}
