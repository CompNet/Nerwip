package edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures;

import java.util.HashMap;
import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils.Document;
import edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils.DocumentCollection;
import edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils.FeatureMap;
import edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils.MemoryEfficientNB;
import edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils.NfoldCrossvalidation;
import edu.illinois.cs.cogcomp.LbjNer.ClassifiersAndUtils.StopWords;
import edu.illinois.cs.cogcomp.LbjNer.IO.InFile;
import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
/*
 * This will keep the information of whether the word is in the title and to what topic it belongs to.
 * 
 *  
 *  
 */
public class WordTopicAndLayoutFeatures {
	public static final String pathToStopWords="../../Data/TrainByTopic/stopwords_big";
	private static HashMap<NEWord,Integer> wordToTopicIdMap=new HashMap<NEWord, Integer>();
	private static FeatureMap map=null; //new FeatureMap();
	private static MemoryEfficientNB nb=null;//new MemoryEfficientNB(docs, map, 3);
	private static String[] labelnames=null;

	/*
	 * Right now the return values are:
	 *  {isInTitle}x{TopicId}
	 */
	public static String getWordType(NEWord w){
		return "-"+wordToTopicIdMap.get(w);
	}

	/*
	 * Note- this assumes that the data is split by documents.
	 * So if we choose to ignore the document boundaries, we're 
	 * in trouble!!!
	 */
	public static void addDatasets(Vector<LinkedVector> sentences,boolean lowercaseData,double confidenceThreshold) throws Exception{
		if(nb==null||map==null)
			throw new Exception("Topic classifier not initialized!!!");
		String documentText="";
		Vector<NEWord> docWords=new Vector<NEWord>();
		for(int sid=0;sid<sentences.size();sid++){
			LinkedVector s=sentences.elementAt(sid);
			for(int i=0;i<s.size();i++){
				documentText+=" "+((NEWord)s.get(i)).originalForm+" ";
				docWords.addElement((NEWord)s.get(i));
			}
			if(((NEWord)s.get(s.size()-1)).nextIgnoreSentenceBoundary==null){
				//this is the last sentence in the document- move on!
				if(lowercaseData)
					documentText=documentText.toLowerCase();
				Document doc=new Document(InFile.tokenize(documentText,"\n\t -.,?<>;':\"[]{}\\|`~!@#$%^&*()_+=-0987654321`~"), -1);
				int label=nb.classify(doc, confidenceThreshold);
				System.out.println("*********************\n"+labelnames[label+1]+"\n*********************\n"+documentText.substring(0,Math.min(documentText.length(),400)));
				for(int i=0;i<docWords.size();i++)
					wordToTopicIdMap.put(docWords.elementAt(i), label);
				documentText="";
				docWords=new Vector<NEWord>();
			}
		}

	}	
	
	public static void initTopicClassifier(String pathToTopicData,String[] fileNames,String[] _labelnames){
		map=new FeatureMap();
		labelnames=new String[_labelnames.length+1];
		labelnames[0]="UNKNOWN";
		for(int i=0;i<_labelnames.length;i++)
			labelnames[1+i]=_labelnames[i];
		DocumentCollection docs=new DocumentCollection();
		StopWords stops=new StopWords(pathToStopWords);
		for(int i=0;i<fileNames.length;i++)
			docs.addDocuments(pathToTopicData+"/"+fileNames[i], i, stops, false,"\n\t -.,?<>;':\"[]{}\\|`~!@#$%^&*()_+=-0987654321`~");
		map.addDocs(docs, 20, false);
		NfoldCrossvalidation cv=new NfoldCrossvalidation(docs, 5);
		cv.printNfoldCorrssvalidationNbAcc(fileNames.length, -1, 20);
		//System.exit(0);
		nb=new MemoryEfficientNB(docs, map, fileNames.length);
	}

}
