package edu.illinois.cs.cogcomp.LbjNer.GazetteerIndexManager;

import java.io.IOException;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;

import edu.illinois.cs.cogcomp.LbjNer.GazetteerIndexManager.IndexGazetteers.AnalyzerTypes;

/**
 * search method. Feed in lines to see result
 */
public class GazetteerIndexSearcher
{
	public  static final int maxTokensForExpressionTester = 10;

	private Searcher searcher = null;
	private  boolean discardCategoryScores = true;
	
	public GazetteerIndexSearcher(String pathToGazListIndex, boolean discardCategoryScores) throws Exception{
		searcher = new IndexSearcher(FSDirectory.getDirectory(pathToGazListIndex));
		this.discardCategoryScores = discardCategoryScores;
	}
		
	public static QueryParser getParser(AnalyzerTypes analyzerType) {
		if(analyzerType.equals(AnalyzerTypes.Standard))
			return new QueryParser("term",new StandardAnalyzer()); 
		if(analyzerType.equals(AnalyzerTypes.Standard))
			return new QueryParser("term",new SimpleAnalyzer()); 
		if(analyzerType.equals(AnalyzerTypes.Standard))
			return new QueryParser("term",new StopAnalyzer()); 
		if(analyzerType.equals(AnalyzerTypes.Standard))
			return new QueryParser("term",new WhitespaceAnalyzer());
		return null;
	}
		
	public  GazetteersAnnotation getGazetteerAnnotations(String expression,  AnalyzerTypes analyzerType) throws CorruptIndexException, IOException, ParseException {
		GazetteersAnnotation res = new GazetteersAnnotation();
		res.originalExpression = expression;
		String catsAndScores = "";
		if(analyzerType.equals(AnalyzerTypes.ExactMatch))
		{
			Term t = new Term("Term", expression);
			Query query = new TermQuery(t);
			TopDocs hits = searcher.search(query,1);
			if(hits.totalHits==0) 
				return res;
			Document doc = searcher.doc(hits.scoreDocs[0].doc);
			res.topMatch=doc.get("Term");
			//catsAndScores = doc.get("CategoriesAndScores");
			catsAndScores = doc.get("Categories");
		} else {
			Query query = getParser(analyzerType).parse(expression);
			TopDocs all = searcher.search(query,1);
			ScoreDoc[] hits = all.scoreDocs;
			if(hits.length==0)
				return res;
			
			Document doc = searcher.doc(hits[0].doc);
			res.topMatch=doc.get("Term");
			//catsAndScores = doc.get("CategoriesAndScores");
			catsAndScores = doc.get("Categories");
		}
		if(catsAndScores!=null) {
			StringTokenizer st = new StringTokenizer(catsAndScores,"\t");
			//System.out.println("Match for "+expression+" is "+catsAndScores);
			while(st.hasMoreTokens()){
				String cat= st.nextToken();
				res.categ.addElement(cat);
				//String score = st.nextToken(); 
				if(discardCategoryScores) 
					res.scores.addElement(1.0);
				//else 
				//	res.scores.addElement(Double.parseDouble(score));
				//System.out.println("\tcat:"+cat+" score: "+score);
			}
		}
		return res;
	}
	
	/**
	 * This is a tester function! When I'll be using the gazetteers, I'mm be using NEWord class etc.
	 */
	public  void analyzeText(String s, IndexGazetteers.AnalyzerTypes analyzer) throws Exception
	{
		StringTokenizer st = new StringTokenizer(s, ".,?!:;()-1234567890\b\t\n\f\r\\");
		int max = st.countTokens();
		String[] array = new String[max];
		for(int i = 0; i < max; i++)
		{
			array[i] = st.nextToken();
		}
		analyzeTextTest(array, analyzer);
	}
	
	public  void analyzeTextTest(String[] s, IndexGazetteers.AnalyzerTypes analyzer) throws Exception
	{
		String expression = "";
		
		for(int i = 0; i < s.length; i++)
		{
			for(int j = i; j<(i+maxTokensForExpressionTester)&&j< s.length;j++)
			{
				expression += s[j];
				System.out.println(getGazetteerAnnotations(expression, analyzer));
				expression += " ";
			}
			expression="";
		}
	}	
	
	public static class GazetteersAnnotation
	{	
		public String originalExpression=null;
		public String topMatch=null;
		public Vector<String> categ= new Vector<String>();
		public Vector<Double> scores= new Vector<Double>();
				
		public String toString()
		{
			String s = originalExpression + " : " + topMatch + "\n";
			for(int i = 0; i < categ.size();i++)
			{
				s+= categ.get(i) + " - " + scores.get(i) + "\n";
			}
			return s;
		}	
	}

	public static void main(String args[]) throws Exception
	{
		GazetteerIndexSearcher searcher = new GazetteerIndexSearcher("../../Data/GazetteersIndex/MergedIndex", true);		
		searcher.analyzeText(
				"Dogs Playing Poker refers collectively to a series of sixteen oil paintings by C. M. Coolidge, commissioned in 1903 by Brown & Bigelow to advertise cigars.  All the paintings in the series feature anthropomorphized dogs, but the nine in which dogs are seated around a card table have become derisively well-known in the United States as examples of mainly working-class taste in home decoration. Critic Annette Ferrara describes Dogs Playing Poker as \"indelibly burned into... the American collective-schlock subconscious ... through incessant reproduction on all manner of pop ephemera.\" These were followed in 1910 by a similar painting, Looks Like Four of a Kind. Some of the compositions in the series are modeled on paintings of human card-players by such artists as Caravaggio, Georges de La Tour, and Paul C�zanne. The St. Bernard in the paintings Waterloo and A Bold Bluff was owned by the Fifth Avenue florist Theodore Lang, who counted Coolidge among his friends. The dog\'s name was Captain. On February 15, 2005, the originals of A Bold Bluff and Waterloo were auctioned as a pair to an undisclosed buyer for US $590,400. The previous top price for a Coolidge was $74,000.\" Rohan ..",
				AnalyzerTypes.ExactMatch);
	}

}
