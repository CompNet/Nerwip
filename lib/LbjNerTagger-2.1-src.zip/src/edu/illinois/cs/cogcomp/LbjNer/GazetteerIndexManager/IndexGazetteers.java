package edu.illinois.cs.cogcomp.LbjNer.GazetteerIndexManager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.LockObtainFailedException;

public class IndexGazetteers
{
	public static enum GazetteeFormats  {SimpleList,  ListWithCategories /*ListWithCategoriesAndScores*/};
	public static enum AnalyzerTypes  {Standard, Simple, StopWords, Whitespace, ExactMatch};

	/**
	 * Names of the indices - Prelim is the intermediate one. Merged is final one.
	 */
	public static String prelim = "../../Data/GazetteersIndex/TempIndex";
	public static AnalyzerTypes analyzer = AnalyzerTypes.ExactMatch;
	
		
	/**
	 * Key file - Please note the inputs/arguments required.
	 * The mergeFiles will only merge the files. It will go through each file, add the categories to a hash map,
	 * therefore taking out duplicates and creates a preliminary index containing the categories and scores in a format as follows:
	 * 
	 * Document X: <term> || <cat> || <score>
	 * 
	 * @param inputFilenames - An array of strings of filenames. This will look in essentially the directory outside of
	 * 						the "src" folder when using Eclipse for example.
	 * @return true if the merge was successful and false if there was an error aside from the thrown exceptions
	 * @throws CorruptIndexException
	 * @throws LockObtainFailedException
	 * @throws IOException
	 * @throws ParseException
	 */
	public static boolean mergeFiles(String inputPath, String[] inputFilenames, 
			String mergedOutputIndexPath, boolean toLowerCaseTerms, String debugFile) throws Exception
	{
		HashMap<String, Boolean> terms = new HashMap<String, Boolean>();
		
		/**
		 * Clear out old index to avoid duplicates
		 */
		deleteIndex(prelim);
		
		IndexWriter index = new IndexWriter(FSDirectory.getDirectory(prelim),
				new StandardAnalyzer(),
				IndexWriter.MaxFieldLength.UNLIMITED);
		
		/**
		 * Create hashmaps and prelim index
		 */
		for(int i = 0; i < inputFilenames.length;i++)
		{
			try{
				BufferedReader br = new BufferedReader(new FileReader(inputPath+"/"+inputFilenames[i]));
				String line = br.readLine();
				if(toLowerCaseTerms&&line!=null)
					line = line.toLowerCase();
				System.out.println("Reading ... " + inputFilenames[i]);
				
				if(getFileType(inputPath+"/"+inputFilenames[i]).equals(GazetteeFormats.SimpleList)) {
					// Type 1 corresponds to simple categ. files one expression per line, no categories
					int count=0;
					while(line!=null) {
						if(count++%10000==0)
							System.out.println(count+" lines processed");
						StringTokenizer s = new StringTokenizer(line,"\t");
						try {
							String term = s.nextToken();
							terms.put(term, true);
							if(s.countTokens()==0) {
								Document doc = new Document();
								doc.add(new Field("Term",term,Field.Store.YES,Field.Index.NOT_ANALYZED));
								doc.add(new Field("Cat",inputFilenames[i],Field.Store.YES,Field.Index.ANALYZED));
								//doc.add(new Field("Score","1",Field.Store.YES,Field.Index.ANALYZED));
								index.addDocument(doc);
							} else {
								while(s.hasMoreTokens()) 	{
									String tokenNext = s.nextToken();
									Document docextras = new Document();
									docextras.add(new Field("Term",term,Field.Store.YES,Field.Index.NOT_ANALYZED));
									docextras.add(new Field("Cat",tokenNext,Field.Store.YES,Field.Index.ANALYZED));
									//docextras.add(new Field("Score","1",Field.Store.YES,Field.Index.ANALYZED));
									index.addDocument(docextras);
								}
							}
						}
						catch(Exception e) {
							System.out.println("Problem processing the line: " + line);
						}
						line = br.readLine();
						if(toLowerCaseTerms&&line!=null)
							line = line.toLowerCase();
					}
				} else {
					 // Type 2 files are those that are in the form:  <Term> ('\t' <Category 1>)*
					int count = 0;
					while(line!=null) {
						StringTokenizer s = new StringTokenizer(line,"\t");
						try {
							if(count++%10000==0)
								System.out.println(count+" lines processed");
							String term = s.nextToken();
							terms.put(term, true);
							while(s.hasMoreTokens())
							{
								String cat = s.nextToken();
								// String score = s.nextToken();
								Document docextras = new Document();
								docextras.add(new Field("Term",term,Field.Store.YES,Field.Index.NOT_ANALYZED));
								docextras.add(new Field("Cat",cat,Field.Store.YES,Field.Index.ANALYZED));
								// docextras.add(new Field("Score",score, Field.Store.YES,Field.Index.ANALYZED));
								index.addDocument(docextras);
							}
						} catch (Exception e) {
							System.out.println("Error processing the <Term> ('\t' <Category 1> '\t' <Score 1>)* line :"+line);
						}
						line = br.readLine();
						if(toLowerCaseTerms&&line!=null)
							line = line.toLowerCase();
					}
				}
			}catch (FileNotFoundException e) {System.out.println(inputFilenames[i] + " were not opened or found."); return false;
			}catch (IOException e) {System.out.println(inputFilenames[i] + "'s lines could not be read."); return false;}
		}
		index.close();
		
		System.out.println("\n------------------------------------------------------");
		System.out.println("Preliminary Index Created. Now Initializing Merging...");
		System.out.println("------------------------------------------------------");
		createFinalIndex(terms,mergedOutputIndexPath, debugFile);
		return true;
	}
	
	/**
	 * Take the compilation of the lists - HashMaps containing the distinct terms
	 * Iterate through the lists and assign values
	 * @throws Exception 
	 */
	public static void createFinalIndex(HashMap<String, Boolean> terms, String outputIndexPath, String debugFile) throws Exception
	{
		IndexWriter index = null;		
		if(analyzer.equals(AnalyzerTypes.Standard)||analyzer.equals(AnalyzerTypes.ExactMatch))
			index = new IndexWriter(FSDirectory.getDirectory(outputIndexPath), new StandardAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);
		if(analyzer.equals(AnalyzerTypes.Simple))
			index = new IndexWriter(FSDirectory.getDirectory(outputIndexPath), new SimpleAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);
		if(analyzer.equals(AnalyzerTypes.StopWords))
			index = new IndexWriter(FSDirectory.getDirectory(outputIndexPath), new StopAnalyzer(), IndexWriter.MaxFieldLength.LIMITED); 
		if(analyzer.equals(AnalyzerTypes.Whitespace))
			index = new IndexWriter(FSDirectory.getDirectory(outputIndexPath), new WhitespaceAnalyzer(), IndexWriter.MaxFieldLength.LIMITED);
		if(index==null)
			throw new Exception("The index is null!!!");
				
		Iterator<String> distinctTerms = terms.keySet().iterator();
		
		IndexSearcher searcher = new IndexSearcher(prelim);

		BufferedWriter out = new BufferedWriter( new FileWriter(debugFile));
		int count = 0;
		/**
		 * Iterating through all the distinct terms in hash map
		 */
		while(distinctTerms.hasNext())
		{
			if(count++%1000==0)
				System.out.println("Merging cats for term "+count+" out of "+terms.size());
			
			String term = distinctTerms.next().toString();
			Document main = new Document();
			if(analyzer.equals(AnalyzerTypes.ExactMatch)) 
				main.add(new Field("Term",term,Field.Store.YES,Field.Index.NOT_ANALYZED));
			else 
				main.add(new Field("Term",term,Field.Store.YES,Field.Index.ANALYZED));

			/**
			 * Instantiating all of the category fields to 0
			 */
			Term t = new Term("Term",term);
			Query query = new TermQuery(t);
			Hits hits = searcher.search(query);
			// HashMap<String,Double> catScores = new HashMap<String, Double>();
			HashMap<String,Boolean> cats = new HashMap<String, Boolean>();
			for(int j = 0; j < hits.length(); j++) {
				Document doc = hits.doc(j);
				//double score = 1.0;
				// try { score = Double.parseDouble(doc.get("Score")); }	catch(NumberFormatException e){System.out.println(doc.get("Score"));score = 1;}
				String cat = doc.get("Cat");
				// catScores.put(cat, score);
				cats.put(cat, true);
			}
			//String catsAndScores = "";
			//for (Iterator iterator = catScores.keySet().iterator(); iterator.hasNext();) {
			//	String cat = (String) iterator.next();
			//	catsAndScores  += "\t"+cat+" \t"+catScores.get(cat);				
			//}
			String catsString = "";
			for (Iterator iterator = cats.keySet().iterator(); iterator.hasNext();) {
				String cat = (String) iterator.next();
				catsString  += "\t"+cat;				
			}
			if(catsString.length()>1000)
				System.out.println("Warning -- huge field : "+catsString); 
			//main.add(new Field("CategoriesAndScores",catsAndScores,Field.Store.YES,Field.Index.NOT_ANALYZED));
			main.add(new Field("Categories",catsString,Field.Store.YES,Field.Index.NOT_ANALYZED));
			out.write(term +"\t"+catsString+"\n");
			index.addDocument(main);
		}
		out.close();
		searcher.close();
		index.close();
	
		System.out.println("\n\n-------------------------------------------------------");
		System.out.println("Merged Index Created-----------------------------------");
		System.out.println("-------------------------------------------------------");
	}
	
	
	
	/**
	 * Used this to avoid having to delete files every time.	
	 * Searched through a forum for help with this
	 */
	public static  boolean emptyIndexFiles(File dir) {
		if (dir.isDirectory())
		{
			String[] subfiles = dir.list();
			for (String s : subfiles)
			{
				boolean deleted = emptyIndexFiles(new File(dir, s));
				if (!deleted)
				{
					return false;
				}
			}
		}
		return dir.delete();
	}
	
	/**
	 * Extra method for seeing the HashMap contents
	 * TODO: For debugging
	 */
	public static void printHashContents(HashMap<String,Boolean> hash, String s)
	{
		System.out.println("The contents of " + s + " are: ");
		Iterator<String> it = hash.keySet().iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}
	
	/**
	 * Delete old merged index
	 */
	public static void deleteIndex(String path)
	{
		emptyIndexFiles(new File(path));
	}
	
	
	public static  GazetteeFormats getFileType(String s1) throws IOException {
		BufferedReader r = new BufferedReader(new FileReader(s1));
		String line = r.readLine();
		int maxColumns = 0;
		int lineCount = 0;
		while(line!=null&&lineCount++<100) {
			StringTokenizer s = new StringTokenizer(line,"\t");
			maxColumns=Math.max(s.countTokens(), maxColumns);
			line = r.readLine();
		}
		if(maxColumns>1) {
			System.out.println("File "+s1+" is a  list with categories");
			return GazetteeFormats.ListWithCategories;
		}
		else {
			System.out.println("File "+s1+" is a simple list");
			return GazetteeFormats.SimpleList;
		}
	}	

	/**
	 * Sample method for this Indexer - filenames is a string array containing files to be merged.
	 * Initialize the Indexer via simple constructor or with a parameter of integer
	 * Indexer will take given input files and supply a final index as stated by 'merged' constant 
	 * @param unimportant
	 * @throws Exception 
	 */
	public static void main(String args[]) throws Exception
	{
		String[] fileNames = (new File("/shared/corpora/ratinov2/NER/Data/KnownLists")).list();
						///{"city1.lst","city2.lst","weightedList.txt","names.lst"};
		deleteIndex(prelim);
		deleteIndex("/shared/corpora/ratinov2/NER/Data/GazetteersIndex/MergedIndex");
		mergeFiles("/shared/corpora/ratinov2/NER/Data/KnownLists", fileNames, 
				"/shared/corpora/ratinov2/NER/Data/GazetteersIndex/MergedIndex", false, 
				"/shared/corpora/ratinov2/NER/Data/GazetteersIndex/termsCategores.debug.txt");
		deleteIndex("/shared/corpora/ratinov2/NER/Data/GazetteersIndex/MergedIndexIgnoreCase");
		mergeFiles("/shared/corpora/ratinov2/NER/Data/KnownLists", fileNames, 
				"/shared/corpora/ratinov2/NER/Data/GazetteersIndex/MergedIndexIgnoreCase", true, 
				"/shared/corpora/ratinov2/NER/Data/GazetteersIndex/termsCategores.debugIC.txt");
	}
}
