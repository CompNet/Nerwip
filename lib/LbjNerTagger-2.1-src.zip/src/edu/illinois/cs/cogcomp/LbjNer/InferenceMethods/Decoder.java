package edu.illinois.cs.cogcomp.LbjNer.InferenceMethods;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.*; 

import java.util.*;

import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.TwoLayerAggregationFeaturesOld;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.TwoLayerPredictionAggregationFeatures;
import LBJ2.learn.SparseNetworkLearner;
import LBJ2.nlp.Word;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.TextChunkRepresentationManager;


public class Decoder
{
		
	/*
	 * 
	 * If you don't wanna use some of the classifiers - pass null parameters. 
	 * 
	 */
	public static void annotateDataBIO(Data data,
			NETaggerLevel1 taggerLevel1,
			NETaggerLevel2 taggerLevel2) throws Exception{
		long time =System.currentTimeMillis();
		Decoder.annotateBIO_AllLevelsWithTaggers(data,taggerLevel1, taggerLevel2);
		//		System.out.println("Inference time: "+(System.currentTimeMillis()-time)+" milliseconds");
	}
	
	/*
	 * 
	 *  use taggerLevel2=null if you want to use only one level of inference
	 * 
	 */
	protected static void annotateBIO_AllLevelsWithTaggers(Data data,
			NETaggerLevel1 taggerLevel1,
			NETaggerLevel2 taggerLevel2) throws Exception {
	    //		System.out.println("Annontating data with the models tagger, the inference algoritm is: "+ParametersForLbjCode.currentParameters.inferenceMethod.toString());
		clearPredictions(data);
		NETaggerLevel1.isTraining=false;
		NETaggerLevel2.isTraining=false;		
		
		
		if(ParametersForLbjCode.currentParameters.inferenceMethod==ParametersForLbjCode.InferenceMethods.GREEDY)
			GreedyDecoding.annotateGreedy(data,taggerLevel1,1);
		if(ParametersForLbjCode.currentParameters.inferenceMethod==ParametersForLbjCode.InferenceMethods.BEAMSEARCH)
			BeamsearchDecoding.annotateBeamsearch(data,taggerLevel1,1);
		if(ParametersForLbjCode.currentParameters.inferenceMethod==ParametersForLbjCode.InferenceMethods.VITERBI)
			ViterbiDecoding.annotateViterbiSecondOrder(data,taggerLevel1,1);
		
		TextChunkRepresentationManager.changeChunkRepresentation(
				ParametersForLbjCode.currentParameters.taggingEncodingScheme, 
				TextChunkRepresentationManager.EncodingScheme.BIO, 
				data, NEWord.LabelToLookAt.PredictionLevel1Tagger);

		
		PredictionsAndEntitiesConfidenceScores.pruneLowConfidencePredictions(data, ParametersForLbjCode.currentParameters.minConfidencePredictionsLevel1, NEWord.LabelToLookAt.PredictionLevel1Tagger);

		if(taggerLevel2!=null&&(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PatternFeatures")||ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1"))){
			//annotate with patterns
			if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")){
				//TwoLayerAggregationFeaturesOld.aggregateLevel1Predictions(data);
				//TwoLayerAggregationFeaturesOld.aggregateEntityLevelPredictions(data);
				PredictionsAndEntitiesConfidenceScores.pruneLowConfidencePredictions(data, 0.0, NEWord.LabelToLookAt.PredictionLevel1Tagger);
		    	//PredictionsAndEntitiesConfidenceScores.annotateWithGoldLabelsWithOmissions(data, 0, 0);
		    	TwoLayerPredictionAggregationFeatures.setLevel1AggregationFeatures(data, false,"testing time- inference time");
			}
			if(ParametersForLbjCode.currentParameters.inferenceMethod==ParametersForLbjCode.InferenceMethods.GREEDY)
				GreedyDecoding.annotateGreedy(data,taggerLevel2,2);
			if(ParametersForLbjCode.currentParameters.inferenceMethod==ParametersForLbjCode.InferenceMethods.BEAMSEARCH)
				BeamsearchDecoding.annotateBeamsearch(data,taggerLevel2,2);
			if(ParametersForLbjCode.currentParameters.inferenceMethod==ParametersForLbjCode.InferenceMethods.VITERBI)
				ViterbiDecoding.annotateViterbiSecondOrder(data,taggerLevel2,2);
			PredictionsAndEntitiesConfidenceScores.pruneLowConfidencePredictions(data, ParametersForLbjCode.currentParameters.minConfidencePredictionsLevel2, NEWord.LabelToLookAt.PredictionLevel2Tagger);
			TextChunkRepresentationManager.changeChunkRepresentation(
					ParametersForLbjCode.currentParameters.taggingEncodingScheme, 
					TextChunkRepresentationManager.EncodingScheme.BIO, 
					data, NEWord.LabelToLookAt.PredictionLevel2Tagger);
		}
		else
		{
			for(int docid=0;docid<data.documents.size();docid++) {
				Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
				for (int k=0;k<sentences.size();k++)
					for (int i = 0; i < sentences.elementAt(k).size(); i++){
						NEWord w=(NEWord)sentences.elementAt(k).get(i);
						w.neTypeLevel2=w.neTypeLevel1;
					}
			}
		}
		//		System.out.println("Done Annontating data with the models tagger, the inference algoritm is: "+ParametersForLbjCode.currentParameters.inferenceMethod.toString());
	}
	
	/*
	 * Lbj does some pretty annoying caching. We need this method for the beamsearch and the viterbi. 
	 */
	public static void nullifyTaggerCachedFields(SparseNetworkLearner tagger){
		NEWord w=new NEWord(new Word("lala1"),null,"O");
		w.parts=new String[0];
		NEWord[] words={new NEWord(w,null,"O"),new NEWord(w,null,"O"),new NEWord(w,null,"O"),new NEWord(w,null,"O"),new NEWord(w,null,"O"),new NEWord(w,null,"O"),new NEWord(w,null,"O")};
		for(int i=1;i<words.length;i++){
			words[i].parts=new String[0];
			words[i].previous=words[i-1];
			words[i].previousIgnoreSentenceBoundary=words[i-1];
			words[i-1].next=words[i];
			words[i-1].nextIgnoreSentenceBoundary=words[i];
		}
		for(int i=0;i<words.length;i++)
			words[i].neTypeLevel1=words[i].neTypeLevel2="O";
		tagger.classify(words[3]);
	}

	public static void clearPredictions(Data data){
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for (int k=0;k<sentences.size();k++){
				for(int i=0;i<sentences.elementAt(k).size();i++){
					((NEWord)sentences.elementAt(k).get(i)).neTypeLevel1=null;
					((NEWord)sentences.elementAt(k).get(i)).neTypeLevel2=null;
				}
			}
		}		
	}
}

