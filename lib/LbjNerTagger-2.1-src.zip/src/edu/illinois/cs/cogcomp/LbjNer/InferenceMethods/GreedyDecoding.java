package edu.illinois.cs.cogcomp.LbjNer.InferenceMethods;


import java.util.*; 

import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.CharacteristicWords;



class GreedyDecoding
{
	/*
	 * This is the simplest greedy left-to right annotation.
	 */
	public static void annotateGreedy(Data data,SparseNetworkLearner tagger,int inferenceLayer) throws Exception{
		if(inferenceLayer!=1&&inferenceLayer!=2){
			Exception e=new Exception("Terrible error- nonexisting inference layer");
			throw e;
		}		
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for (int k=0;k<sentences.size();k++){
				for (int i = 0; i < sentences.elementAt(k).size() ; ++i)
				{
					NEWord w=(NEWord)sentences.elementAt(k).get(i);
					if(inferenceLayer==1)
						PredictionsToProbabilities.getAndSetPredictionConfidences(tagger, w,NEWord.LabelToLookAt.PredictionLevel1Tagger);//this will set the label of w.neTypeLevel1 to the max prediction...	 
					else
						PredictionsToProbabilities.getAndSetPredictionConfidences(tagger, w,NEWord.LabelToLookAt.PredictionLevel2Tagger);//this will set the label of w.neTypeLevel1 to the max prediction...
				}
			}
		}			    
	}
}

