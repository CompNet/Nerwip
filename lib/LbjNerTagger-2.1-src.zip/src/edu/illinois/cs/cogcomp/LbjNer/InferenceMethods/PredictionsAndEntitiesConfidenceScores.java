package edu.illinois.cs.cogcomp.LbjNer.InferenceMethods;

import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.TwoLayerPredictionAggregationFeatures;
import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel1;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel2;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NERDocument;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NETesterMultiDataset;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NamedEntity;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Parameters;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData.TaggedDataReader;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.CharacteristicWords;

/*
 * This class is responsible for handling prediction scores of the entities. That is, this class can prune the entities/predictions on which we're not confident at
 * 
 *  This class also allows to annotate the data with gold named entities, where the gold label is
 *  sometimes erased. This is for supporting the 2 layered inference procedure.
 * 
 */
public class PredictionsAndEntitiesConfidenceScores {

	/*
	 * This function assumes that the data is already tagged with the confidence scores
	 */
	public static void pruneLowConfidencePredictions(Data data,double minConfScore,NEWord.LabelToLookAt predictionsToLookAt) throws Exception{
		Vector<NamedEntity> entities = getAndMarkEntities(data, predictionsToLookAt);
		//System.out.println(entities.size()+" entities were annotated");
		for(int i=0;i<entities.size();i++){
			double confStart=-1;
			if(predictionsToLookAt.equals(NEWord.LabelToLookAt.PredictionLevel1Tagger))
				confStart=getMaxConfidence(entities.elementAt(i).tokens.elementAt(0).predictionConfidencesLevel1Classifier);
			if(predictionsToLookAt.equals(NEWord.LabelToLookAt.PredictionLevel2Tagger))
				confStart=getMaxConfidence(entities.elementAt(i).tokens.elementAt(0).predictionConfidencesLevel2Classifier);
			double confEnd=-1;
			if(predictionsToLookAt.equals(NEWord.LabelToLookAt.PredictionLevel1Tagger))
				confEnd=getMaxConfidence(entities.elementAt(i).tokens.elementAt(entities.elementAt(i).tokens.size()-1).predictionConfidencesLevel1Classifier);
			if(predictionsToLookAt.equals(NEWord.LabelToLookAt.PredictionLevel2Tagger))
				confEnd=getMaxConfidence(entities.elementAt(i).tokens.elementAt(entities.elementAt(i).tokens.size()-1).predictionConfidencesLevel2Classifier);
			//System.out.println("start="+confStart+"; end= "+confEnd+" ;Start*End="+(confEnd*confStart));
			//System.out.println("*Enity : "+entities.elementAt(i).form+" type "+entities.elementAt(i).type+" ; conf = "+Math.sqrt(confEnd*confStart));
			if(Math.sqrt(confEnd*confStart)<minConfScore)
				for(int j=0;j<entities.elementAt(i).tokens.size();j++){
					if(predictionsToLookAt==NEWord.LabelToLookAt.PredictionLevel1Tagger)
						entities.elementAt(i).tokens.elementAt(j).neTypeLevel1="O";
					if(predictionsToLookAt==NEWord.LabelToLookAt.PredictionLevel2Tagger)
						entities.elementAt(i).tokens.elementAt(j).neTypeLevel2="O";
					entities.elementAt(i).tokens.elementAt(j).predictedEntity=null;
				}
		}
	}

	private static double getMaxConfidence(CharacteristicWords confidences) {
		if(confidences.topScores.size()==0)
			return 0;				
		double max=confidences.topScores.elementAt(0);
		for(int i=0;i<confidences.topScores.size();i++)
			if(max<confidences.topScores.elementAt(i)){
				max=confidences.topScores.elementAt(i);
			}
		//System.out.println("max="+max);
		return max;
	}

	/*
	 * Assumes BIO - annotated data
	 */
	public static Vector<NamedEntity> getAndMarkEntities(Data data,NEWord.LabelToLookAt predictionType) throws Exception {
		Vector<NamedEntity> res=new Vector<NamedEntity>();
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for(int i=0;i<sentences.size();i++)
				for(int j=0;j<sentences.elementAt(i).size();j++){
					NEWord w=(NEWord)sentences.elementAt(i).get(j);
					w.predictedEntity=null;
					w.goldEntity=null;
				}
		}
		int startSentence=-1;
		int startToken=-1;
		int startAbsIndex=-1;
		int absTokenId=0;
		String type="O";
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for(int i=0;i<sentences.size();i++)
				for(int j=0;j<sentences.elementAt(i).size();j++){
					NEWord w=(NEWord)sentences.elementAt(i).get(j);
					String label=w.neLabel;
					if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel1Tagger))
						label=w.neTypeLevel1;
					if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel2Tagger))
						label=w.neTypeLevel2;
					String nextLabel="O";
					if(w.nextIgnoreSentenceBoundary!=null){
						if(predictionType.equals(NEWord.LabelToLookAt.GoldLabel))
							nextLabel =w.nextIgnoreSentenceBoundary.neLabel;
						if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel1Tagger))
							nextLabel=w.nextIgnoreSentenceBoundary.neTypeLevel1;
						if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel2Tagger))
							nextLabel=w.nextIgnoreSentenceBoundary.neTypeLevel2;
					}
					if(startSentence==-1&&label.startsWith("B-")){
						startSentence=i;
						startToken=j;
						startAbsIndex=absTokenId;
						type=label.substring(2);
					}
					if(startSentence!=-1&&(!nextLabel.startsWith("I-"))){
						NamedEntity e=new NamedEntity(sentences,startAbsIndex,startSentence,startToken,i,j);
						e.type=type;
						res.addElement(e);
						if(predictionType.equals(NEWord.LabelToLookAt.GoldLabel))
							for(int k=0;k<e.tokens.size();k++)
								e.tokens.elementAt(k).goldEntity=e;
						if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel1Tagger)||predictionType.equals(NEWord.LabelToLookAt.PredictionLevel2Tagger))
							for(int k=0;k<e.tokens.size();k++)
								e.tokens.elementAt(k).predictedEntity=e;
						startSentence=startToken=-1;
					}
					absTokenId++;
				}
		}
		return res;
	}
	public static void main(String[] args) throws Exception{
		Parameters.readConfigAndLoadExternalData("JournalConfigChunkRep/baselineBILOU.config");
		//Vector<LinkedVector> data = TaggedDataReader.readFile("Data/GoldData/Reuters/ColumnFormatDocumentsSplit/Test/0005.txt","-c");
		 Data data = new Data("../../Data/GoldData/Reuters/ColumnFormatDocumentsSplit/Train","CoNLL_Train","-c", new Vector<String>(),new Vector<String>());
		//getAndMarkEntities(data,NEWord.LabelToLookAt.GoldLabel);
		//annotateWithGoldLabelsWithOmissions(data,0.2,0.1);
		getAndMarkEntities(data,NEWord.LabelToLookAt.GoldLabel);
		TwoLayerPredictionAggregationFeatures.setLevel1AggregationFeatures(data, true,"testig with gold data");

		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for(int i=0;i<sentences.size();i++)
				for(int j=0;j<sentences.elementAt(i).size();j++){
				NEWord w=(NEWord)sentences.elementAt(i).get(j);
								System.out.print(w.form+" \tgold="+w.neLabel+"\t");
				if(w.goldEntity!=null)
					System.out.print(w.goldEntity.type+"\t");
				else
					System.out.print("O\t");
				if(w.level1AggregationFeatures.size()>0){
					System.out.print("< ");
					for(int k=0;k<w.level1AggregationFeatures.size();k++)
						System.out.print(w.level1AggregationFeatures.elementAt(k)+" ");
					System.out.print("> ");
				}
				System.out.println();
			}
		}
		//System.exit(0);
		System.out.println("----------------------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------------------");
		System.out.println("----------------------------------------------------------------------------------------");
		data = new Data("../../Data/GoldData/Reuters/ColumnFormatDocumentsSplit/Test","CoNLL_Test","-c", new Vector<String>(),new Vector<String>());
		Parameters.loadClassifierModels(ParametersForLbjCode.currentParameters);
		Decoder.annotateBIO_AllLevelsWithTaggers(data, (NETaggerLevel1)ParametersForLbjCode.currentParameters.taggerLevel1,null);
		pruneLowConfidencePredictions(data,0.99999,NEWord.LabelToLookAt.PredictionLevel1Tagger);
		for(int docid=0;docid<data.documents.size();docid++) {
			Vector<LinkedVector> sentences = data.documents.elementAt(docid).sentences; 
			for(int i=0;i<sentences.size();i++)
				for(int j=0;j<sentences.elementAt(i).size();j++){
					NEWord w=(NEWord)sentences.elementAt(i).get(j);
					w.neTypeLevel2=w.neTypeLevel1;
				}
		}
		Vector<Data> v=new Vector<Data>();
		v.addElement(data);
		NETesterMultiDataset.printTestResultsByDataset(v, true);
	}
}
