package edu.illinois.cs.cogcomp.LbjNer.InferenceMethods;

import LBJ2.classify.*;
import LBJ2.learn.*;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.CharacteristicWords;

class PredictionsToProbabilities
{
    private static boolean DEBUG = false;
    private static final String NAME = PredictionsToProbabilities.class.getCanonicalName();

	public static CharacteristicWords getAndSetPredictionLogConfidences(SparseNetworkLearner c,NEWord w,NEWord.LabelToLookAt predictionType){
	    if ( null == c )
		System.err.println( "ERROR: PredictionsToProbabilities.CharacteristicWords(): null learner." );

		CharacteristicWords confs=getAndSetPredictionConfidences(c, w,predictionType);
		CharacteristicWords res=new CharacteristicWords(-1);
		for(int i=0;i<confs.topScores.size();i++)
			res.addElement(confs.topWords.elementAt(i), Math.log(confs.topScores.elementAt(i)));
		return res;
	}
	public static CharacteristicWords getAndSetPredictionConfidences(SparseNetworkLearner c,NEWord w,NEWord.LabelToLookAt predictionType){
	
	    if ( null == c )
		System.err.println( "ERROR: PredictionsToProbabilities.CharacteristicWords(): null learner." );
	Score[] scores= c.scores(w).toArray();
		if ( DEBUG )
		    System.err.println("## " + NAME + ".getAndSetPredictionConfidences(): c.scores: " + c.scores(w) );
		double[] correctedScores=new double[scores.length];
		double min=scores[0].score;
		int maxScoreIdx=0;
		double maxScore=scores[maxScoreIdx].score;
		String maxLabel=scores[maxScoreIdx].value;
		for(int i=0;i<scores.length;i++){
			if(min>scores[i].score)
				min=scores[i].score;
			if(maxScore<scores[i].score){
				maxScore=scores[i].score;
				maxScoreIdx=i;
				maxLabel=scores[i].value;
			}
		}
		for(int i=0;i<scores.length;i++)
			correctedScores[i]=scores[i].score-min;
		double sum=0;
		for(int i=0;i<correctedScores.length;i++)
		{			  
			correctedScores[i]=Math.exp(correctedScores[i]);
			sum+=correctedScores[i];
		}
		if(sum>0)
			for(int i=0;i<correctedScores.length;i++)
				correctedScores[i]/=sum;
		for(int i=0;i<correctedScores.length;i++)
			correctedScores[i]=correctedScores[i];
		CharacteristicWords res=new CharacteristicWords(scores.length);
		for(int i=0;i<scores.length;i++)
			res.addElement(scores[i].value, correctedScores[i]);
		if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel1Tagger)){
			w.neTypeLevel1=maxLabel;
			w.predictionConfLevel1=correctedScores[maxScoreIdx];
			w.predictionConfidencesLevel1Classifier=res;
		}
		if(predictionType.equals(NEWord.LabelToLookAt.PredictionLevel2Tagger)){
			w.neTypeLevel2=maxLabel;
			w.predictionConfLevel2=correctedScores[maxScoreIdx];
			w.predictionConfidencesLevel2Classifier=res;
		}
		return res;
	}
}

