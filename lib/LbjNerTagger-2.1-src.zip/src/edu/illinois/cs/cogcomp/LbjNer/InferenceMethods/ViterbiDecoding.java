package edu.illinois.cs.cogcomp.LbjNer.InferenceMethods;


import LBJ2.learn.*;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;

class ViterbiDecoding
{
		
	public static void annotateViterbiSecondOrder(Data data,
			SparseNetworkLearner tagger,int inferenceLayer)throws Exception
	{
		throw new Exception("Viterbi decoding is buggy and disabled");
	}
}

