// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B88000000000000000560915B43C03017CFBAC93074B4D601F1D4BE3834F541928A8F036F017DB67925391779AD988FDDD4ADDCE894021E27FFBFDFFEEA4DCB624787E07B46B73B86B367845827B1E8E9EEEDC2590DBFB268C258F60D514458225F1EB288FED2D3EB73B0B52A85774486CD493151A27D112FB8D756F97B6C92D68F10FB2A9DF37A95C1708B170A52C1C512F1C9F20A55CE6F1848AC2144AD787921434693C51CC7E3A4EC2703D5BDA48421D187BFABDF811F01B038B3721E7E4837309E0C9E5C690F35BDE872A5A9E04BEF81539EEF852DB2C7D403197A2E06A181FCE84B9A79B28D689ADB6E8731C2A64750165A778C15F1F1665FB5966CE3B18C6CA41D2A9ADD6CFF42940E23A164F36C5F89E563BA0D69E4290F8F3FBA7AA8E5A5E100000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class BrownClusterPaths extends Classifier
{
  public BrownClusterPaths()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "BrownClusterPaths";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "discrete%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'BrownClusterPaths(NEWord)' defined on line 238 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    String __value;

    if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("BrownClusterPaths"))
    {
      int i;
      NEWord w = word, last = word;
      for (i = 0; i <= 2 && last != null; ++i)
      {
        last = (NEWord) last.next;
      }
      for (i = 0; i > -2 && w.previous != null; --i)
      {
        w = (NEWord) w.previous;
      }
      for (; w != last; w = (NEWord) w.next)
      {
        String[] paths = BrownClusters.getPrefixes(w);
        for (int j = 0; j < paths.length; j++)
        {
          __id = "" + (i);
          __value = "" + (paths[j]);
          __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
        }
        i++;
      }
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'BrownClusterPaths(NEWord)' defined on line 238 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "BrownClusterPaths".hashCode(); }
  public boolean equals(Object o) { return o instanceof BrownClusterPaths; }
}

