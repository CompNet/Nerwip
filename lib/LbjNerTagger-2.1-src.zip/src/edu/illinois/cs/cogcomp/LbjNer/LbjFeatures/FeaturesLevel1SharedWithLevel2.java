// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// mixed% FeaturesLevel1SharedWithLevel2(NEWord word) <- FeaturesSharedTemp

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class FeaturesLevel1SharedWithLevel2 extends Classifier
{
  private static final FeaturesSharedTemp __FeaturesSharedTemp = new FeaturesSharedTemp();

  public FeaturesLevel1SharedWithLevel2()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "FeaturesLevel1SharedWithLevel2";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "mixed%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'FeaturesLevel1SharedWithLevel2(NEWord)' defined on line 487 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    FeatureVector __result;
    __result = __FeaturesSharedTemp.classify(__example);
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'FeaturesLevel1SharedWithLevel2(NEWord)' defined on line 487 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "FeaturesLevel1SharedWithLevel2".hashCode(); }
  public boolean equals(Object o) { return o instanceof FeaturesLevel1SharedWithLevel2; }
}

