// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B88000000000000000BCDCCA84D4155507B4D4C292D2A4D26F94D2B4DC132D0F37D0FCF2A415827021A9A063ABA010549A56999F5A5C12989E109852529A54970158A3A09302AD0D13D3DB8253D31B4233F3F06629E02B6234892742133289851005C08CF267BCF227ECFCB294DA82189C0AABA4545C41358CC0358CC5741000F1DA3B716D000000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class FeaturesLevel2 extends Classifier
{
  private static final PreviousTagPatternLevel2 __PreviousTagPatternLevel2 = new PreviousTagPatternLevel2();
  private static final level1AggregationFeatures __level1AggregationFeatures = new level1AggregationFeatures();
  private static final PreviousTag1Level2 __PreviousTag1Level2 = new PreviousTag1Level2();
  private static final PreviousTag2Level2 __PreviousTag2Level2 = new PreviousTag2Level2();
  private static final prevTagsForContextLevel2 __prevTagsForContextLevel2 = new prevTagsForContextLevel2();
  private static final FeaturesLevel2$$5 __FeaturesLevel2$$5 = new FeaturesLevel2$$5();
  private static final FeaturesLevel2$$6 __FeaturesLevel2$$6 = new FeaturesLevel2$$6();
  private static final FeaturesLevel2$$7 __FeaturesLevel2$$7 = new FeaturesLevel2$$7();

  public FeaturesLevel2()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "FeaturesLevel2";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "mixed%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'FeaturesLevel2(NEWord)' defined on line 673 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    FeatureVector __result;
    __result = new FeatureVector();
    __result.addFeatures(__PreviousTagPatternLevel2.classify(__example));
    __result.addFeatures(__level1AggregationFeatures.classify(__example));
    __result.addFeatures(__PreviousTag1Level2.classify(__example));
    __result.addFeatures(__PreviousTag2Level2.classify(__example));
    __result.addFeatures(__prevTagsForContextLevel2.classify(__example));
    __result.addFeatures(__FeaturesLevel2$$5.classify(__example));
    __result.addFeatures(__FeaturesLevel2$$6.classify(__example));
    __result.addFeatures(__FeaturesLevel2$$7.classify(__example));
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'FeaturesLevel2(NEWord)' defined on line 673 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "FeaturesLevel2".hashCode(); }
  public boolean equals(Object o) { return o instanceof FeaturesLevel2; }

  public java.util.LinkedList getCompositeChildren()
  {
    java.util.LinkedList result = new java.util.LinkedList();
    result.add(__PreviousTagPatternLevel2);
    result.add(__level1AggregationFeatures);
    result.add(__PreviousTag1Level2);
    result.add(__PreviousTag2Level2);
    result.add(__prevTagsForContextLevel2);
    result.add(__FeaturesLevel2$$5);
    result.add(__FeaturesLevel2$$6);
    result.add(__FeaturesLevel2$$7);
    return result;
  }
}

