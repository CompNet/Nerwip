// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B8800000000000000058E4D5B62C0401CFB27F250584FF18F2535D22888811AFCB6E6257DE56F2CED64BAFBED312218E34BF2BF13B333B3D2FF0CFB8B528CA754AAE84A0FB74BDD463B8FC8AEDD52799AB9DBAB53BC73D1830BD5B07BA4514C0253A2325B2C594D1B150EB1917492C944957CA92C3D8B07F14738910A964C6915BDD66DF036E6F8F9BFB67859439181CCEDA9627CCC7D9B6CB8491AF460DD29D1701C2AD30CB769FA1D992FEF01F890ED935DA03C62A4915E4DB4D6C76CF5CCF786B3058FD66776897E638F4100000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class FeaturesSharedTemp extends Classifier
{
  private static final Linkability __Linkability = new Linkability();
  private static final IsSentenceStart __IsSentenceStart = new IsSentenceStart();
  private static final Capitalization __Capitalization = new Capitalization();
  private static final nonLocalFeatures __nonLocalFeatures = new nonLocalFeatures();
  private static final GazetteersFeatures __GazetteersFeatures = new GazetteersFeatures();
  private static final FormParts __FormParts = new FormParts();
  private static final Forms __Forms = new Forms();
  private static final WordTypeInformation __WordTypeInformation = new WordTypeInformation();
  private static final Affixes __Affixes = new Affixes();
  private static final BrownClusterPaths __BrownClusterPaths = new BrownClusterPaths();
  private static final WordEmbeddingFeatures __WordEmbeddingFeatures = new WordEmbeddingFeatures();
  private static final additionalFeaturesDiscreteNonConjunctive __additionalFeaturesDiscreteNonConjunctive = new additionalFeaturesDiscreteNonConjunctive();
  private static final additionalFeaturesDiscreteConjunctive __additionalFeaturesDiscreteConjunctive = new additionalFeaturesDiscreteConjunctive();
  private static final additionalFeaturesRealNonConjunctive __additionalFeaturesRealNonConjunctive = new additionalFeaturesRealNonConjunctive();

  public FeaturesSharedTemp()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "FeaturesSharedTemp";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "mixed%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'FeaturesSharedTemp(NEWord)' defined on line 485 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    FeatureVector __result;
    __result = new FeatureVector();
    __result.addFeatures(__Linkability.classify(__example));
    __result.addFeatures(__IsSentenceStart.classify(__example));
    __result.addFeatures(__Capitalization.classify(__example));
    __result.addFeatures(__nonLocalFeatures.classify(__example));
    __result.addFeatures(__GazetteersFeatures.classify(__example));
    __result.addFeatures(__FormParts.classify(__example));
    __result.addFeatures(__Forms.classify(__example));
    __result.addFeatures(__WordTypeInformation.classify(__example));
    __result.addFeatures(__Affixes.classify(__example));
    __result.addFeatures(__BrownClusterPaths.classify(__example));
    __result.addFeatures(__WordEmbeddingFeatures.classify(__example));
    __result.addFeatures(__additionalFeaturesDiscreteNonConjunctive.classify(__example));
    __result.addFeatures(__additionalFeaturesDiscreteConjunctive.classify(__example));
    __result.addFeatures(__additionalFeaturesRealNonConjunctive.classify(__example));
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'FeaturesSharedTemp(NEWord)' defined on line 485 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "FeaturesSharedTemp".hashCode(); }
  public boolean equals(Object o) { return o instanceof FeaturesSharedTemp; }

  public java.util.LinkedList getCompositeChildren()
  {
    java.util.LinkedList result = new java.util.LinkedList();
    result.add(__Linkability);
    result.add(__IsSentenceStart);
    result.add(__Capitalization);
    result.add(__nonLocalFeatures);
    result.add(__GazetteersFeatures);
    result.add(__FormParts);
    result.add(__Forms);
    result.add(__WordTypeInformation);
    result.add(__Affixes);
    result.add(__BrownClusterPaths);
    result.add(__WordEmbeddingFeatures);
    result.add(__additionalFeaturesDiscreteNonConjunctive);
    result.add(__additionalFeaturesDiscreteConjunctive);
    result.add(__additionalFeaturesRealNonConjunctive);
    return result;
  }
}

