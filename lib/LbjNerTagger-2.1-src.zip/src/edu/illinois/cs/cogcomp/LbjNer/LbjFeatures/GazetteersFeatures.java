// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B880000000000000005609F4B43013015CFBAC850B424CD02E1DD650115F0A88705C37CEECA669431942B64B2DFEEE46FF4B67DB40623F6E7FEDC45A3CAC364C368B55B1C8111D78B1451B5F818D3C5FB83F5142A783C2A08F10D530B745E5DA964848ECFDFB6375EA249BA6DB74B17FD395F049727FC18AFEC645AD68B3CF663BFF6533EC33DD640D0B483D2164B6AA2BDF90815122513462EDDFA4B8F51B48AD97063CC96850C91CC7EDBEF86906B536A40124763892427D3046B31CC5041D1729CF0F8F9AD5B16F4B2A8E869E02FCE4799559B1E8594EBDE69D110976B733AD7B9ED0B1ACDF75B238ED023E4D0122BE30AD0841BECF0558607D476FBC8CA1E9D77B0A58827A9C6CD03DBB6384992709CBA7F32FB019D2BC9730200000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class GazetteersFeatures extends Classifier
{
  public GazetteersFeatures()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "GazetteersFeatures";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "discrete%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'GazetteersFeatures(NEWord)' defined on line 124 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    String __value;

    if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("GazetteersFeatures"))
    {
      int i = 0;
      NEWord w = word, last = (NEWord) word.next;
      for (i = 0; i < 2 && last != null; ++i)
      {
        last = (NEWord) last.next;
      }
      for (i = 0; i > -2 && w.previous != null; --i)
      {
        w = (NEWord) w.previous;
      }
      do
      {
        if (w.gazetteers != null)
        {
          for (int j = 0; j < w.gazetteers.size(); j++)
          {
            __id = "" + (i);
            __value = "" + (w.gazetteers.elementAt(j));
            __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
          }
        }
        i++;
        w = (NEWord) w.next;
      }      while (w != last);

    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'GazetteersFeatures(NEWord)' defined on line 124 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "GazetteersFeatures".hashCode(); }
  public boolean equals(Object o) { return o instanceof GazetteersFeatures; }
}

