// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B88000000000000000D849D5B43C034168FFAC1B0E8E8AD2A7B663F66C40178C06E7C5A46BE9144BB44294DD688FFDD4AEE32D43DE6416096ED7F97FCEC934522D2E2162C8F72D93B289ED6CF43E73123785B9F9E3C0258F106B4887A452D51A649AEE58C9CCF364227CC615A498C5F1FE2B5225D5A445FC2E5499B71C5356C5D32E63E8C9C88AFD7B85EA18118D7E1C0BACCB2828A2DBB30185A09013337CB620C060348B18E5FEF5271340E56150184216697B3FDEEF04FBA376C173A90CFA7C9B384B2ECA3BF298FDC449AE84B43DA86B671574DD1854C82C87C6801F5C634D234127580192D45AE802131C7B6E67547333BF6C968CC6124229DBE197E535F897EDAADA8D3535CD96EB551D2CCCBCD0A6853016D43659AFA827B7E52FE59D84F0222051481064B533A3E2753D80074714860BA27C41EA6C9927201DBF3C82AECE98114370EE9130D907D6EDCEFC94D349DE5C7B25AB6D1A15B4DB177E4D35B65A753572DE4D298BCA3CE987C0700E9CB53634BA3E97B3BCE6BD2AA81C294CE7E5CC3F707004E2F169500000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class Linkability extends Classifier
{
  public Linkability()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "Linkability";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "real%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'Linkability(NEWord)' defined on line 203 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    double __value;

    if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("Linkability"))
    {
      int i;
      NEWord w = word, last = word;
      for (i = 0; i <= 1 && last != null; ++i)
      {
        last = (NEWord) last.next;
      }
      for (i = 0; i > -1 && w.previous != null; --i)
      {
        w = (NEWord) w.previous;
      }
      for (; w != last; w = (NEWord) w.next)
      {
        __id = "" + ("start" + i);
        __value = w.maxStartLinkabilityScore;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("end" + i);
        __value = w.maxEndLinkabilityScore;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("startPrev" + i);
        __value = w.maxStartLinkabilityScorePrevalent;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("endPrev" + i);
        __value = w.maxEndLinkabilityScorePrevalent;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("startVeryPrev" + i);
        __value = w.maxStartLinkabilityScoreVeryPrevalent;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("endVeryPrev" + i);
        __value = w.maxEndLinkabilityScoreVeryPrevalent;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("max" + i);
        __value = w.maxLinkability;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("maxPrev" + i);
        __value = w.maxLinkabilityPrevalent;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("maxVeryPrev" + i);
        __value = w.maxLinkabilityVeryPrevalent;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("start" + i + "_IC");
        __value = w.maxStartLinkabilityScore_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("end" + i + "_IC");
        __value = w.maxEndLinkabilityScore_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("startPrev" + i + "_IC");
        __value = w.maxStartLinkabilityScorePrevalent_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("endPrev" + i + "_IC");
        __value = w.maxEndLinkabilityScorePrevalent_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("startVeryPrev" + i + "_IC");
        __value = w.maxStartLinkabilityScoreVeryPrevalent_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("endVeryPrev" + i + "_IC");
        __value = w.maxEndLinkabilityScoreVeryPrevalent_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("max" + i + "_IC");
        __value = w.maxLinkability_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("maxPrev" + i + "_IC");
        __value = w.maxLinkabilityPrevalent_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        __id = "" + ("maxVeryPrev" + i + "_IC");
        __value = w.maxLinkabilityVeryPrevalent_IC;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        i++;
      }
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'Linkability(NEWord)' defined on line 203 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "Linkability".hashCode(); }
  public boolean equals(Object o) { return o instanceof Linkability; }
}

