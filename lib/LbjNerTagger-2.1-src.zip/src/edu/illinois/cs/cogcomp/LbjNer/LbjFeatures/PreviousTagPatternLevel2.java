// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B88000000000000000DC25D4B6201301DFB2360A2902D54C367BD24926F251B247BDE1B44774949895B946D5C61FFB772B9D5F305FE561278997F66EDB7B39B2733B8E1FA062617DAA82D56271319ED3A5332C53AE10F1F0F3A0B93454F808BDB68F505370E31965E29886DD3516743DFA7C227C4665A5B86CFEB79CC15AF2D2ABCA87374DF2C879AC8B76CD076796123128674BB51EE0A1502A6909CAA1A5A0FE833F58585542310D065D419B841E5DB556610A5E4153539DB0B4B65E514780A5A6D2A1B23E1294850AD8BE315E23B42298B100D2D9FE55884C0E8249358D20A67879169D665817C60CE90A38A80D8939D0EAC870545CE39C48B581047BBD00B1DBBB2428FD5A4DE839522F9AA7DB024B98121997E34D8B4AFD0CBA4860F29027C92E1448FF43F8D6DA3A574E4DF027107F0DF3B1947E423934D91B9EAC9ABAFC18F06F79147691EE28EC2EC5EF7CBD77137421F8324CE058132F70FC5908E10BF464F21638B9849828E8A5E0D09D76C0E6A582D7F72799536129300000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class PreviousTagPatternLevel2 extends Classifier
{
  public PreviousTagPatternLevel2()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "PreviousTagPatternLevel2";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "discrete%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'PreviousTagPatternLevel2(NEWord)' defined on line 634 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    String __value;

    if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PreviousTagPatternLevel2"))
    {
      NEWord w = (NEWord) word.previous;
      Vector pattern = new Vector();
      String label = "O";
      if (w != null)
      {
        if (NETaggerLevel2.isTraining)
        {
          label = ((NEWord) w).neLabel;
        }
        else
        {
          label = ((NEWord) w).neTypeLevel2;
        }
      }
      else
      {
        label = null;
      }
      for (int i = 0; i < 2 && label != null && label.equals("O"); i++)
      {
        pattern.addElement(w.form);
        w = (NEWord) w.previous;
        if (w != null)
        {
          if (NETaggerLevel2.isTraining)
          {
            label = ((NEWord) w).neLabel;
          }
          else
          {
            label = ((NEWord) w).neTypeLevel2;
          }
        }
        else
        {
          label = null;
        }
      }
      if (pattern.size() > 0 && label != null && !label.equals("O"))
      {
        label = label.substring(2);
        String res = "";
        for (int i = 0; i < pattern.size(); i++)
        {
          res = (String) pattern.elementAt(i) + "_" + res;
        }
        res = label + "_" + res;
        __id = "";
        __value = "" + (res);
        __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
      }
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'PreviousTagPatternLevel2(NEWord)' defined on line 634 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "PreviousTagPatternLevel2".hashCode(); }
  public boolean equals(Object o) { return o instanceof PreviousTagPatternLevel2; }
}

