// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B880000000000000005B19B5B430130158FFAC4B069D52E601F1D47501F6F6D721BFC1A99DA3ABD4A4E2D515CFFE62BD4FAF02A50904291233FD907E822733B8E1FC04A254E9C869DE30A4F1C2ABBBCF67B64FB60D33F4B2C2627F3536514717B216C51C72436C2414AD3434A0A68B01DF56CD7B0F93A64B2D3AAD0B63CED362774F18549DFC1365644EA548F1DC0439FCAFF0C6C61718ADFD8F222D3A605305C023887078352FF24AF9CCB1AE929656AB4AFE05BBDAC1FC7E3A53169319B048BA3E7A769D60410F5175232840C6C6ACF7D37865A3F9B019D2B5B95403EA1E21643A57BC0A60D1AD65003649EB297E2BFE56F537D8FEE39CD127EA1AAE93D1F5A5C51990E674BAAAE96DDE3A67D7B56988D1176298883E6E42A5EF497FFB58D7A72DFBB0A78B43E680C2A58C0683F4137AAE4B8F91BEF2FD68EA3C5875300000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class additionalFeaturesDiscreteConjunctive extends Classifier
{
  public additionalFeaturesDiscreteConjunctive()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "additionalFeaturesDiscreteConjunctive";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "discrete%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesDiscreteConjunctive(NEWord)' defined on line 50 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    String __value;

    for (int fid = 0; fid < word.generatedDiscreteFeaturesConjunctive.size(); fid++)
    {
      NEWord.DiscreteFeature feature = word.generatedDiscreteFeaturesConjunctive.elementAt(fid);
      if (!feature.useWithinTokenWindow)
      {
        __id = "" + (feature.featureGroupName);
        __value = "" + (feature.featureValue);
        __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
      }
    }
    int i;
    NEWord w = word, last = word;
    for (i = 0; i <= 2 && last != null; ++i)
    {
      last = (NEWord) last.next;
    }
    for (i = 0; i > -2 && w.previous != null; --i)
    {
      w = (NEWord) w.previous;
    }
    for (; w != last; w = (NEWord) w.next)
    {
      for (int fid = 0; fid < w.generatedDiscreteFeaturesConjunctive.size(); fid++)
      {
        NEWord.DiscreteFeature feature = w.generatedDiscreteFeaturesConjunctive.elementAt(fid);
        if (feature.useWithinTokenWindow)
        {
          __id = "" + ("pos" + i + "group" + feature.featureGroupName);
          __value = "" + (feature.featureValue);
          __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
        }
      }
      i++;
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesDiscreteConjunctive(NEWord)' defined on line 50 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "additionalFeaturesDiscreteConjunctive".hashCode(); }
  public boolean equals(Object o) { return o instanceof additionalFeaturesDiscreteConjunctive; }
}

