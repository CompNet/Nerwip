// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B880000000000000005B29BDA430130168F556A50BCE217388796AB2887ABBE598DBE0DCC6D1DD625278EA82EBBB9C63D6D6F2A8704209468CCC7FF0FF4419B9954F872025922F464BC6FE05AF061DDD4E7B981D7D64F370D33F4B2C2627B3536514717B216C51CB3436C2414AD3434A0A68331DF56CD7A0F93A64B2D3AAD0E638FD7C2774F68549D79236564AEA578F1491439FCAF7687C61718ADF59F22A04491A60A814661F0E07A4EF984F389714D352DAC479A5078ADD65197E3FEDA90BC98C502C5C1E3D3AC630A08F88B29D142063665E67F41A59EC7E04463E6D6911C8B683781D86D9238A14786B510C815A6527D567FBCE36EA1F5D729BD7EC5245D37A3EB4B8B2231CDE86555D3DABFA8AD5ED69522664CA94222E039398697C6AEFF932FF3DCBFB73EE1E2D8B120B8642381EC3D0B354FBBF40C85F79F4DC757CF466300000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class additionalFeaturesDiscreteNonConjunctive extends Classifier
{
  public additionalFeaturesDiscreteNonConjunctive()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "additionalFeaturesDiscreteNonConjunctive";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "discrete%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesDiscreteNonConjunctive(NEWord)' defined on line 25 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    String __value;

    for (int fid = 0; fid < word.generatedDiscreteFeaturesNonConjunctive.size(); fid++)
    {
      NEWord.DiscreteFeature feature = word.generatedDiscreteFeaturesNonConjunctive.elementAt(fid);
      if (!feature.useWithinTokenWindow)
      {
        __id = "" + (feature.featureGroupName);
        __value = "" + (feature.featureValue);
        __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
      }
    }
    int i;
    NEWord w = word, last = word;
    for (i = 0; i <= 2 && last != null; ++i)
    {
      last = (NEWord) last.next;
    }
    for (i = 0; i > -2 && w.previous != null; --i)
    {
      w = (NEWord) w.previous;
    }
    for (; w != last; w = (NEWord) w.next)
    {
      for (int fid = 0; fid < w.generatedDiscreteFeaturesNonConjunctive.size(); fid++)
      {
        NEWord.DiscreteFeature feature = w.generatedDiscreteFeaturesNonConjunctive.elementAt(fid);
        if (feature.useWithinTokenWindow)
        {
          __id = "" + ("pos" + i + "group" + feature.featureGroupName);
          __value = "" + (feature.featureValue);
          __result.addFeature(new DiscretePrimitiveStringFeature(this.containingPackage, this.name, __id, __value, valueIndexOf(__value), (short) 0));
        }
      }
      i++;
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesDiscreteNonConjunctive(NEWord)' defined on line 25 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "additionalFeaturesDiscreteNonConjunctive".hashCode(); }
  public boolean equals(Object o) { return o instanceof additionalFeaturesDiscreteNonConjunctive; }
}

