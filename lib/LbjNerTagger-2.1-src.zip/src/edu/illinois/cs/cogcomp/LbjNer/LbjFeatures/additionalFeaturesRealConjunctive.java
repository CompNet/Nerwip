// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B88000000000000000DA19D5B43C034168FFAC9D0C1D21B14CB4BDA022AEDDE244CD570B7A3F8669C8C7CA2A8FFDD42BCE3CD58C81258427AD7FC3F6A7E53824E9188EA3274A59097F82C97386F13CBFB5DAEDCBA7174B2C26A7733D6A3812C2524351C714FAD0414AC14F4D14B07157A343942C7E8A0D8078D54EC689B7C3E69E31B8235F036560CDAD08FE9E1AFCB7B7423152E2059BB17540A60635F05C82348B7B83327FA4AE94FB3AA919AE4F01D7D2A2BB5B2E97F703ADF27A261807578F9E9584F853C77872EFC35D0B91D4EB7E938416D5E2AEC36A5F0880A961E2162395B464D282F256D0C815CBA4EEBC3BE235DC51E78B867FB937D0552EC0C7960754ADBDD1DAAA21D68D74DE47B565D1411A72A94D782E86A5EF591FFB70C7A5AB7C58B3E5A6B360616C6C06C3F81D6CAE4B8C91B478F16333095173300000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class additionalFeaturesRealConjunctive extends Classifier
{
  public additionalFeaturesRealConjunctive()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "additionalFeaturesRealConjunctive";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "real%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesRealConjunctive(NEWord)' defined on line 101 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    double __value;

    for (int fid = 0; fid < word.generatedRealFeaturesConjunctive.size(); fid++)
    {
      NEWord.RealFeature feature = word.generatedRealFeaturesConjunctive.elementAt(fid);
      if (!feature.useWithinTokenWindow)
      {
        __id = "" + (feature.featureGroupName);
        __value = feature.featureValue;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
      }
    }
    int i;
    NEWord w = word, last = word;
    for (i = 0; i <= 2 && last != null; ++i)
    {
      last = (NEWord) last.next;
    }
    for (i = 0; i > -2 && w.previous != null; --i)
    {
      w = (NEWord) w.previous;
    }
    for (; w != last; w = (NEWord) w.next)
    {
      for (int fid = 0; fid < w.generatedRealFeaturesConjunctive.size(); fid++)
      {
        NEWord.RealFeature feature = w.generatedRealFeaturesConjunctive.elementAt(fid);
        if (feature.useWithinTokenWindow)
        {
          __id = "" + ("pos" + i + "group" + feature.featureGroupName);
          __value = feature.featureValue;
          __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        }
      }
      i++;
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesRealConjunctive(NEWord)' defined on line 101 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "additionalFeaturesRealConjunctive".hashCode(); }
  public boolean equals(Object o) { return o instanceof additionalFeaturesRealConjunctive; }
}

