// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B880000000000000005B19F4B43013015CFBAC4B069D52E601F86AB2888A7BE144CE938B3B5743D4AC629EA82E7773943DFB7825A02B09462B33FB71EDBE05AAB009D434E8C869AE115A3FD1AD7E07F313AFED8EF0FAFDC1D21B89C3C4D47D04F169216C51CF04B6A38284B3869A18A1EA44A3C835B0F91A6CE4A3C622A6D8DD7427B4FD854996C81B230175A1C77640ADCB7D7A36151EC15BBB37540070C35B05C02378B7B83527FE4AF5CC72AE929E6C4F15AD2A6BB153E97F7AEC8F5C44EC11E6E0F7DBA45E150CF68F2A504206D605E7AE528296D5E24463B656311C8B68B681D865D238A14B75A4003641F9297E2B3E56AA9B6CF2715E6F937B0552E4FC71D1E29C87BB5A55552A5FBB8AD6FD685224748998222E0B93A8697C29EFF889FCEC8F4B8878B036780C2897C0683B8107CAECB0E91B478F30BC113B8564300000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class additionalFeaturesRealNonConjunctive extends Classifier
{
  public additionalFeaturesRealNonConjunctive()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "additionalFeaturesRealNonConjunctive";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "real%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesRealNonConjunctive(NEWord)' defined on line 74 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    double __value;

    for (int fid = 0; fid < word.generatedRealFeaturesNonConjunctive.size(); fid++)
    {
      NEWord.RealFeature feature = word.generatedRealFeaturesNonConjunctive.elementAt(fid);
      if (!feature.useWithinTokenWindow)
      {
        __id = "" + (feature.featureGroupName);
        __value = feature.featureValue;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
      }
    }
    int i;
    NEWord w = word, last = word;
    for (i = 0; i <= 2 && last != null; ++i)
    {
      last = (NEWord) last.next;
    }
    for (i = 0; i > -2 && w.previous != null; --i)
    {
      w = (NEWord) w.previous;
    }
    for (; w != last; w = (NEWord) w.next)
    {
      for (int fid = 0; fid < w.generatedRealFeaturesNonConjunctive.size(); fid++)
      {
        NEWord.RealFeature feature = w.generatedRealFeaturesNonConjunctive.elementAt(fid);
        if (feature.useWithinTokenWindow)
        {
          __id = "" + ("pos" + i + "group" + feature.featureGroupName);
          __value = feature.featureValue;
          __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
        }
      }
      i++;
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'additionalFeaturesRealNonConjunctive(NEWord)' defined on line 74 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "additionalFeaturesRealNonConjunctive".hashCode(); }
  public boolean equals(Object o) { return o instanceof additionalFeaturesRealNonConjunctive; }
}

