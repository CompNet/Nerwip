// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B8800000000000000058F8F4B62C04015CFBAC0280B14C5CE5B6C38843E1A1444A6B7E5DCB48D2B9DD23BB961B5AFDDD985B4E422303303F7E7FED03C8B1393C72CD3C2B9681D894638F206257C88A63F4F618B2AF294915E35AF12B539ADA163D221836118BC3CBFA2450D7CE891E3D033D5F592F216F156E1C7236D7C76C94D86BC8ACE1B79A85E54C7495620FA30392BE3195A50DC6E252FB86BEB9E0574BFD0599CAE462D31EFC0BED9CF57D51AA585770207865CBF2392B28A80F15ECEFDFFA9347F1B197A8E1786EBA17D16E4FBD7C915057ADF954100000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class level1AggregationFeatures extends Classifier
{
  public level1AggregationFeatures()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "level1AggregationFeatures";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "real%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'level1AggregationFeatures(NEWord)' defined on line 624 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    double __value;

    if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1"))
    {
      for (int i = 0; i < word.level1AggregationFeatures.size(); i++)
      {
        NEWord.RealFeature f = word.level1AggregationFeatures.elementAt(i);
        __id = "" + (f.featureGroupName);
        __value = f.featureValue;
        __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
      }
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'level1AggregationFeatures(NEWord)' defined on line 624 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "level1AggregationFeatures".hashCode(); }
  public boolean equals(Object o) { return o instanceof level1AggregationFeatures; }
}

