// Modifying this comment will cause the next execution of LBJ2 to overwrite this file.
// F1B88000000000000000DA3516F63D0301DFB274526A85180D1C732BE71AA180155998501F16AA09B9C53838B6F83B3B251ADF77EC673DA86786242419CA8FCFCFED3BFD9905AE7A07B487759C6DDB5B435B6C3EF4F33CB34D7E9DCF2FB85A6063C3808B87E0FB04DA02BB29427D8E192C689D2BB9AD60B8AB72243EF0B65CA05AFE90D556F3B3E576269AC8BF08BDC647A28321220BB1F0AE914752C0AC0398AE52C5B7256ADB954C9A3E2B1CDC05C75B821E36D9C14D835BD3352134BE0F7B38E9EA78D5B2B4099268C8B4050713187907676CAAF48735FA579097EA281B8C473A61F732BC4499C852CC6A062E5791DEFEE215071D0F14B48BF3A23F8548B0156B77FEB53690FA9F22309FB162F642D6F4C72C9F87C3E327AA2FC383D88CE212B364647558643DAFF6C5940A09262BBDD260688471D7718F3A79ADDE11268D23FB4E0DA54A4DD1582751174AC9088F7BEC807ADB22C645DE5953E21DD7296A1BBE7786094A7B454FE07E6593CC4C1208E6158C6A9ACE7743FF55B82EC762798A95E24448AD1E382B125C80C80B74085D6F61392EE0D7C9DF3A1CFDF940A159E1A0470B0340A1AEBF7532930E9C1C56B8E3AB471A17F8B9B81BB7EFD575936822BC7E03AFA32E19121A3DF5FF1C81FD24696940CB08C2B6C6FB4D82E082F6DB4D9497F732CFDF60004458CC78400000

package edu.illinois.cs.cogcomp.LbjNer.LbjFeatures;

import LBJ2.classify.*;
import LBJ2.infer.*;
import LBJ2.learn.*;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.BrownClusters;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.Gazzetteers;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordEmbeddings;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.WordTopicAndLayoutFeatures;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;
import edu.illinois.cs.cogcomp.LbjNer.StringStatisticsUtils.*;
import java.util.*;


public class prevTagsForContextLevel1 extends Classifier
{
  public prevTagsForContextLevel1()
  {
    containingPackage = "edu.illinois.cs.cogcomp.LbjNer.LbjFeatures";
    name = "prevTagsForContextLevel1";
  }

  public String getInputType() { return "edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord"; }
  public String getOutputType() { return "real%"; }

  public FeatureVector classify(Object __example)
  {
    if (!(__example instanceof NEWord))
    {
      String type = __example == null ? "null" : __example.getClass().getName();
      System.err.println("Classifier 'prevTagsForContextLevel1(NEWord)' defined on line 403 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    NEWord word = (NEWord) __example;

    FeatureVector __result;
    __result = new FeatureVector();
    String __id;
    double __value;

    if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("prevTagsForContext"))
    {
      int i, j;
      NEWord w = word;
      String[] words = new String[3];
      OccurrenceCounter[] count = new OccurrenceCounter[3];
      for (i = 0; i <= 2 && w != null; ++i)
      {
        count[i] = new OccurrenceCounter();
        words[i] = w.form;
        w = (NEWord) w.next;
      }
      w = (NEWord) word.previousIgnoreSentenceBoundary;
      for (i = 0; i < 1000 && w != null; i++)
      {
        for (j = 0; j < words.length; j++)
        {
          if (words[j] != null && w.form.equals(words[j]))
          {
            if (NETaggerLevel1.isTraining)
            {
              if (ParametersForLbjCode.currentParameters.prevPredictionsLevel1RandomGenerator.useNoise())
              {
                count[j].addToken(ParametersForLbjCode.currentParameters.prevPredictionsLevel1RandomGenerator.randomLabel());
              }
              else
              {
                count[j].addToken(w.neLabel);
              }
            }
            else
            {
              count[j].addToken(w.neTypeLevel1);
            }
          }
        }
        w = (NEWord) w.previousIgnoreSentenceBoundary;
      }
      for (j = 0; j < count.length; j++)
      {
        if (count[j] != null)
        {
          String[] all = count[j].getTokens();
          for (i = 0; i < all.length; i++)
          {
            __id = "" + (j + "_" + all[i]);
            __value = count[j].getCount(all[i]) / ((double) count[j].totalTokens);
            __result.addFeature(new RealPrimitiveStringFeature(this.containingPackage, this.name, __id, __value));
          }
        }
      }
    }
    return __result;
  }

  public FeatureVector[] classify(Object[] examples)
  {
    if (!(examples instanceof NEWord[]))
    {
      String type = examples == null ? "null" : examples.getClass().getName();
      System.err.println("Classifier 'prevTagsForContextLevel1(NEWord)' defined on line 403 of LbjTagger.lbj received '" + type + "' as input.");
      new Exception().printStackTrace();
      System.exit(1);
    }

    return super.classify(examples);
  }

  public int hashCode() { return "prevTagsForContextLevel1".hashCode(); }
  public boolean equals(Object o) { return o instanceof prevTagsForContextLevel1; }
}

