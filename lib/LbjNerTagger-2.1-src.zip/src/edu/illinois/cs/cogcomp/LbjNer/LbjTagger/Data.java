package edu.illinois.cs.cogcomp.LbjNer.LbjTagger;

import java.io.File;
import java.util.HashMap;
import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData.TaggedDataReader;


public class Data {
	public String nickname;//this will be used to save the model to know on what dataset we have tuned....
	public String pathToData;
	public String datasetPath;
	public Vector<NERDocument> documents=new Vector<NERDocument>();
	HashMap<String,Boolean> labelsToIgnoreForEvaluation=new HashMap<String, Boolean>();
	HashMap<String,Boolean> labelsToAnonymizeForEvaluation=new HashMap<String, Boolean>();
	
	private Data(Data other){
		//no copy!!!
	}
	

	public Data(){
		datasetPath="missing";
		nickname="missing";
	}

	public Data(NERDocument doc){
		datasetPath="missing";
		nickname="missing";
		documents.addElement(doc);
	}
	
	public Data(String pathToData,String nickname,String dataFormat,Vector<String> labelsToIgnoreForEvaluation,Vector<String> labelsToAnonymizeForEvaluation) throws Exception{
		this.datasetPath=pathToData;
		this.nickname=nickname;
		this.pathToData=pathToData;
		if((new File(pathToData)).isDirectory()){
			Vector<NERDocument> docs=TaggedDataReader.readFolder(pathToData, dataFormat);
			for(int i=0;i<docs.size();i++)
				documents.addElement(docs.elementAt(i));
		}
		else{
			int idx = Math.max(Math.max(0,pathToData.lastIndexOf("/")),pathToData.lastIndexOf('\\'));
			String docname=pathToData.substring(idx);
			documents.addElement(TaggedDataReader.readFile(pathToData, dataFormat, docname));
		}
		setLabelsToIgnore(labelsToIgnoreForEvaluation);
		setLabelsToAnonymize(labelsToAnonymizeForEvaluation);
	}

	public Data(String pathToData,String nickname,String dataFormat,String[] labelsToIgnoreForEvaluation,String[] labelsToAnonymizeForEvaluation) throws Exception{
		this.datasetPath=pathToData;
		this.nickname=nickname;
		if((new File(pathToData)).isDirectory()){
			Vector<NERDocument> docs=TaggedDataReader.readFolder(pathToData, dataFormat);
			for(int i=0;i<docs.size();i++)
				documents.addElement(docs.elementAt(i));
		}
		else{
			int idx = Math.max(Math.max(0,pathToData.lastIndexOf("/")),pathToData.lastIndexOf('\\'));
			String docname=pathToData.substring(idx);
			documents.addElement(TaggedDataReader.readFile(pathToData, dataFormat, docname));
		}
		setLabelsToIgnore(labelsToIgnoreForEvaluation);
		setLabelsToAnonymize(labelsToAnonymizeForEvaluation);
	}

	public void setLabelsToIgnore(Vector<String> labelsToIgnoreForEvaluation){
		this.labelsToIgnoreForEvaluation=new HashMap<String, Boolean>();
		if(labelsToIgnoreForEvaluation!=null)
			for(int i=0;i<labelsToIgnoreForEvaluation.size();i++)
				this.labelsToIgnoreForEvaluation.put(labelsToIgnoreForEvaluation.elementAt(i), true);		
	}
	public void setLabelsToAnonymize(Vector<String> labelsToAnonymizeForEvaluation){
		this.labelsToAnonymizeForEvaluation=new HashMap<String, Boolean>();
		if(labelsToAnonymizeForEvaluation!=null)
			for(int i=0;i<labelsToAnonymizeForEvaluation.size();i++)
				this.labelsToAnonymizeForEvaluation.put(labelsToAnonymizeForEvaluation.elementAt(i), true);		
	}
	public void setLabelsToIgnore(String[] labelsToIgnoreForEvaluation){
		this.labelsToIgnoreForEvaluation=new HashMap<String, Boolean>();
		if(labelsToIgnoreForEvaluation!=null)
			for(int i=0;i<labelsToIgnoreForEvaluation.length;i++)
				this.labelsToIgnoreForEvaluation.put(labelsToIgnoreForEvaluation[i], true);		
	}
	public void setLabelsToAnonymize(String[] labelsToAnonymizeForEvaluation){
		this.labelsToAnonymizeForEvaluation=new HashMap<String, Boolean>();
		if(labelsToAnonymizeForEvaluation!=null)
			for(int i=0;i<labelsToAnonymizeForEvaluation.length;i++)
				this.labelsToAnonymizeForEvaluation.put(labelsToAnonymizeForEvaluation[i], true);		
	}
}
