package edu.illinois.cs.cogcomp.LbjNer.LbjTagger;

import java.util.Vector;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.ExpressiveFeaturesAnnotator;
import edu.illinois.cs.cogcomp.LbjNer.ExpressiveFeatures.TwoLayerPredictionAggregationFeatures;
import edu.illinois.cs.cogcomp.LbjNer.InferenceMethods.PredictionsAndEntitiesConfidenceScores;
import LBJ2.classify.TestDiscrete;
import LBJ2.learn.BatchTrainer;
import LBJ2.learn.Learner;
import LBJ2.learn.SparseNetworkLearner;
import LBJ2.parse.*;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel1;
import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.NETaggerLevel2;

public class LearningCurveMultiDataset
{

	/*
	 * use fixedNumIterations=-1 if you wanna use the automatic convergence criterion
	 */
	public static void getLearningCurve(int fixedNumIterations,String trainDataPath,String testDataPath,String filesFormat) throws Exception{
		Data trainData=new Data(trainDataPath,trainDataPath,filesFormat,new String[]{},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(trainData);
		Data testData=new Data(testDataPath,testDataPath,filesFormat,new String[]{},new String[]{});
		ExpressiveFeaturesAnnotator.annotate(testData);
		Vector<Data> train=new Vector<Data>();
		train.addElement(trainData);
		Vector<Data> test=new Vector<Data>();
		test.addElement(testData);
		getLearningCurve(train, test,fixedNumIterations);
	}

	/*
	 * use fixedNumIterations=-1 if you wanna use the automatic convergence criterion
	 */
	public static void getLearningCurve(Vector<Data> trainDataSet,Vector<Data> testDataSet,int fixedNumIterations) throws Exception
	{	  
		double bestF1Level1 = -1;
		int bestRoundLevel1 = 0;
		NETaggerLevel1 tagger1 = new NETaggerLevel1(ParametersForLbjCode.currentParameters.pathToModelFile+".level1",ParametersForLbjCode.currentParameters.pathToModelFile+".level1.lex");
		tagger1.forget();

		for(int dataId=0;dataId<trainDataSet.size();dataId++){
			Data trainData = trainDataSet.elementAt(dataId);
			if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")){
				//PredictionsAndEntitiesConfidenceScores.annotateWithGoldLabelsWithOmissions(trainData, 0.1, 0.2);
				PredictionsAndEntitiesConfidenceScores.getAndMarkEntities(trainData,NEWord.LabelToLookAt.GoldLabel);
				TwoLayerPredictionAggregationFeatures.setLevel1AggregationFeatures(trainData, true,"training time- induced from gold labels");
			}
		}

				
		System.out.println("Pre-extracting the training data for Level 1 classifier");
		Runtime rt = Runtime.getRuntime();
		Process pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTrainData*");
		pr.waitFor();
		pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTestData*");
		pr.waitFor();

		BatchTrainer bt1train = prefetchAndGetBatchTrainer(tagger1, trainDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTrainData");
		//BatchTrainerByParts bt1train = prefetchAndGetBatchTrainer(tagger1, trainDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTrainData", 100);
		System.out.println("Pre-extracting the testing data for Level 1 classifier");
		BatchTrainer bt1test = prefetchAndGetBatchTrainer(tagger1, testDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTestData");
		//BatchTrainerByParts bt1test = prefetchAndGetBatchTrainer(tagger1, testDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTestData", 1);
		Parser testParser1 = bt1test.getParser();
		//Parser testParser1 = bt1test.inputParser;
		
		for (int i = 0; (fixedNumIterations==-1&& i < 200 && i-bestRoundLevel1<10) || (fixedNumIterations>0&&i<=fixedNumIterations); ++i) {
			System.out.println("Learning first level classifier; round "+i);
			bt1train.train(1);
			//bt1train.trainOneRound();
	
			System.out.println("Testing level 1 classifier;  on prefetched data, round: "+i);
			testParser1.reset();
			TestDiscrete simpleTest = new TestDiscrete();
			simpleTest.addNull("O");
			TestDiscrete.testDiscrete(simpleTest, tagger1, null,  testParser1, true, 0);
							
			double f1Level1 = simpleTest.getOverallStats()[2];
			if (f1Level1 > bestF1Level1) {
				bestF1Level1 = f1Level1;
				bestRoundLevel1 = i;
				tagger1.save();
			}

			if (i % 5 == 0)
				System.err.println(i  + " rounds.  Best so far for Level1 : (" + bestRoundLevel1 + ")=" + bestF1Level1);
		}
		pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTrainData*");
		pr.waitFor();
		pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level1.prefetchedTestData*");
		pr.waitFor();

		System.out.println("Testing level 1 classifier, final performance: ");
		TestDiscrete[] results = NETesterMultiDataset.printAllTestResultsAsOneDataset(testDataSet,tagger1,null, false);
		double f1Level1 = results[0].getOverallStats()[2];
		System.out.println("Level 1; round "+bestRoundLevel1 + "\t" + f1Level1);

		
		NETaggerLevel2 tagger2 = new NETaggerLevel2(ParametersForLbjCode.currentParameters.pathToModelFile+".level2",ParametersForLbjCode.currentParameters.pathToModelFile+".level2.lex");
		tagger2.forget();
		if (ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PatternFeatures")||
							ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")) {
			double bestF1Level2 = -1;
			int bestRoundLevel2 = 0;
			
			pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTrainData*");
			pr.waitFor();
			pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTestData*");
			pr.waitFor();
			System.out.println("Pre-extracting the training data for Level 2 classifier");
			BatchTrainer bt2train = prefetchAndGetBatchTrainer(tagger2, trainDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTrainData");
			//BatchTrainerByParts bt2train = prefetchAndGetBatchTrainer(tagger2, trainDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTrainData", 100);
			System.out.println("Pre-extracting the testing data for Level 2 classifier");
			BatchTrainer bt2test = prefetchAndGetBatchTrainer(tagger2, testDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTestData");
			//BatchTrainerByParts bt2test = prefetchAndGetBatchTrainer(tagger2, testDataSet, ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTestData",1);
			Parser testParser2 = bt2test.getParser();
			//Parser testParser2 = bt2test.inputParser;
			
			for (int i = 0; (fixedNumIterations==-1&& i < 200 && i-bestRoundLevel2<10) || (fixedNumIterations>0&&i<=fixedNumIterations); ++i) {
				System.out.println("Learning Level2 ; round "+i);
				bt2train.train(1);
				//bt2train.trainOneRound();
				
				System.out.println("Testing level 2 classifier;  on prefetched data, round: "+i);
				testParser2.reset();
				TestDiscrete simpleTest = new TestDiscrete();
				simpleTest.addNull("O");
				TestDiscrete.testDiscrete(simpleTest, tagger2, null,  testParser2, true, 0);

		
				double f1Level2 = simpleTest.getOverallStats()[2];
				if (f1Level2 > bestF1Level2) {
					bestF1Level2 = f1Level2;
					bestRoundLevel2 = i ;
					tagger2.save();
				}

				if ( i % 5 == 0)
					System.err.println(i + " rounds.  Best so far for Level2 : (" + bestRoundLevel2 + ") " + bestF1Level2);
			}
			pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTrainData*");
			pr.waitFor();
			pr = rt.exec("rm ./ "+ParametersForLbjCode.currentParameters.pathToModelFile+".level2.prefetchedTestData*");
			pr.waitFor();

			System.out.println("Testing both levels ...");
			results = NETesterMultiDataset.printAllTestResultsAsOneDataset(testDataSet,tagger1,tagger2,false);
			f1Level1 = results[0].getOverallStats()[2];
			double f1Level2 = results[1].getOverallStats()[2];
			System.out.println("Level1: bestround="+ bestRoundLevel1 + "\t F1=" + f1Level1+"\t Level2: bestround="+ bestRoundLevel2 + "\t F1=" + f1Level2);
		}
		
		
		/*
		 * This will override the models forcing to save the iteration we're interested in- the fixedNumIterations iteration, the last one.
		 * But note - both layers will be saved for this iteration. If the best performance for one of the layers came before the final
		 * iteration, we're in a small trouble- the performance will decrease 
		 */
		if(fixedNumIterations>-1){
			tagger1.save();
			tagger2.save();			
		}
	}
	
	/*
	 * Parts is the number of parts to which we split the data.
	 * in training - if you have a lot of samples- use 100 partitions	
	 * otherwise, the zip doesn't work on training files larger than 4G
	 */
	private static BatchTrainer prefetchAndGetBatchTrainer(SparseNetworkLearner classifier, Vector<Data> dataSets, String exampleStorePath) {
		System.out.println("Pre-extracting the training data for Level 1 classifier");
		for(int dataId=0;dataId<dataSets.size();dataId++){
			Data data = dataSets.elementAt(dataId);
			TextChunkRepresentationManager.changeChunkRepresentation(
				TextChunkRepresentationManager.EncodingScheme.BIO, 
				ParametersForLbjCode.currentParameters.taggingEncodingScheme, 
				data, NEWord.LabelToLookAt.GoldLabel);
		}
		BatchTrainer bt = new BatchTrainer(classifier, new SampleReader(dataSets), 1000);
		classifier.setLexicon(bt.preExtract(exampleStorePath));
		//BatchTrainerByParts bt = new BatchTrainerByParts(new SampleReader(dataSets), classifier, parts, exampleStorePath);
		for(int dataId=0; dataId<dataSets.size(); dataId++) {
			Data trainData = dataSets.elementAt(dataId);
			TextChunkRepresentationManager.changeChunkRepresentation(
					ParametersForLbjCode.currentParameters.taggingEncodingScheme, 
					TextChunkRepresentationManager.EncodingScheme.BIO, 
					trainData, NEWord.LabelToLookAt.GoldLabel);
		}
		return bt;
	}
	
	public static class BatchTrainerByParts {
		Parser inputParser = null;
		Vector<BatchTrainer> trainers = new Vector<BatchTrainer>();
		
		BatchTrainerByParts(Parser inputParser, Learner learner, int splits, String outputFile) {
			this.inputParser = inputParser;
			inputParser.reset();
			int originalParserSampleCount = 0; // stores the number of samples in the input parse
			int partsSamplesCount =0; // stores the number of samples in the parts -- part by part. This is for testing purposes -- we wanna check whether originalParserSampleCount==partsSamplesCount
			Object sample = inputParser.next();
			for (originalParserSampleCount = 0; sample!=null; sample = inputParser.next())
				originalParserSampleCount++;
			System.out.println(originalParserSampleCount + " samples in the input parser");
			for (int i=0;i<splits;i++) {
				FoldParser parts = new FoldParser(inputParser, splits, FoldParser.SplitPolicy.sequential, i, true);
				parts.reset();
				System.out.println("Hello world");
				BatchTrainer bt = new BatchTrainer(learner, parts, 10);
				learner.setLexicon(bt.preExtract(outputFile+".part"+i));
				int partCount = 0;
				parts = new FoldParser(inputParser, splits, FoldParser.SplitPolicy.sequential, i, true);
				parts.reset();
				sample = parts.next();
				for (partCount = 0; sample!=null; sample = parts.next())
					partCount++;
				System.out.println(partCount+" samples in part "+i);
				partsSamplesCount+=partCount;
				trainers.addElement(bt);
			}
			if(partsSamplesCount!=originalParserSampleCount) {
				System.out.println("Fatal error. The number of input samples is "+originalParserSampleCount+" vs "+partsSamplesCount);
				System.exit(0);
			}
		}
		
		public void trainOneRound() {
			for(int i=0;i<trainers.size();i++)
				trainers.elementAt(i).train(1);
		}
	}
	
		
	public static class SampleReader implements Parser {
		public Vector<Data> dataset=null;
		int datasetId = 0;
		int docid = 0;
		int sentenceId =0;
		int tokenId=0;
		int generatedSampes = 0;
		
		public SampleReader(Vector<Data> dataset) {
			this.dataset=dataset;
		}
		
		public void close() {
			// do nothing			
		}
		
		public Object next() {
			if(datasetId>=dataset.size())
				return null;
			// System.out.println("token = "+tokenId+"; sentence = "+sentenceId+"; dataset = "+datasetId+" ---  datasets="+dataset.size()+" now sentences= "+dataset.elementAt(datasetId).sentences.size()+"; now tokens = "+dataset.elementAt(datasetId).sentences.elementAt(sentenceId).size());
			Object res =  dataset.elementAt(datasetId).documents.elementAt(docid).sentences.elementAt(sentenceId).get(tokenId);
			if(tokenId<dataset.elementAt(datasetId).documents.elementAt(docid).sentences.elementAt(sentenceId).size()-1)
				tokenId++;
			else {
				tokenId=0;
				if(sentenceId<dataset.elementAt(datasetId).documents.elementAt(docid).sentences.size()-1) {
					sentenceId++;
				} else {
					sentenceId=0;
					if (docid< dataset.elementAt(datasetId).documents.size()-1) {
						docid++;
					} else {	
						docid=0;
						datasetId++;
					}
				}
			}
			//System.out.println("token = "+tokenId+"; sentence = "+sentenceId+"; dataset = "+datasetId+" ---  datasets="+dataset.size()+" now sentences= "+dataset.elementAt(datasetId).sentences.size()+"; now tokens = "+dataset.elementAt(datasetId).sentences.elementAt(sentenceId).size());
			generatedSampes++;
			//System.out.println(generatedSampes+" samples generated by SampleReader");
			return res;
		}
		public void reset() {
			datasetId = 0;
			sentenceId =0;
			tokenId=0;
			generatedSampes = 0;
		}
	}
}

/*

			THE OLD VERSION

	public static void getLearningCurve(Vector<Data> trainDataSet,Vector<Data> testDataSet,int fixedNumIterations) throws Exception
	{	  
		NETaggerLevel1 tagger1 = new NETaggerLevel1();
		tagger1.forget();
		NETaggerLevel2 tagger2 = new NETaggerLevel2();
		tagger2.forget();
		double bestF1Level1 = -1;
		int bestRoundLevel1 = 0;
		double bestF1Level2 = -1;
		int bestRoundLevel2 = 0;


		for (int i = 0; (fixedNumIterations==-1&& i < 1000 && i-bestRoundLevel2<10) || (fixedNumIterations>0&&i<fixedNumIterations); ++i)
		{
			System.out.println("Learning round "+i);
			for(int dataId=0;dataId<trainDataSet.size();dataId++){
				Vector<LinkedVector> trainData = trainDataSet.elementAt(dataId).sentences;
				Decoder.clearPredictions(trainData);
				NETaggerLevel1.isTraining=true;
				NETaggerLevel2.isTraining=true;
				
				if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1")){
					//TextChunkRepresentationManager.changeChunkRepresentation(
					//		TextChunkRepresentationManager.EncodingScheme.BIO, 
					//		ParametersForLbjCode.currentParameters.taggingEncodingScheme, 
					//		trainData, NEWord.LabelToLookAt.GoldLabel);
					// REMEMBER TO UNCOMMENT THE taggingEncodingScheme--> BIO CONVERSION IF YOU UNCOMMENT THIS!!!
					//TwoLayerAggregationFeaturesOld.aggregateLevel1Predictions(trainData);
					//TwoLayerAggregationFeaturesOld.aggregateEntityLevelPredictions(trainData);
			    	PredictionsAndEntitiesConfidenceScores.annotateWithGoldLabelsWithOmissions(trainData, 0.1, 0.2);
			    	TwoLayerPredictionAggregationFeatures.setLevel1AggregationFeatures(trainData, true,"training time- induced from gold labels");
					//GlobalFeatures.displayLevel1AggregationData(trainData);
				}
				System.out.println("Sentences trained on (out of "+trainData.size()+") :");
				for (int k=0;k<trainData.size();k++){
					if(k%100==0)
						System.out.print(" "+k);
					for (int j=0;j<trainData.elementAt(k).size();j++){
						tagger1.learn(trainData.elementAt(k).get(j));
						if(ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PatternFeatures")||ParametersForLbjCode.currentParameters.featuresToUse.containsKey("PredictionsLevel1"))
							tagger2.learn(trainData.elementAt(k).get(j));
					}
				}
				System.out.println();
				//after we're done training, go back to BIO. This will not cause
				//problems when testing because all the "pattern extraction" and
				//"prediction aggregation" will use the predicted tags and not the
				//gold labels.
				
				//TextChunkRepresentationManager.changeChunkRepresentation(
				//		ParametersForLbjCode.currentParameters.taggingEncodingScheme, 
				//		TextChunkRepresentationManager.EncodingScheme.BIO, 
				//		trainData, NEWord.LabelToLookAt.GoldLabel);
			}
			
			System.out.println("Testing round "+i);
			//NETester.annotateBothLevels(testData, tagger1, tagger2);
			TestDiscrete[] results = NETesterMultiDataset.printAllTestResultsAsOneDataset(testDataSet,tagger1,tagger2,false);
			double f1Level1 = results[0].getOverallStats()[2];
			//System.out.println("Level1: "+(i + 1) + "\t" + f1Level1);
			double f1Level2 = results[1].getOverallStats()[2];
			//System.out.println("Level2: "+(i + 1) + "\t" + f1Level2);

			if (f1Level1 > bestF1Level1)
			{
				bestF1Level1 = f1Level1;
				bestRoundLevel1 = i + 1;
				NETaggerLevel1.getInstance().binaryWrite(ParametersForLbjCode.currentParameters.pathToModelFile+".level1");
			}
			if (f1Level2 > bestF1Level2)
			{
				bestF1Level2 = f1Level2;
				bestRoundLevel2 = i + 1;
				NETaggerLevel2.getInstance().binaryWrite(ParametersForLbjCode.currentParameters.pathToModelFile+".level2");
			}

			if ((i + 1) % 5 == 0)
				System.err.println((i + 1) + " rounds.  Best so far: Level1(" + bestRoundLevel1 + ")=" + bestF1Level1+" Level2(" + bestRoundLevel2 + ") " + bestF1Level2);
		}
	}






*/