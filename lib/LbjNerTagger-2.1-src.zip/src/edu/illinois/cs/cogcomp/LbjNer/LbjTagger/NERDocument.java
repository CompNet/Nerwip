package edu.illinois.cs.cogcomp.LbjNer.LbjTagger;

import java.util.Vector;

import LBJ2.parse.LinkedVector;

public class NERDocument {
	public String docname;

	public NERDocument(Vector<LinkedVector> vector, String documentName) {
		docname=documentName;
		sentences=vector;
	}

	public Vector<LinkedVector> sentences;
}
