package edu.illinois.cs.cogcomp.LbjNer.LbjTagger;

import java.util.StringTokenizer;

import edu.illinois.cs.cogcomp.LbjNer.LbjFeatures.*;

import edu.illinois.cs.cogcomp.LbjNer.IO.Keyboard;
import edu.illinois.cs.cogcomp.LbjNer.IO.OutFile;


public class NerTagger {
	public static void main(String[] args){		
		try{
			Parameters.readConfigAndLoadExternalData(args[args.length-1]);
			
			if(ParametersForLbjCode.currentParameters.logging)
				ParametersForLbjCode.currentParameters.loggingFile=new OutFile(ParametersForLbjCode.currentParameters.debuggingLogPath);
			
			if(args[0].equalsIgnoreCase("-annotate"))
				NETagPlain.tagData(args[1], args[2],false);
			if(args[0].equalsIgnoreCase("-annotateWithConf"))
				NETagPlain.tagData(args[1], args[2],true);
			if(args[0].equalsIgnoreCase("-demo")){
				System.out.println("Reading model file : " + ParametersForLbjCode.currentParameters.pathToModelFile+".level1");
				NETaggerLevel1 tagger1=new NETaggerLevel1(ParametersForLbjCode.currentParameters.pathToModelFile+".level1",ParametersForLbjCode.currentParameters.pathToModelFile+".level1.lex");
				System.out.println("Reading model file : " + ParametersForLbjCode.currentParameters.pathToModelFile+".level2");
				NETaggerLevel2 tagger2=new NETaggerLevel2(ParametersForLbjCode.currentParameters.pathToModelFile+".level2", ParametersForLbjCode.currentParameters.pathToModelFile+".level2.lex");
				String input="";
				while(!input.equalsIgnoreCase("quit")){
					input=Keyboard.readLine();
					if(input.equalsIgnoreCase("quit"))
						System.exit(0);
					String res=NETagPlain.tagLine(input,tagger1,tagger2);
					res=NETagPlain.insertHtmlColors(res);
					int len=0;
					StringTokenizer st=new StringTokenizer(res);
					StringBuffer output=new StringBuffer();
					while(st.hasMoreTokens()){
						String s=st.nextToken();
						output.append(" "+s);
						len+=s.length();
					}					
					System.out.println(output.toString());
				}
			}
			if(args[0].equalsIgnoreCase("-test"))
				NETesterMultiDataset.test(args[1], args[2],true);
			if(args[0].equalsIgnoreCase("-dumpFeatures"))
				NETesterMultiDataset.dumpFeaturesLabeledData(args[1], args[2], args[3]);
			if(args[0].equalsIgnoreCase("-train"))
				LearningCurveMultiDataset.getLearningCurve(-1,args[1],args[3],args[4]);
			if(args[0].equalsIgnoreCase("-trainFixedIterations"))
				LearningCurveMultiDataset.getLearningCurve(Integer.parseInt(args[1]),args[2],args[4],args[5]);
		}catch(Exception e){
			System.out.println("Exception caught: ");
			e.printStackTrace();
			System.out.println("The problem might be the usage: use one of the below:");
			System.out.println("*)java -classpath $LBJ2.jar:LBJ2Library.jar:bin -Xmx1000m -train <traingFile> -test <testFile> <-b/-r> <pathToConfigFile>");
			System.out.println("\tThis command will learn the classifier and print the training curve, the last parameter specifies the file " +
					"format; use -b for brackets and -r for raw (plain) text; ");
			System.out.println("*)java -classpath $LBJ2.jar:LBJ2Library.jar:bin -Xmx1000m -annotate <rawInputFile> <outFile>  <pathToConfigFile>");
			System.out.println("\tThis one takes a plain text, tags it, and outputs the the specified file in brackets format");
			System.out.println("*)java -classpath $LBJ2.jar:LBJ2Library.jar:bin -Xmx1000m -test <goldFile> <format(-c/-r)>  <pathToConfigFile>");
			System.out.println("\tWill output phrase-level F1 score on the file (recall that I love other measures for comparing taggers, I want to use this primary as sanity check)");
		}
		if(ParametersForLbjCode.currentParameters.loggingFile!=null)
			ParametersForLbjCode.currentParameters.loggingFile.close();
	}
}
