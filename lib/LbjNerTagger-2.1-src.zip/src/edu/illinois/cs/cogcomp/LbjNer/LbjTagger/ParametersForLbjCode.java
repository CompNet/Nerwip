package edu.illinois.cs.cogcomp.LbjNer.LbjTagger;

import java.util.*; 


import edu.illinois.cs.cogcomp.LbjNer.IO.OutFile;
import LBJ2.learn.SparseNetworkLearner;

public class ParametersForLbjCode {
	public  enum  TokenizationScheme {LbjTokenizationScheme,DualTokenizationScheme};
	public  enum InferenceMethods {GREEDY,BEAMSEARCH,VITERBI};

	public  static ParametersForLbjCode currentParameters=new ParametersForLbjCode();
	public  String[] labelTypes= {"PER","ORG","LOC","MISC"};//will be initialized to something like {"PER","ORG","LOC","MISC"}; This is necessary for brackets file reader

	public  String locationOnDisk=null;
	public String nameAsAuxFeature=null;//if we use this set of parameters as auxiliary feature- this tells us what is the name of the feature to generate.
	public SparseNetworkLearner taggerLevel1;
	public SparseNetworkLearner taggerLevel2;
	
	public double minConfidencePredictionsLevel1=0;//predictions with lower confidence will be pruned
	public double minConfidencePredictionsLevel2=0;//predictions with lower confidence will be pruned
	
	public Vector<ParametersForLbjCode> auxiliaryModels=new Vector<ParametersForLbjCode>();//the predictions of these models will be the input to the classifier
	
	public  String configFilename=null;//this name must be unique foe each config file, and it will be appended to the model file names, so that we can automatically save the models at the right place
	//public  int trainingIteration=0;

	
	public  InferenceMethods inferenceMethod=InferenceMethods.GREEDY;
	public  int beamSize=5;
	public  boolean thresholdPrediction=false;
	public  double predictionConfidenceThreshold=-1;
	public  boolean logging = true;
	public  OutFile loggingFile=null;
	public  String  debuggingLogPath=null;
	
	public  boolean sortLexicallyFilesInFolders=true;
	public  boolean treatAllFilesInFolderAsOneBigDocument=false;
	public  boolean forceNewSentenceOnLineBreaks=false;
	public  boolean normalizeTitleText=false;//this will selectively lowercase the text in the first sentence if it's all-capitilized
	public  String pathToTokenNormalizationData="../../Data/BrownHierarchicalWordClusters/brown-english-wikitext.case-intact.txt-c1000-freq10-v3.txt";//this will selectively lowercase the text in the first sentence if it's all-capitilized
	public  boolean keepOriginalFileTokenizationAndSentenceSplitting=false;// this will not normalize the text in any way

	public  String pathToModelFile=null;
	public  TokenizationScheme tokenizationScheme=null;// should be either LbjTokenizationScheme or DualTokenizationScheme
	public  TextChunkRepresentationManager.EncodingScheme taggingEncodingScheme=null;// should be  BIO / BILOU/ IOB1/ IOE1/ IOE2
	
    public  RandomLabelGenerator patternLabelRandomGenerator = null;
    public  RandomLabelGenerator level1AggregationRandomGenerator = null;
	public  RandomLabelGenerator prevPredictionsLevel1RandomGenerator = null;
	public  RandomLabelGenerator prevPredictionsLevel2RandomGenerator = null;
		
	public  Hashtable<String,Boolean> featuresToUse=null;	
}
