package edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData;

import java.util.Vector; 

import edu.illinois.cs.cogcomp.LbjNer.IO.OutFile;
import LBJ2.parse.LinkedVector;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.Data;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;

public class PlainTextWriter {
	public static void write(Data data,String outFile){
		OutFile out=new OutFile(outFile);
		for(int did=0;did<data.documents.size();did++) {
			for(int i=0;i<data.documents.elementAt(did).sentences.size();i++) {
				StringBuffer buf=new StringBuffer(2000);
				for(int j=0;j<data.documents.elementAt(did).sentences.elementAt(i).size();j++)
					buf.append(((NEWord)data.documents.elementAt(did).sentences.elementAt(i).get(j)).form+" ");
				out.println(buf.toString());
			}			
		}
		out.close();
	}
	public static void write(Vector<LinkedVector> data,String outFile){
		OutFile out=new OutFile(outFile);
		for(int i=0;i<data.size();i++){
			StringBuffer buf=new StringBuffer(2000);
			for(int j=0;j<data.elementAt(i).size();j++)
				buf.append(((NEWord)data.elementAt(i).get(j)).form+" ");
			out.println(buf.toString());
		}
		out.close();
	}
}
