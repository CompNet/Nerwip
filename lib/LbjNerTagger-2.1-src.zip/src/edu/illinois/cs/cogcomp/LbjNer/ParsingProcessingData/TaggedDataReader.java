package edu.illinois.cs.cogcomp.LbjNer.ParsingProcessingData;
import java.io.File; 
import java.util.Vector;

import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NERDocument;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.NEWord;
import edu.illinois.cs.cogcomp.LbjNer.LbjTagger.ParametersForLbjCode;

import LBJ2.parse.LinkedVector;

public class TaggedDataReader {	
	public static NERDocument parseTextAnnotatedWithBrackets(String annotatedText,String documentName) throws Exception{
		return BracketFileReader.parseTextWithBrackets(annotatedText,documentName);
	}
		
	public static Vector<NERDocument> readFolder(String path,String format)throws Exception{
		Vector<NERDocument> res=new Vector<NERDocument>();
		String[] files=(new File(path)).list();
		if(ParametersForLbjCode.currentParameters.sortLexicallyFilesInFolders)
			sortFilesLexicographically(files);
		for(int i=0;i<files.length;i++){
			String file=path+"/"+files[i];
			if((new File(file)).isFile()&&(!files[i].equals(".DS_Store")))
				res.addElement(readFile(file, format,files[i]));
		}
		if(ParametersForLbjCode.currentParameters.treatAllFilesInFolderAsOneBigDocument){
		    //connecting sentence boundaries
			for(int i=0;i<res.size()-1;i++) {
				Vector<LinkedVector> ss1 = res.elementAt(i).sentences;
				Vector<LinkedVector> ss2 = res.elementAt(i+1).sentences;
				if(ss1.size()>0&&ss1.elementAt(ss1.size()-1).size()>0&&ss2.size()>0&&ss2.elementAt(0).size()>0) {
					NEWord lastWord1 = (NEWord)ss1.elementAt(ss1.size()-1).get(ss1.elementAt(ss1.size()-1).size()-1);
					NEWord firstWord2 = (NEWord)ss2.elementAt(0).get(0);
					lastWord1.nextIgnoreSentenceBoundary = firstWord2;
					firstWord2.previousIgnoreSentenceBoundary = lastWord1;
				}
			}
		}
		return res;
	}

	/*
	 * 
	 */
	public static NERDocument readFile(String path,String format,String documentName) throws Exception{
		NERDocument res=null;
		if(format.equals("-c")){
			res = (new ColumnFileReader(path)).read(documentName);
		}
		else{
			if(format.equals("-r")){
				res = BracketFileReader.read(path,documentName);
			}
			else{
				System.out.println("Fatal error: unrecognized file format: "+format);
				System.exit(0);
			}
		}
		connectSentenceBoundaries(res.sentences);
		return res;
	}
	
	public static void connectSentenceBoundaries(Vector<LinkedVector> sentences){
	    //connecting sentence boundaries
	    for(int i=0;i<sentences.size();i++)
	    {
	    	for(int j=0;j<sentences.elementAt(i).size();j++){
	    		NEWord w=(NEWord)sentences.elementAt(i).get(j);
	    		w.previousIgnoreSentenceBoundary=(NEWord)w.previous;
	    		w.nextIgnoreSentenceBoundary=(NEWord)w.next;
	    	}
	    	if(i>0&&sentences.elementAt(i).size()>0)
	    	{
	    		NEWord w=(NEWord)sentences.elementAt(i).get(0);
	    		w.previousIgnoreSentenceBoundary=(NEWord)sentences.elementAt(i-1).get(sentences.elementAt(i-1).size()-1);
	    	}
	    	if(i<sentences.size()-1&&sentences.elementAt(i).size()>0)
	    	{
	    		NEWord w=(NEWord)sentences.elementAt(i).get(sentences.elementAt(i).size()-1);
	    		w.nextIgnoreSentenceBoundary=(NEWord)sentences.elementAt(i+1).get(0);
	    	}
	    }
	}
	
	public static void sortFilesLexicographically(String[] files){
		for(int i=0;i<files.length;i++)
			for(int j=i+1;j<files.length;j++){
				if(files[i].compareTo(files[j])>0){
					String s=files[i];
					files[i]=files[j];
					files[j]=s;
				}
			}
	}
}
