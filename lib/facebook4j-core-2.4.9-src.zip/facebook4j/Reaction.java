package facebook4j;

public interface Reaction extends IdNameEntity {

    ReactionType getType();

}
