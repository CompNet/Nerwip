package de.unihd.dbs.uima.annotator.heideltime.processors;

import de.unihd.dbs.uima.annotator.heideltime.HeidelTimeException;

public class ProcessorInitializationException extends HeidelTimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4036889037291484936L;

}
