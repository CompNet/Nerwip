package de.unihd.dbs.uima.annotator.heideltime.processors;

import de.unihd.dbs.uima.annotator.heideltime.HeidelTimeException;

public class ProcessorProcessingException extends HeidelTimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6123306006146166368L;

}
