package de.unihd.dbs.uima.annotator.heideltime.utilities;

import de.unihd.dbs.uima.annotator.heideltime.HeidelTimeException;

public class LocaleException extends HeidelTimeException {

	/**
	 * default generated uid
	 */
	private static final long serialVersionUID = -3573142250219483271L;

}
