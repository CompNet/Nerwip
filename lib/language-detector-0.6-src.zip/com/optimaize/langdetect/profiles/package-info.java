/**
 * Provides functionality for loading, storing and creating {@link com.optimaize.langdetect.profiles.LanguageProfile}s.
 *
 * @author Fabian Kessler
 */
package com.optimaize.langdetect.profiles;