
import java.util.*;
import java.io.PrintStream;
import LBJ2.classify.*;
import LBJ2.learn.Learner;

public abstract class Distribution extends Learner
{
  protected int n;

  public Distribution(String n) { this(n, null); }
  public Distribution(String n, Classifier e) { this(n, null, e); }
  public Distribution(String n, Classifier l, Classifier e) {
    super(n, l, e);
  }

  public String getInputType() { return "Example"; }
  public String[] allowableValues()
  { return new String[]{ "foo", "bar", "baz" }; }
  public void learn(Object example) { }
  public void learn(int[] exampleFeatures, double[] exampleValues,
                    int[] exampleLabels, double[] labelValues) { }
  public void forget() { }
  public FeatureVector classify(int[] exampleFeatures, double[] exampleValues)
  { return null; }

  public FeatureVector classify(Object example) {
    return new FeatureVector(featureValue(example));
  }

  public Feature featureValue(Object example) {
    String prediction = scores(example).highScoreValue();
    return
      new DiscretePrimitiveStringFeature(
          "", "f" + n, "", prediction, valueIndexOf(prediction), (short) 3);
  }

  public void write(PrintStream out) { } 
}

