
import LBJ2.classify.*;
import LBJ2.learn.Learner;

public class Distribution1 extends Distribution
{
  public Distribution1() { super(""); }
  public Distribution1(Parameters p) { super(""); }
  public Distribution1(String n)
  {
    this(n, null);
    this.n = 1;
  }

  public Distribution1(String n, Classifier e)
  {
    this(n, null, e);
    this.n = 1;
  }

  public Distribution1(String n, Classifier l, Classifier e)
  {
    super(n, l, e);
    this.n = 1;
  }

  public ScoreSet scores(int[] f, double[] v)
  {
    ScoreSet result = new ScoreSet();
    result.put("foo", .55);
    result.put("bar", .24);
    result.put("baz", .21);
    return result;
  }

  public static class Parameters extends Learner.Parameters
  {
    public Parameters() { }
    public Parameters(Parameters p) { super(p); }
  }
}

