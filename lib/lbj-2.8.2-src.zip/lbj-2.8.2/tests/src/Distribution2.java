
import LBJ2.classify.*;
import LBJ2.learn.Learner;

public class Distribution2 extends Distribution
{
  public Distribution2() { super(""); }
  public Distribution2(Parameters p) { super(""); }
  public Distribution2(String n)
  {
    this(n, null);
    this.n = 2;
  }

  public Distribution2(String n, Classifier e)
  {
    this(n, null, e);
    this.n = 2;
  }

  public Distribution2(String n, Classifier l, Classifier e)
  {
    super(n, l, e);
    this.n = 2;
  }


  public ScoreSet scores(int[] f, double[] v)
  {
    ScoreSet result = new ScoreSet();
    result.put("foo", .55);
    result.put("bar", .23);
    result.put("baz", .22);
    return result;
  }

  public static class Parameters extends Learner.Parameters
  {
    public Parameters() { }
    public Parameters(Parameters p) { super(p); }
  }
}

