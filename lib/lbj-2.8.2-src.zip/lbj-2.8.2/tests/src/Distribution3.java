
import LBJ2.classify.*;
import LBJ2.learn.Learner;

public class Distribution3 extends Distribution
{
  public Distribution3() { super(""); }
  public Distribution3(Parameters p) { super(""); }
  public Distribution3(String n)
  {
    this(n, null);
    this.n = 3;
  }

  public Distribution3(String n, Classifier e)
  {
    this(n, null, e);
    this.n = 3;
  }

  public Distribution3(String n, Classifier l, Classifier e)
  {
    super(n, l, e);
    this.n = 3;
  }


  public ScoreSet scores(int[] f, double[] v)
  {
    ScoreSet result = new ScoreSet();
    result.put("foo", .6);
    result.put("bar", .4);
    result.put("baz", 0);
    return result;
  }

  public static class Parameters extends Learner.Parameters
  {
    public Parameters() { }
    public Parameters(Parameters p) { super(p); }
  }
}

