
public class Example
{
  public String cacheHere;
  public Example() { }
  public String toString() { return ""; }
}

