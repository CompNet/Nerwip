
public class TestInference
{
  public static void main(String[] args)
  {
    C1 c1 = new C1();
    C2 c2 = new C2();
    C3 c3 = new C3();
    I1 i1 = new I1();
    I2 i2 = new I2();
    I3 i3 = new I3();
    Example e = new Example();

    System.out.println(c1.discreteValue(e) + ", " + c2.discreteValue(e)
                       + ", " + c3.discreteValue(e));
    System.out.println(i1.discreteValue(e) + ", " + i2.discreteValue(e)
                       + ", " + i3.discreteValue(e));
  }
}

