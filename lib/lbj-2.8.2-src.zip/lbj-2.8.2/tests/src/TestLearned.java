
public class TestLearned
{
  public static void main(String[] args)
  {
    String file = null;

    try { file = args[0]; }
    catch (Exception e)
    {
      System.err.println("usage: java TestLearned <test file>");
      System.exit(1);
    }

    Learned learned = new Learned();
    learned.demandLexicon();
    Label label = new Label();
    VectorParser parser = new VectorParser(file);
    int correct = 0, examples = 0;

    learned.write(System.out);

    for (Object example = parser.next(); example != null;
         example = parser.next())
    {
      String prediction = learned.discreteValue(example);
      boolean isCorrect = prediction.equals(label.discreteValue(example));
      if (isCorrect) ++correct;
      ++examples;

      System.out.println("Example " + examples + " " + (isCorrect ? "" : "in")
                         + "correct (" + learned.score(example) + ")");
    }

    System.out.println("Accuracy: " + correct + " / " + examples);
  }
}

