
public class TestLearnedReal
{
  public static void main(String[] args)
  {
    String file = null;

    try { file = args[0]; }
    catch (Exception e)
    {
      System.err.println("usage: java TestLearnedReal <test file>");
      System.exit(1);
    }

    Learned learned = new Learned();
    Label label = new Label();
    VectorParser parser = new VectorParser(file);
    int correct = 0, examples = 0;

    learned.write(System.out);

    double totalDifference = 0;
    for (Object example = parser.next(); example != null;
         example = parser.next())
    {
      double prediction = learned.realValue(example);
      double value = label.realValue(example);
      double difference = Math.abs(prediction-value);  
      totalDifference += difference;    
      learned.classify(example);
      ++examples;

      System.out.println("Example " + examples + " difference: " + difference
                         + " (prediction: " + prediction + ")");
    }

    double avg = totalDifference / examples;
    System.out.println("Average difference: " + avg);
  }
}

