
import LBJ2.parse.ArrayFileParser;

public class TestPruned
{
  public static void main(String[] args) {
    String file = null;

    try { file = args[0]; }
    catch (Exception e) {
      System.err.println("usage: java TestPruned <test file>");
      System.exit(1);
    }

    Learned learned = new Learned();
    Label label = new Label();
    ArrayFileParser afp = new ArrayFileParser(file);
    int correct = 0, examples = 0;

    learned.getLexicon().printCountTable(true);
    System.out.println();
    learned.write(System.out);
    System.out.println();

    for (Object example = afp.next(); example != null; example = afp.next()) {
      Object[] ex = (Object[]) example;
      int[] fi = (int[]) ex[0];
      double[] fs = (double[]) ex[1];
      int[] li = (int[]) ex[2];
      double[] ls = (double[]) ex[3];
      System.out.println(arrayToString(li) + ": " + arrayToString(fi));
    }
  }


  static String arrayToString(int[] a) {
    if (a.length == 0) return "";
    StringBuffer buffer = new StringBuffer();
    for (int i = 0; i < a.length; ++i) {
      buffer.append(", ");
      buffer.append(a[i]);
    }

    return buffer.substring(2);
  }
}

