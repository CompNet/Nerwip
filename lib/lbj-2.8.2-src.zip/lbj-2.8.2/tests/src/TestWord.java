
public class TestWord
{
  public String form;
  public String dValue;
  public String[] daValue;
  public double rValue;
  public double[] raValue;
}

