/**
 * Classes for determining entity coreference within documents.
 */
package com.aliasi.coref;
