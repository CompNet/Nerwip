/**
 * Classes and interfaces for conditional random fields.
 */
package com.aliasi.crf;
