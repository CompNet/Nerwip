/**
 * Classes for estimating and decoding hidden Markov models.
 */
package com.aliasi.hmm;
