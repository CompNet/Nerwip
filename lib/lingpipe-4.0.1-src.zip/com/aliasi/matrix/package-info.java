/**
 * Classes for matrices and vectors.
 */
package com.aliasi.matrix;
