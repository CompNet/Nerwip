/**
 * Classes for handling basic statical distributions and estimators.
 */
package com.aliasi.stats;