/**
 * Classes and interfaces for sequence tagging, including evaluators.
 */
package com.aliasi.tag;
