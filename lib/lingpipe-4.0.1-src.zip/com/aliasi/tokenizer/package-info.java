/**
 * Classes for tokenizing character sequences.
 */
package com.aliasi.tokenizer;
